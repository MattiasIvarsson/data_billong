2 clubs

- **Tempête FC** : (2) Tempête · Tempête Football Club ⇒ (3) ≈Tempete≈ · ≈Tempete FC≈ · ≈Tempete Football Club≈
- **Valencia FC** : (1) Valencia




Alphabet

- **Alphabet Specials** (1):  **ê** 
  - **ê**×3 U+00EA (234) - LATIN SMALL LETTER E WITH CIRCUMFLEX ⇒ e




Duplicates





By City

- **Léogâne** (1): Valencia FC  (1) Valencia
- **Saint-Marc** (1): Tempête FC  (2) Tempête · Tempête Football Club




By Region

- **Saint-Marc†** (1):   Tempête FC
- **Léogâne†** (1):   Valencia FC




By Year

- ? (2):   Tempête FC · Valencia FC






By A to Z

- **T** (3): Tempête · Tempête FC · Tempête Football Club
- **V** (2): Valencia · Valencia FC




