3 datafiles, 5 clubs

**caribbean/haiti/ht.clubs.txt** _(2)_:  Tempête FC · Valencia FC

**caribbean/puerto-rico/pr.clubs.txt** _(1)_:  Puerto Rico Islanders

**caribbean/trinidad-n-tobago/tt.clubs.txt** _(2)_:  Caledonia AIA · W Connection

