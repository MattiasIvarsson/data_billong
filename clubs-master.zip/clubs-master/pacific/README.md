2 datafiles, 18 clubs

**pacific/australia/au.clubs.txt** _(9)_:  Adelaide United · Brisbane Roar · Sydney FC · Western Sydney Wanderers · Central Coast Mariners · Newcastle United Jets · Melbourne Heart · Melbourne Victory · Perth Glory

**pacific/new-zealand/nz.clubs.txt** _(9)_:  Auckland City FC · Waitakere United · Hawke's Bay United · Team Wellington · Waikato FC · YoungHeart Manawatu · Canterbury United · Otago United · Wellington Phoenix

