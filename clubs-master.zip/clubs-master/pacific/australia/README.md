9 clubs

- **Adelaide United**
- **Brisbane Roar**
- **Sydney FC**
- **Western Sydney Wanderers** : (1) WS Wanderers FC
- **Central Coast Mariners**
- **Newcastle United Jets** : (1) Newcastle Jets
- **Melbourne Heart**
- **Melbourne Victory**
- **Perth Glory**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Melbourne, Victoria** (2): 
  - Melbourne Heart 
  - Melbourne Victory 
- **Sydney, New South Wales** (2): 
  - Sydney FC 
  - Western Sydney Wanderers  (1) WS Wanderers FC
- **Adelaide, South Australia** (1): Adelaide United 
- **Brisbane Roar, Queensland** (1): Brisbane Roar 
- **Gosford, Central Coast › New South Wales** (1): Central Coast Mariners 
- **Newcastle, New South Wales** (1): Newcastle United Jets  (1) Newcastle Jets
- **Perth, Western Australia** (1): Perth Glory 




By Region

- **South Australia** (1):   Adelaide United
- **Queensland** (1):   Brisbane Roar
- **New South Wales** (3):   Sydney FC · Western Sydney Wanderers · Newcastle United Jets
- **Central Coast › New South Wales** (1):   Central Coast Mariners
- **Victoria** (2):   Melbourne Heart · Melbourne Victory
- **Western Australia** (1):   Perth Glory




By Year

- ? (9):   Adelaide United · Brisbane Roar · Sydney FC · Western Sydney Wanderers · Central Coast Mariners · Newcastle United Jets · Melbourne Heart · Melbourne Victory · Perth Glory






By A to Z

- **A** (1): Adelaide United
- **B** (1): Brisbane Roar
- **C** (1): Central Coast Mariners
- **M** (2): Melbourne Heart · Melbourne Victory
- **N** (2): Newcastle Jets · Newcastle United Jets
- **P** (1): Perth Glory
- **S** (1): Sydney FC
- **W** (2): WS Wanderers FC · Western Sydney Wanderers




