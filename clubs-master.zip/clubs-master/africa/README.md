2 datafiles, 19 clubs

**africa/egypt/eg.clubs.txt** _(18)_:  Al Ahly · Al Mokawloon Al Arab · El Dakhleya · El Entag El Harby · ENPPI SC · Ittihad El Shorta · Tala'ea El Gaish · Wadi Degla · Al Ittihad Al Sakandary · Haras El Hodood · Smouha SC · Zamalek · Ismaily · El Gouna · Ghazl El Mahalla · Misr El Makasa · Petrojet · Telephonat Bani Sweif

**africa/morocco/ma.clubs.txt** _(1)_:  Raja Casablanca

