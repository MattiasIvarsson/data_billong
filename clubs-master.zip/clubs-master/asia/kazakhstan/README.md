10 clubs

- [**FC Astana**](https://en.wikipedia.org/wiki/FC_Astana) : (2) Astana · Football Club Astana
- **FC Aktobe** : (1) Aktobe
- **FC Shakhter Karagandy** : (1) Shakhter
- **FC Tobol Kostanay**
- **FC Irtysh Pavlodar**
- **FC Ordabasy Shymkent**
- **FC Atyrau**
- **FC Zhetysu Taldykorgan**
- **FC Okzhetpes Kokshetau**
- **FC Kairat Almaty**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- ? (10): 
  - FC Astana  (2) Astana · Football Club Astana
  - FC Aktobe  (1) Aktobe
  - FC Shakhter Karagandy  (1) Shakhter
  - FC Tobol Kostanay 
  - FC Irtysh Pavlodar 
  - FC Ordabasy Shymkent 
  - FC Atyrau 
  - FC Zhetysu Taldykorgan 
  - FC Okzhetpes Kokshetau 
  - FC Kairat Almaty 




By Region





By Year

- **2009** (1):   FC Astana
- ? (9):   FC Aktobe · FC Shakhter Karagandy · FC Tobol Kostanay · FC Irtysh Pavlodar · FC Ordabasy Shymkent · FC Atyrau · FC Zhetysu Taldykorgan · FC Okzhetpes Kokshetau · FC Kairat Almaty






By A to Z

- **A** (2): Aktobe · Astana
- **F** (11): FC Aktobe · FC Astana · FC Atyrau · FC Kairat Almaty · FC Tobol Kostanay · FC Irtysh Pavlodar · FC Ordabasy Shymkent · Football Club Astana · FC Shakhter Karagandy · FC Okzhetpes Kokshetau · FC Zhetysu Taldykorgan
- **S** (1): Shakhter




