14 clubs

- **Busan I'Park** : (2) Busan IPark · Busan IPark FC
- **Chunnam Dragons** : (1) Chunnam Dragons FC
- **Daegu FC** : (1) Daegu
- **Daejeon Citizen** : (1) Daejeon Citizen FC
- **Gangwon FC** : (1) Gangwon
- **Gyeongnam FC** : (1) Gyeongnam
- **Incheon United** : (1) Incheon United FC
- **Jeju United** : (1) Jeju United FC
- **Jeonbuk Motors** : (2) Jeonbuk Hyundai Motors · Jeonbuk Hyundai Motors FC
- **Pohang Steelers** : (1) FC Pohang Steelers
- **Seongnam Ilhwa Chunma** : (1) Seongnam Ilhwa Chunma FC
- **FC Seoul** : (1) Seoul
- **Suwon Bluewings** : (2) Suwon Samsung Bluewings · Suwon Samsung Bluewings FC
- **Ulsan Hyundai** : (1) Ulsan Hyundai FC




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **Busan I'Park**, city:busan (1):
  - `busanipark` (2): Busan I'Park · Busan IPark




By City

- **city:busan** (1): Busan I'Park  (2) Busan IPark · Busan IPark FC
- **city:changwon** (1): Gyeongnam FC  (1) Gyeongnam
- **city:daegu** (1): Daegu FC  (1) Daegu
- **city:daejeon** (1): Daejeon Citizen  (1) Daejeon Citizen FC
- **city:gangneung** (1): Gangwon FC  (1) Gangwon
- **city:gwangyang** (1): Chunnam Dragons  (1) Chunnam Dragons FC
- **city:incheon** (1): Incheon United  (1) Incheon United FC
- **city:jeonju** (1): Jeonbuk Motors  (2) Jeonbuk Hyundai Motors · Jeonbuk Hyundai Motors FC
- **city:pohang** (1): Pohang Steelers  (1) FC Pohang Steelers
- **city:seogwipo** (1): Jeju United  (1) Jeju United FC
- **city:seongnam** (1): Seongnam Ilhwa Chunma  (1) Seongnam Ilhwa Chunma FC
- **city:seoul** (1): FC Seoul  (1) Seoul
- **city:suwon** (1): Suwon Bluewings  (2) Suwon Samsung Bluewings · Suwon Samsung Bluewings FC
- **city:ulsan** (1): Ulsan Hyundai  (1) Ulsan Hyundai FC




By Region

- **city:busan†** (1):   Busan I'Park
- **city:gwangyang†** (1):   Chunnam Dragons
- **city:daegu†** (1):   Daegu FC
- **city:daejeon†** (1):   Daejeon Citizen
- **city:gangneung†** (1):   Gangwon FC
- **city:changwon†** (1):   Gyeongnam FC
- **city:incheon†** (1):   Incheon United
- **city:seogwipo†** (1):   Jeju United
- **city:jeonju†** (1):   Jeonbuk Motors
- **city:pohang†** (1):   Pohang Steelers
- **city:seongnam†** (1):   Seongnam Ilhwa Chunma
- **city:seoul†** (1):   FC Seoul
- **city:suwon†** (1):   Suwon Bluewings
- **city:ulsan†** (1):   Ulsan Hyundai




By Year

- ? (14):   Busan I'Park · Chunnam Dragons · Daegu FC · Daejeon Citizen · Gangwon FC · Gyeongnam FC · Incheon United · Jeju United · Jeonbuk Motors · Pohang Steelers · Seongnam Ilhwa Chunma · FC Seoul · Suwon Bluewings · Ulsan Hyundai






By A to Z

- **B** (3): Busan IPark · Busan I'Park · Busan IPark FC
- **C** (2): Chunnam Dragons · Chunnam Dragons FC
- **D** (4): Daegu · Daegu FC · Daejeon Citizen · Daejeon Citizen FC
- **F** (2): FC Seoul · FC Pohang Steelers
- **G** (4): Gangwon · Gyeongnam · Gangwon FC · Gyeongnam FC
- **I** (2): Incheon United · Incheon United FC
- **J** (5): Jeju United · Jeju United FC · Jeonbuk Motors · Jeonbuk Hyundai Motors · Jeonbuk Hyundai Motors FC
- **P** (1): Pohang Steelers
- **S** (6): Seoul · Suwon Bluewings · Seongnam Ilhwa Chunma · Suwon Samsung Bluewings · Seongnam Ilhwa Chunma FC · Suwon Samsung Bluewings FC
- **U** (2): Ulsan Hyundai · Ulsan Hyundai FC




