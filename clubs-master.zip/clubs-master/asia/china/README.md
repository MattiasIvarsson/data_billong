25 clubs

- [**Beijing Sinobo Guoan**](https://en.wikipedia.org/wiki/Beijing_Sinobo_Guoan) : (1) Beijing Guoan
- [**Beijing Renhe**](https://en.wikipedia.org/wiki/Beijing_Renhe_F.C.) : (1) Beijing Renhe F.C.
- [**Shanghai SIPG**](https://en.wikipedia.org/wiki/Shanghai_SIPG_F.C.) : (1) Shanghai SIPG F.C.
- [**Shanghai Greenland Shenhua**](https://en.wikipedia.org/wiki/Shanghai_Greenland_Shenhua) : (1) Shanghai Shenhua
- **Shanghai Shenxin** : (1) Shanghai Shenxin F.C.
- [**Guangzhou Evergrande Taobao**](https://en.wikipedia.org/wiki/Guangzhou_Evergrande_Taobao_F.C.) : (2) Guangzhou Evergrande · Guangzhou Evergrande Taobao F.C.
- [**Guangzhou R&F**](https://en.wikipedia.org/wiki/Guangzhou_R&F)
- [**Chongqing Dangdai Lifan**](https://en.wikipedia.org/wiki/Chongqing_Dangdai_Lifan_F.C.) : (2) Chongqing Lifan · Chongqing Dangdai Lifan F.C.
- [**Changchun Yatai**](https://en.wikipedia.org/wiki/Changchun_Yatai)
- [**Dalian Yifang**](https://en.wikipedia.org/wiki/Dalian_Yifang_F.C.) : (1) Dalian Yifang F.C.
- [**Guizhou Hengfeng**](https://en.wikipedia.org/wiki/Guizhou_Hengfeng_Zhicheng_F.C.) : (2) Guizhou Zhicheng · Guizhou Hengfeng Zhicheng F.C.
- **Hangzhou Greentown**
- [**Shandong Luneng Taishan**](https://en.wikipedia.org/wiki/Shandong_Luneng_Taishan) : (1) Shandong Luneng
- [**Hebei China Fortune**](https://en.wikipedia.org/wiki/Hebei_China_Fortune_F.C.) : (2) Hebei · Hebei China Fortune F.C.
- [**Jiangsu Suning**](https://en.wikipedia.org/wiki/Jiangsu_Suning_F.C.) : (1) Jiangsu Suning F.C.
- **Shenzhen F.C.** : (1) Shenzhen
- **Shijiazhuang Ever Bright** : (1) Shijiazhuang
- **Tianjin Tianhai**
- [**Tianjin TEDA**](https://en.wikipedia.org/wiki/Tianjin_Teda_F.C.) : (2) Tianjin Teda · Tianjin Teda F.C.
- [**Tianjin Quanjian**](https://en.wikipedia.org/wiki/Tianjin_Quanjian)
- **Wuhan Zall**
- [**Henan Jianye**](https://en.wikipedia.org/wiki/Henan_Jianye)
- **Liaoning F.C.** : (1) Liaoning
- **Yanbian Funde** : (1) Yanbian
- **Zhejiang Yiteng F.C.** : (2) Harbin Yiteng · Zhejiang Yiteng




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **Tianjin TEDA**, Tianjin (1):
  - `tianjinteda` (2): Tianjin TEDA · Tianjin Teda




By City

- **Shanghai** (3): 
  - Shanghai SIPG  (1) Shanghai SIPG F.C.
  - Shanghai Greenland Shenhua  (1) Shanghai Shenhua
  - Shanghai Shenxin  (1) Shanghai Shenxin F.C.
- **Tianjin** (3): 
  - Tianjin Tianhai 
  - Tianjin TEDA  (2) Tianjin Teda · Tianjin Teda F.C.
  - Tianjin Quanjian 
- **Beijing** (2): 
  - Beijing Sinobo Guoan  (1) Beijing Guoan
  - Beijing Renhe  (1) Beijing Renhe F.C.
- **Guangzhou** (2): 
  - Guangzhou Evergrande Taobao  (2) Guangzhou Evergrande · Guangzhou Evergrande Taobao F.C.
  - Guangzhou R&F 
- **Changchun** (1): Changchun Yatai 
- **Chongqing** (1): Chongqing Dangdai Lifan  (2) Chongqing Lifan · Chongqing Dangdai Lifan F.C.
- **Dalian** (1): Dalian Yifang  (1) Dalian Yifang F.C.
- **Guiyang** (1): Guizhou Hengfeng  (2) Guizhou Zhicheng · Guizhou Hengfeng Zhicheng F.C.
- **Hangzhou** (1): Hangzhou Greentown 
- **Harbin** (1): Zhejiang Yiteng F.C.  (2) Zhejiang Yiteng · Harbin Yiteng
- **Jinan** (1): Shandong Luneng Taishan  (1) Shandong Luneng
- **Langfang** (1): Hebei China Fortune  (2) Hebei · Hebei China Fortune F.C.
- **Nanjing** (1): Jiangsu Suning  (1) Jiangsu Suning F.C.
- **Shenyang** (1): Liaoning F.C.  (1) Liaoning
- **Shenzhen** (1): Shenzhen F.C.  (1) Shenzhen
- **Shijiazhuang** (1): Shijiazhuang Ever Bright  (1) Shijiazhuang
- **Wuhan** (1): Wuhan Zall 
- **Yanji** (1): Yanbian Funde  (1) Yanbian
- **Zhengzhou** (1): Henan Jianye 




By Region

- **Beijing†** (2):   Beijing Sinobo Guoan · Beijing Renhe
- **Shanghai†** (3):   Shanghai SIPG · Shanghai Greenland Shenhua · Shanghai Shenxin
- **Guangzhou†** (2):   Guangzhou Evergrande Taobao · Guangzhou R&F
- **Chongqing†** (1):   Chongqing Dangdai Lifan
- **Changchun†** (1):   Changchun Yatai
- **Dalian†** (1):   Dalian Yifang
- **Guiyang†** (1):   Guizhou Hengfeng
- **Hangzhou†** (1):   Hangzhou Greentown
- **Jinan†** (1):   Shandong Luneng Taishan
- **Langfang†** (1):   Hebei China Fortune
- **Nanjing†** (1):   Jiangsu Suning
- **Shenzhen†** (1):   Shenzhen F.C.
- **Shijiazhuang†** (1):   Shijiazhuang Ever Bright
- **Tianjin†** (3):   Tianjin Tianhai · Tianjin TEDA · Tianjin Quanjian
- **Wuhan†** (1):   Wuhan Zall
- **Zhengzhou†** (1):   Henan Jianye
- **Shenyang†** (1):   Liaoning F.C.
- **Yanji†** (1):   Yanbian Funde
- **Harbin†** (1):   Zhejiang Yiteng F.C.




By Year

- ? (25):   Beijing Sinobo Guoan · Beijing Renhe · Shanghai SIPG · Shanghai Greenland Shenhua · Shanghai Shenxin · Guangzhou Evergrande Taobao · Guangzhou R&F · Chongqing Dangdai Lifan · Changchun Yatai · Dalian Yifang · Guizhou Hengfeng · Hangzhou Greentown · Shandong Luneng Taishan · Hebei China Fortune · Jiangsu Suning · Shenzhen F.C. · Shijiazhuang Ever Bright · Tianjin Tianhai · Tianjin TEDA · Tianjin Quanjian · Wuhan Zall · Henan Jianye · Liaoning F.C. · Yanbian Funde · Zhejiang Yiteng F.C.






By A to Z

- **B** (4): Beijing Guoan · Beijing Renhe · Beijing Renhe F.C. · Beijing Sinobo Guoan
- **C** (4): Changchun Yatai · Chongqing Lifan · Chongqing Dangdai Lifan · Chongqing Dangdai Lifan F.C.
- **D** (2): Dalian Yifang · Dalian Yifang F.C.
- **G** (7): Guangzhou R&F · Guizhou Hengfeng · Guizhou Zhicheng · Guangzhou Evergrande · Guangzhou Evergrande Taobao · Guizhou Hengfeng Zhicheng F.C. · Guangzhou Evergrande Taobao F.C.
- **H** (6): Hebei · Henan Jianye · Harbin Yiteng · Hangzhou Greentown · Hebei China Fortune · Hebei China Fortune F.C.
- **J** (2): Jiangsu Suning · Jiangsu Suning F.C.
- **L** (2): Liaoning · Liaoning F.C.
- **S** (12): Shenzhen · Shijiazhuang · Shanghai SIPG · Shenzhen F.C. · Shandong Luneng · Shanghai Shenhua · Shanghai Shenxin · Shanghai SIPG F.C. · Shanghai Shenxin F.C. · Shandong Luneng Taishan · Shijiazhuang Ever Bright · Shanghai Greenland Shenhua
- **T** (5): Tianjin TEDA · Tianjin Teda · Tianjin Tianhai · Tianjin Quanjian · Tianjin Teda F.C.
- **W** (1): Wuhan Zall
- **Y** (2): Yanbian · Yanbian Funde
- **Z** (2): Zhejiang Yiteng · Zhejiang Yiteng F.C.




