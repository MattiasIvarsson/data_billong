27 clubs

- [**FC Tokyo**](https://en.wikipedia.org/wiki/FC_Tokyo) : (1) Tokyo
- **Tokyo Verdy** : (1) Verdy
- **Albirex Niigata**
- **Omiya Ardija**
- [**Cerezo Osaka**](https://en.wikipedia.org/wiki/Cerezo_Osaka) : (1) C-Osaka
- [**Gamba Osaka**](https://en.wikipedia.org/wiki/Gamba_Osaka) : (1) G-Osaka
- [**Yokohama F. Marinos**](https://en.wikipedia.org/wiki/Yokohama_F._Marinos) : (2) Yokohama · Yokohama M.
- [**Kawasaki Frontale**](https://en.wikipedia.org/wiki/Kawasaki_Frontale)
- [**Nagoya Grampus**](https://en.wikipedia.org/wiki/Nagoya_Grampus) : (1) Nagoya
- [**Júbilo Iwata**](https://en.wikipedia.org/wiki/Júbilo_Iwata) : (1) Iwata ⇒ (1) ≈Jubilo Iwata≈
- [**Urawa Red Diamonds**](https://en.wikipedia.org/wiki/Urawa_Red_Diamonds) : (1) Urawa
- **Kashiwa Reysol** : (1) Kashiwa
- [**Shimizu S-Pulse**](https://en.wikipedia.org/wiki/Shimizu_S-Pulse) : (1) Shimizu
- [**Sagan Tosu**](https://en.wikipedia.org/wiki/Sagan_Tosu)
- [**Sanfrecce Hiroshima**](https://en.wikipedia.org/wiki/Sanfrecce_Hiroshima) : (1) Hiroshima
- [**Vegalta Sendai**](https://en.wikipedia.org/wiki/Vegalta_Sendai)
- [**Hokkaido Consadole Sapporo**](https://en.wikipedia.org/wiki/Consadole_Sapporo) : (2) Sapporo · Consadole Sapporo
- **Avispa Fukuoka**
- [**Matsumoto Yamaga**](https://en.wikipedia.org/wiki/Matsumoto_Yamaga) : (1) Yamaga
- [**Vissel Kobe**](https://en.wikipedia.org/wiki/Vissel_Kobe) : (1) Kobe
- **V-Varen Nagasaki**
- [**Kashima Antlers**](https://en.wikipedia.org/wiki/Kashima_Antlers) : (1) Kashima
- [**Oita Trinita**](https://en.wikipedia.org/wiki/Oita_Trinita) : (1) Oita
- [**Shonan Bellmare**](https://en.wikipedia.org/wiki/Shonan_Bellmare) : (1) Shonan
- **Ventforet Kofu** : (1) Kofu
- **Montedio Yamagata**
- **Tokushima Vortis** : (1) Tokushima




Alphabet

- **Alphabet Specials** (1):  **ú** 
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Tokyo** (2): 
  - FC Tokyo  (1) Tokyo
  - Tokyo Verdy  (1) Verdy
- **Hakata, Fukuoka** (1): Avispa Fukuoka 
- **Hiroshima, Hiroshima** (1): Sanfrecce Hiroshima  (1) Hiroshima
- **Iwata, Shizuoka** (1): Júbilo Iwata  (1) Iwata
- **Kashiwa, Chiba** (1): Kashiwa Reysol  (1) Kashiwa
- **Kawasaki, Kanagawa** (1): Kawasaki Frontale 
- **Matsumoto, Nagano** (1): Matsumoto Yamaga  (1) Yamaga
- **Miyagi** (1): Vegalta Sendai 
- **Nagoya, Aichi** (1): Nagoya Grampus  (1) Nagoya
- **Niigata & Seiro, Niigata** (1): Albirex Niigata 
- **Omiya, Saitama** (1): Omiya Ardija 
- **Osaka, Osaka** (1): Cerezo Osaka  (1) C-Osaka
- **Sapporo, Hokkaido** (1): Hokkaido Consadole Sapporo  (2) Sapporo · Consadole Sapporo
- **Shizuoka, Shizuoka** (1): Shimizu S-Pulse  (1) Shimizu
- **Suita, Osaka** (1): Gamba Osaka  (1) G-Osaka
- **Tosu, Saga** (1): Sagan Tosu 
- **Urawa, Saitama** (1): Urawa Red Diamonds  (1) Urawa
- **Yokohama & Yokosuka, Kanagawa** (1): Yokohama F. Marinos  (2) Yokohama · Yokohama M.
- ? (8): 
  - Vissel Kobe  (1) Kobe
  - V-Varen Nagasaki 
  - Kashima Antlers  (1) Kashima
  - Oita Trinita  (1) Oita
  - Shonan Bellmare  (1) Shonan
  - Ventforet Kofu  (1) Kofu
  - Montedio Yamagata 
  - Tokushima Vortis  (1) Tokushima




By Region

- **Tokyo†** (2):   FC Tokyo · Tokyo Verdy
- **Niigata** (1):   Albirex Niigata
- **Saitama** (2):   Omiya Ardija · Urawa Red Diamonds
- **Osaka** (2):   Cerezo Osaka · Gamba Osaka
- **Kanagawa** (2):   Yokohama F. Marinos · Kawasaki Frontale
- **Aichi** (1):   Nagoya Grampus
- **Shizuoka** (2):   Júbilo Iwata · Shimizu S-Pulse
- **Chiba** (1):   Kashiwa Reysol
- **Saga** (1):   Sagan Tosu
- **Hiroshima** (1):   Sanfrecce Hiroshima
- **Miyagi†** (1):   Vegalta Sendai
- **Hokkaido** (1):   Hokkaido Consadole Sapporo
- **Fukuoka** (1):   Avispa Fukuoka
- **Nagano** (1):   Matsumoto Yamaga




By Year

- ? (27):   FC Tokyo · Tokyo Verdy · Albirex Niigata · Omiya Ardija · Cerezo Osaka · Gamba Osaka · Yokohama F. Marinos · Kawasaki Frontale · Nagoya Grampus · Júbilo Iwata · Urawa Red Diamonds · Kashiwa Reysol · Shimizu S-Pulse · Sagan Tosu · Sanfrecce Hiroshima · Vegalta Sendai · Hokkaido Consadole Sapporo · Avispa Fukuoka · Matsumoto Yamaga · Vissel Kobe · V-Varen Nagasaki · Kashima Antlers · Oita Trinita · Shonan Bellmare · Ventforet Kofu · Montedio Yamagata · Tokushima Vortis






By A to Z

- **A** (2): Avispa Fukuoka · Albirex Niigata
- **C** (3): C-Osaka · Cerezo Osaka · Consadole Sapporo
- **F** (1): FC Tokyo
- **G** (2): G-Osaka · Gamba Osaka
- **H** (2): Hiroshima · Hokkaido Consadole Sapporo
- **I** (1): Iwata
- **J** (1): Júbilo Iwata
- **K** (7): Kobe · Kofu · Kashima · Kashiwa · Kashiwa Reysol · Kashima Antlers · Kawasaki Frontale
- **M** (2): Matsumoto Yamaga · Montedio Yamagata
- **N** (2): Nagoya · Nagoya Grampus
- **O** (3): Oita · Oita Trinita · Omiya Ardija
- **S** (7): Shonan · Sapporo · Shimizu · Sagan Tosu · Shimizu S-Pulse · Shonan Bellmare · Sanfrecce Hiroshima
- **T** (4): Tokyo · Tokushima · Tokyo Verdy · Tokushima Vortis
- **U** (2): Urawa · Urawa Red Diamonds
- **V** (5): Verdy · Vissel Kobe · Vegalta Sendai · Ventforet Kofu · V-Varen Nagasaki
- **Y** (4): Yamaga · Yokohama · Yokohama M. · Yokohama F. Marinos




