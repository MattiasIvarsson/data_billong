5 clubs

- **Universidad de Chile** : (2) U. de Chile · Club Universidad de Chile
- **Universidad Católica** : (3) CDUC · CD Universidad Católica · Club Deportivo Universidad Católica ⇒ (3) ≈Universidad Catolica≈ · ≈CD Universidad Catolica≈ · ≈Club Deportivo Universidad Catolica≈
- **Unión Española** : (1) Club Unión Española S.A.D.P ⇒ (2) ≈Union Espanola≈ · ≈Club Union Espanola S.A.D.P≈
- **CD Huachipato** : (2) Huachipato · Club Deportivo Huachipato
- **Deportes Iquique** : (2) Iquique · Club Deportes Iquique




Alphabet

- **Alphabet Specials** (2):  **ñ**  **ó** 
  - **ñ**×2 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×5 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Santiago** (3): 
  - Universidad de Chile  (2) U. de Chile · Club Universidad de Chile
  - Universidad Católica  (3) CDUC · CD Universidad Católica · Club Deportivo Universidad Católica
  - Unión Española  (1) Club Unión Española S.A.D.P
- **Iquique** (1): Deportes Iquique  (2) Iquique · Club Deportes Iquique
- **Talcahuano** (1): CD Huachipato  (2) Huachipato · Club Deportivo Huachipato




By Region

- **Santiago†** (3):   Universidad de Chile · Universidad Católica · Unión Española
- **Talcahuano†** (1):   CD Huachipato
- **Iquique†** (1):   Deportes Iquique




By Year

- ? (5):   Universidad de Chile · Universidad Católica · Unión Española · CD Huachipato · Deportes Iquique






By A to Z

- **C** (8): CDUC · CD Huachipato · Club Deportes Iquique · CD Universidad Católica · Club Deportivo Huachipato · Club Universidad de Chile · Club Unión Española S.A.D.P · Club Deportivo Universidad Católica
- **D** (1): Deportes Iquique
- **H** (1): Huachipato
- **I** (1): Iquique
- **U** (4): U. de Chile · Unión Española · Universidad Católica · Universidad de Chile




