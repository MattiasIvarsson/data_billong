37 clubs

- **All Boys** : (1) Club Atlético All Boys ⇒ (1) ≈Club Atletico All Boys≈
- [**Argentinos Juniors**](https://en.wikipedia.org/wiki/Argentinos_Juniors) : (3) Argentinos · Argentinos Jrs · Asociación Atlética Argentinos Juniors ⇒ (1) ≈Asociacion Atletica Argentinos Juniors≈
- [**Boca Juniors**](https://en.wikipedia.org/wiki/Boca_Juniors) : (3) Boca · Boca Jrs · Club Atlético Boca Juniors ⇒ (1) ≈Club Atletico Boca Juniors≈
- [**River Plate**](https://en.wikipedia.org/wiki/Club_Atlético_River_Plate) : (2) River · Club Atlético River Plate ⇒ (1) ≈Club Atletico River Plate≈
- [**San Lorenzo**](https://en.wikipedia.org/wiki/San_Lorenzo_de_Almagro) : (3) San Lorenzo de Almagro · CA San Lorenzo de Almagro · Club Atlético San Lorenzo de Almagro ⇒ (1) ≈Club Atletico San Lorenzo de Almagro≈
- [**Vélez Sarsfield**](https://en.wikipedia.org/wiki/Club_Atlético_Vélez_Sarsfield) : (5) Vélez · CA Vélez · Velez Sarsfield · CA Vélez Sarsfield · Club Atlético Vélez Sarsfield ⇒ (5) ≈Velez≈ · ≈CA Velez≈ · ≈Velez Sarsfield≈ · ≈CA Velez Sarsfield≈ · ≈Club Atletico Velez Sarsfield≈
- [**Huracán**](https://en.wikipedia.org/wiki/Club_Atlético_Huracán) : (2) Huracan · Club Atlético Huracán ⇒ (2) ≈Huracan≈ · ≈Club Atletico Huracan≈
- **Nueva Chicago** : (1) Club Atlético Nueva Chicago ⇒ (1) ≈Club Atletico Nueva Chicago≈
- **CA Tigre** : (2) Tigre · Club Atlético Tigre ⇒ (1) ≈Club Atletico Tigre≈
- [**CA Independiente de Avellaneda**](https://en.wikipedia.org/wiki/Club_Atlético_Independiente) : (2) Independiente · Club Atlético Independiente ⇒ (1) ≈Club Atletico Independiente≈
- [**Racing Club**](https://en.wikipedia.org/wiki/Racing_Club_de_Avellaneda) : (2) Racing · Racing Club de Avellaneda
- **Quilmes AC** : (2) Quilmes · Quilmes Atlético Club ⇒ (1) ≈Quilmes Atletico Club≈
- [**CA Lanús**](https://en.wikipedia.org/wiki/Club_Atlético_Lanús) : (3) Lanús · Lanus · Club Atlético Lanús ⇒ (3) ≈Lanus≈ · ≈CA Lanus≈ · ≈Club Atletico Lanus≈
- [**Arsenal de Sarandí**](https://en.wikipedia.org/wiki/Arsenal_de_Sarandí) : (4) Arsenal · Arsenal FC · Arsenal Sarandi · Arsenal Fútbol Club ⇒ (2) ≈Arsenal de Sarandi≈ · ≈Arsenal Futbol Club≈
- [**Estudiantes LP**](https://en.wikipedia.org/wiki/Estudiantes_de_La_Plata) : (4) Estudiantes · Estudiantes L.P. · Estudiantes de La Plata · Club Estudiantes de La Plata
- [**Gimnasia y Esgrima**](https://en.wikipedia.org/wiki/Club_de_Gimnasia_y_Esgrima_La_Plata) : (4) GELP · Gimnasia L.P. · Gimnasia y Esgrima La Plata · Club de Gimnasia y Esgrima La Plata
- [**Club Atlético Aldosivi**](https://en.wikipedia.org/wiki/Aldosivi) : (1) Aldosivi ⇒ (1) ≈Club Atletico Aldosivi≈
- [**Club Atlético Banfield**](https://en.wikipedia.org/wiki/Club_Atlético_Banfield) : (1) Banfield ⇒ (1) ≈Club Atletico Banfield≈
- [**Defensa y Justicia**](https://en.wikipedia.org/wiki/Defensa_y_Justicia) : (1) Club Social y Deportivo Defensa y Justicia
- **Olimpo Bahía Blanca** : (4) Olimpo · Club Olimpo · Olimpo Bahia Blanca · Olimpo de Bahía Blanca ⇒ (2) ≈Olimpo Bahia Blanca≈ · ≈Olimpo de Bahia Blanca≈
- **Sarmiento Junín** : (4) Sarmiento · Sarmiento Junin · Club Atlético Sarmiento · Club Atlético Sarmiento (Junín) ⇒ (3) ≈Sarmiento Junin≈ · ≈Club Atletico Sarmiento≈ · ≈Club Atletico Sarmiento (Junin)≈
- **Temperley** : (1) Club Atlético Temperley ⇒ (1) ≈Club Atletico Temperley≈
- **Chacarita Juniors** : (1) Club Atlético Chacarita Juniors ⇒ (1) ≈Club Atletico Chacarita Juniors≈
- [**Colón Santa Fe**](https://en.wikipedia.org/wiki/Club_Atlético_Colón) : (5) Colón · CA Colón · Colon Santa FE · Club Atlético Colón · Club Atlético Colón (Santa Fe) ⇒ (5) ≈Colon≈ · ≈CA Colon≈ · ≈Colon Santa Fe≈ · ≈Club Atletico Colon≈ · ≈Club Atletico Colon (Santa Fe)≈
- [**Unión Santa Fe**](https://en.wikipedia.org/wiki/Unión_de_Santa_Fe) : (3) Unión · Unión de Santa Fe · Club Atlético Unión ⇒ (4) ≈Union≈ · ≈Union Santa Fe≈ · ≈Union de Santa Fe≈ · ≈Club Atletico Union≈
- [**Newell's Old Boys**](https://en.wikipedia.org/wiki/Newell's_Old_Boys) : (5) Newell's · N.O. Boys · Newells Old Boys · CA Newell's Old Boys · Club Atlético Newell's Old Boys ⇒ (1) ≈Club Atletico Newell's Old Boys≈
- [**Rosario Central**](https://en.wikipedia.org/wiki/Rosario_Central) : (1) Club Atlético Rosario Central ⇒ (1) ≈Club Atletico Rosario Central≈
- **Atlético Rafaela** : (4) Atl. Rafaela · At. de Rafaela · Atlético de Rafaela · Asociación Mutual Social y Deportiva Atlético de Rafaela ⇒ (3) ≈Atletico Rafaela≈ · ≈Atletico de Rafaela≈ · ≈Asociacion Mutual Social y Deportiva Atletico de Rafaela≈
- **Club Atlético Belgrano** : (1) Belgrano ⇒ (1) ≈Club Atletico Belgrano≈
- [**Talleres de Córdoba**](https://en.wikipedia.org/wiki/Talleres_de_Córdoba) : (2) Talleres Cordoba · Club Atlético Talleres ⇒ (2) ≈Talleres de Cordoba≈ · ≈Club Atletico Talleres≈
- [**Godoy Cruz**](https://en.wikipedia.org/wiki/Godoy_Cruz_Antonio_Tomba) : (2) Godoy Cruz Antonio Tomba · Club Deportivo Godoy Cruz Antonio Tomba
- **San Martín** : (3) San Martin S.J. · San Martín San Juan · Club Atlético San Martín ⇒ (3) ≈San Martin≈ · ≈San Martin San Juan≈ · ≈Club Atletico San Martin≈
- [**Atlético Tucumán**](https://en.wikipedia.org/wiki/Atlético_Tucumán) : (1) Atl. Tucuman ⇒ (1) ≈Atletico Tucuman≈
- **San Martín de Tucumán** : (3) San Martin T. · Club Atlético San Martín · Club Atlético San Martín (Tucumán) ⇒ (3) ≈San Martin de Tucuman≈ · ≈Club Atletico San Martin≈ · ≈Club Atletico San Martin (Tucuman)≈
- [**Patronato**](https://en.wikipedia.org/wiki/Club_Atlético_Patronato) : (2) Club Atlético Patronato · Club Atlético Patronato de la Juventud Católica ⇒ (2) ≈Club Atletico Patronato≈ · ≈Club Atletico Patronato de la Juventud Catolica≈
- **Crucero del Norte** : (1) Club Mutual Crucero del Norte
- [**Central Córdoba**](https://en.wikipedia.org/wiki/Central_Córdoba_de_Santiago_del_Estero) : (3) Central Córdoba (SdE) · Club Atlético Central Córdoba · Central Córdoba de Santiago del Estero ⇒ (4) ≈Central Cordoba≈ · ≈Central Cordoba (SdE)≈ · ≈Club Atletico Central Cordoba≈ · ≈Central Cordoba de Santiago del Estero≈




Alphabet

- **Alphabet Specials** (5):  **á**  **é**  **í**  **ó**  **ú** 
  - **á**×5 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×40 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×11 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×17 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×4 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates

- **Vélez Sarsfield**, Buenos Aires (1):
  - `velezsarsfield` (2): **Velez Sarsfield** · **Velez Sarsfield**
- **Huracán**, Buenos Aires (1):
  - `huracan` (2): **Huracan** · **Huracan**
- **CA Lanús**, Lanús (1):
  - `lanus` (2): **Lanus** · **Lanus**
- **Estudiantes LP**, La Plata (1):
  - `estudianteslp` (2): Estudiantes LP · Estudiantes L.P.
- **Olimpo Bahía Blanca**, Bahía Blanca (1):
  - `olimpobahiablanca` (2): **Olimpo Bahia Blanca** · **Olimpo Bahia Blanca**
- **Sarmiento Junín**, Junín (1):
  - `sarmientojunin` (2): **Sarmiento Junin** · **Sarmiento Junin**
- **Colón Santa Fe**, Santa Fe (1):
  - `colonsantafe` (2): Colon Santa FE · Colon Santa Fe
- **Newell's Old Boys**, Rosario (1):
  - `newellsoldboys` (2): Newell's Old Boys · Newells Old Boys




By City

- **Buenos Aires, Buenos Aires** (8): 
  - All Boys  (1) Club Atlético All Boys
  - Argentinos Juniors  (3) Argentinos · Argentinos Jrs · Asociación Atlética Argentinos Juniors
  - Boca Juniors  (3) Boca · Boca Jrs · Club Atlético Boca Juniors
  - River Plate  (2) River · Club Atlético River Plate
  - San Lorenzo  (3) San Lorenzo de Almagro · CA San Lorenzo de Almagro · Club Atlético San Lorenzo de Almagro
  - Vélez Sarsfield  (5) Vélez · Velez Sarsfield · CA Vélez · CA Vélez Sarsfield · Club Atlético Vélez Sarsfield
  - Huracán  (2) Huracan · Club Atlético Huracán
  - Nueva Chicago  (1) Club Atlético Nueva Chicago
- **Avellaneda, Buenos Aires** (2): 
  - CA Independiente de Avellaneda  (2) Independiente · Club Atlético Independiente
  - Racing Club  (2) Racing · Racing Club de Avellaneda
- **Córdoba, Córdoba** (2): 
  - Club Atlético Belgrano  (1) Belgrano
  - Talleres de Córdoba  (2) Talleres Cordoba · Club Atlético Talleres
- **La Plata, Buenos Aires** (2): 
  - Estudiantes LP  (4) Estudiantes · Estudiantes L.P. · Club Estudiantes de La Plata · Estudiantes de La Plata
  - Gimnasia y Esgrima  (4) Gimnasia L.P. · Gimnasia y Esgrima La Plata · GELP · Club de Gimnasia y Esgrima La Plata
- **Rosario, Santa Fe** (2): 
  - Newell's Old Boys  (5) Newell's · Newells Old Boys · N.O. Boys · CA Newell's Old Boys · Club Atlético Newell's Old Boys
  - Rosario Central  (1) Club Atlético Rosario Central
- **San Miguel de Tucumán, Tucumán** (2): 
  - Atlético Tucumán  (1) Atl. Tucuman
  - San Martín de Tucumán  (3) San Martin T. · Club Atlético San Martín · Club Atlético San Martín (Tucumán)
- **Santa Fe, Santa Fe** (2): 
  - Colón Santa Fe  (5) Colón · CA Colón · Club Atlético Colón · Club Atlético Colón (Santa Fe) · Colon Santa FE
  - Unión Santa Fe  (3) Unión · Unión de Santa Fe · Club Atlético Unión
- **Bahía Blanca, Buenos Aires** (1): Olimpo Bahía Blanca  (4) Olimpo · Club Olimpo · Olimpo Bahia Blanca · Olimpo de Bahía Blanca
- **Banfield, Buenos Aires** (1): Club Atlético Banfield  (1) Banfield
- **Garupá, Misiones** (1): Crucero del Norte  (1) Club Mutual Crucero del Norte
- **Gobernador Julio A. Costa, Buenos Aires** (1): Defensa y Justicia  (1) Club Social y Deportivo Defensa y Justicia
- **Junín, Buenos Aires** (1): Sarmiento Junín  (4) Sarmiento · Sarmiento Junin · Club Atlético Sarmiento · Club Atlético Sarmiento (Junín)
- **Lanús, Buenos Aires** (1): CA Lanús  (3) Lanús · Lanus · Club Atlético Lanús
- **Mar del Plata, Buenos Aires** (1): Club Atlético Aldosivi  (1) Aldosivi
- **Mendoza, Mendoza** (1): Godoy Cruz  (2) Godoy Cruz Antonio Tomba · Club Deportivo Godoy Cruz Antonio Tomba
- **Paraná, Entre Ríos** (1): Patronato  (2) Club Atlético Patronato · Club Atlético Patronato de la Juventud Católica
- **Quilmes, Buenos Aires** (1): Quilmes AC  (2) Quilmes · Quilmes Atlético Club
- **Rafaela, Santa Fe** (1): Atlético Rafaela  (4) At. de Rafaela · Atl. Rafaela · Atlético de Rafaela · Asociación Mutual Social y Deportiva Atlético de Rafaela
- **San Juan, San Juan** (1): San Martín  (3) San Martin S.J. · San Martín San Juan · Club Atlético San Martín
- **Santiago del Estero, Santiago del Estero** (1): Central Córdoba  (3) Club Atlético Central Córdoba · Central Córdoba de Santiago del Estero · Central Córdoba (SdE)
- **Sarandí, Buenos Aires** (1): Arsenal de Sarandí  (4) Arsenal · Arsenal Sarandi · Arsenal FC · Arsenal Fútbol Club
- **Turdera, Buenos Aires** (1): Temperley  (1) Club Atlético Temperley
- **Victoria, Buenos Aires** (1): CA Tigre  (2) Tigre · Club Atlético Tigre
- **Villa Maipú, Buenos Aires** (1): Chacarita Juniors  (1) Club Atlético Chacarita Juniors




By Region

- **Buenos Aires** (23):   All Boys · Argentinos Juniors · Boca Juniors · River Plate · San Lorenzo · Vélez Sarsfield · Huracán · Nueva Chicago · CA Tigre · CA Independiente de Avellaneda · Racing Club · Quilmes AC · CA Lanús · Arsenal de Sarandí · Estudiantes LP · Gimnasia y Esgrima · Club Atlético Aldosivi · Club Atlético Banfield · Defensa y Justicia · Olimpo Bahía Blanca · Sarmiento Junín · Temperley · Chacarita Juniors
- **Santa Fe** (5):   Colón Santa Fe · Unión Santa Fe · Newell's Old Boys · Rosario Central · Atlético Rafaela
- **Córdoba** (2):   Club Atlético Belgrano · Talleres de Córdoba
- **Mendoza** (1):   Godoy Cruz
- **San Juan** (1):   San Martín
- **Tucumán** (2):   Atlético Tucumán · San Martín de Tucumán
- **Entre Ríos** (1):   Patronato
- **Misiones** (1):   Crucero del Norte
- **Santiago del Estero** (1):   Central Córdoba




By Year

- ? (37):   All Boys · Argentinos Juniors · Boca Juniors · River Plate · San Lorenzo · Vélez Sarsfield · Huracán · Nueva Chicago · CA Tigre · CA Independiente de Avellaneda · Racing Club · Quilmes AC · CA Lanús · Arsenal de Sarandí · Estudiantes LP · Gimnasia y Esgrima · Club Atlético Aldosivi · Club Atlético Banfield · Defensa y Justicia · Olimpo Bahía Blanca · Sarmiento Junín · Temperley · Chacarita Juniors · Colón Santa Fe · Unión Santa Fe · Newell's Old Boys · Rosario Central · Atlético Rafaela · Club Atlético Belgrano · Talleres de Córdoba · Godoy Cruz · San Martín · Atlético Tucumán · San Martín de Tucumán · Patronato · Crucero del Norte · Central Córdoba






By A to Z

- **A** (18): Arsenal · Aldosivi · All Boys · Argentinos · Arsenal FC · Atl. Rafaela · Atl. Tucuman · Argentinos Jrs · At. de Rafaela · Arsenal Sarandi · Atlético Rafaela · Atlético Tucumán · Argentinos Juniors · Arsenal de Sarandí · Arsenal Fútbol Club · Atlético de Rafaela · Asociación Atlética Argentinos Juniors · Asociación Mutual Social y Deportiva Atlético de Rafaela
- **B** (5): Boca · Banfield · Belgrano · Boca Jrs · Boca Juniors
- **C** (50): Colón · CA Colón · CA Lanús · CA Tigre · CA Vélez · Club Olimpo · Colon Santa FE · Colón Santa Fe · Central Córdoba · Chacarita Juniors · Crucero del Norte · CA Vélez Sarsfield · Club Atlético Colón · Club Atlético Lanús · Club Atlético Tigre · Club Atlético Unión · CA Newell's Old Boys · Central Córdoba (SdE) · Club Atlético Huracán · Club Atlético Aldosivi · Club Atlético All Boys · Club Atlético Banfield · Club Atlético Belgrano · Club Atlético Talleres · Club Atlético Patronato · Club Atlético Sarmiento · Club Atlético Temperley · !! **Club Atlético San Martín (2)** !! · CA San Lorenzo de Almagro · Club Atlético River Plate · Club Atlético Boca Juniors · Club Atlético Independiente · Club Atlético Nueva Chicago · Club Estudiantes de La Plata · Club Atlético Central Córdoba · Club Atlético Rosario Central · Club Atlético Vélez Sarsfield · Club Mutual Crucero del Norte · CA Independiente de Avellaneda · Club Atlético Colón (Santa Fe) · Club Atlético Chacarita Juniors · Club Atlético Newell's Old Boys · Club Atlético Sarmiento (Junín) · Club Atlético San Martín (Tucumán) · Club de Gimnasia y Esgrima La Plata · Club Atlético San Lorenzo de Almagro · Central Córdoba de Santiago del Estero · Club Deportivo Godoy Cruz Antonio Tomba · Club Social y Deportivo Defensa y Justicia · Club Atlético Patronato de la Juventud Católica
- **D** (1): Defensa y Justicia
- **E** (4): Estudiantes · Estudiantes LP · Estudiantes L.P. · Estudiantes de La Plata
- **G** (6): GELP · Godoy Cruz · Gimnasia L.P. · Gimnasia y Esgrima · Godoy Cruz Antonio Tomba · Gimnasia y Esgrima La Plata
- **H** (2): Huracan · Huracán
- **I** (1): Independiente
- **L** (2): Lanus · Lanús
- **N** (5): Newell's · N.O. Boys · Nueva Chicago · Newells Old Boys · Newell's Old Boys
- **O** (4): Olimpo · Olimpo Bahia Blanca · Olimpo Bahía Blanca · Olimpo de Bahía Blanca
- **P** (1): Patronato
- **Q** (3): Quilmes · Quilmes AC · Quilmes Atlético Club
- **R** (6): River · Racing · Racing Club · River Plate · Rosario Central · Racing Club de Avellaneda
- **S** (10): Sarmiento · San Martín · San Lorenzo · San Martin T. · San Martin S.J. · Sarmiento Junin · Sarmiento Junín · San Martín San Juan · San Martín de Tucumán · San Lorenzo de Almagro
- **T** (4): Tigre · Temperley · Talleres Cordoba · Talleres de Córdoba
- **U** (3): Unión · Unión Santa Fe · Unión de Santa Fe
- **V** (3): Vélez · Velez Sarsfield · Vélez Sarsfield




