6 clubs

- **Deportivo Quito** : (1) Sociedad Deportivo Quito
- **El Nacional** : (1) Club Deportivo El Nacional
- **LDU Quito** : (3) LDU de Quito · Liga de Quito · Liga Deportiva Universitaria de Quito
- **CS Emelec** : (2) Emelec · Club Sport Emelec
- **Barcelona Guayaquil** : (4) Barcelona · Barcelona SC · Barcelona SC Guayaquil · Barcelona Sporting Club
- **LDU Loja** : (3) LDU de Loja · Liga de Loja · Liga Deportiva Universitaria de Loja




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Quito** (3): 
  - Deportivo Quito  (1) Sociedad Deportivo Quito
  - El Nacional  (1) Club Deportivo El Nacional
  - LDU Quito  (3) LDU de Quito · Liga de Quito · Liga Deportiva Universitaria de Quito
- **Guayaquil** (2): 
  - CS Emelec  (2) Emelec · Club Sport Emelec
  - Barcelona Guayaquil  (4) Barcelona · Barcelona SC Guayaquil · Barcelona SC · Barcelona Sporting Club
- **Loja** (1): LDU Loja  (3) LDU de Loja · Liga de Loja · Liga Deportiva Universitaria de Loja




By Region

- **Quito†** (3):   Deportivo Quito · El Nacional · LDU Quito
- **Guayaquil†** (2):   CS Emelec · Barcelona Guayaquil
- **Loja†** (1):   LDU Loja




By Year

- ? (6):   Deportivo Quito · El Nacional · LDU Quito · CS Emelec · Barcelona Guayaquil · LDU Loja






By A to Z

- **B** (5): Barcelona · Barcelona SC · Barcelona Guayaquil · Barcelona SC Guayaquil · Barcelona Sporting Club
- **C** (3): CS Emelec · Club Sport Emelec · Club Deportivo El Nacional
- **D** (1): Deportivo Quito
- **E** (2): Emelec · El Nacional
- **L** (8): LDU Loja · LDU Quito · LDU de Loja · LDU de Quito · Liga de Loja · Liga de Quito · Liga Deportiva Universitaria de Loja · Liga Deportiva Universitaria de Quito
- **S** (1): Sociedad Deportivo Quito




