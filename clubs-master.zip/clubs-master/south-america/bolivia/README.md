5 clubs

- **Club Bolívar** : (1) Bolívar ⇒ (2) ≈Bolivar≈ · ≈Club Bolivar≈
- **The Strongest** : (2) Strongest · Club The Strongest
- **Real Potosí** : (1) Club Bamin Real Potosí ⇒ (2) ≈Real Potosi≈ · ≈Club Bamin Real Potosi≈
- **Club Deportivo San José** : (1) San José ⇒ (2) ≈San Jose≈ · ≈Club Deportivo San Jose≈
- **Club Deportivo Oriente Petrolero** : (1) Oriente Petrolero




Alphabet

- **Alphabet Specials** (2):  **é**  **í** 
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×4 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i




Duplicates





By City

- **La Paz** (2): 
  - Club Bolívar  (1) Bolívar
  - The Strongest  (2) Strongest · Club The Strongest
- **Oruro** (1): Club Deportivo San José  (1) San José
- **Potosí** (1): Real Potosí  (1) Club Bamin Real Potosí
- **Santa Cruz de la Sierra** (1): Club Deportivo Oriente Petrolero  (1) Oriente Petrolero




By Region

- **La Paz†** (2):   Club Bolívar · The Strongest
- **Potosí†** (1):   Real Potosí
- **Oruro†** (1):   Club Deportivo San José
- **Santa Cruz de la Sierra†** (1):   Club Deportivo Oriente Petrolero




By Year

- ? (5):   Club Bolívar · The Strongest · Real Potosí · Club Deportivo San José · Club Deportivo Oriente Petrolero






By A to Z

- **B** (1): Bolívar
- **C** (5): Club Bolívar · Club The Strongest · Club Bamin Real Potosí · Club Deportivo San José · Club Deportivo Oriente Petrolero
- **O** (1): Oriente Petrolero
- **R** (1): Real Potosí
- **S** (2): San José · Strongest
- **T** (1): The Strongest




