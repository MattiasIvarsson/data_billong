18 clubs

- **Caracas FC** : (2) Caracas · Caracas Fútbol Club ⇒ (1) ≈Caracas Futbol Club≈
- **Deportivo La Guaira** : (1) Dvo. La Guaira
- **Deportivo Petare** : (1) Dvo. Petare
- **Deportivo Táchira** : (2) Dvo. Táchira · Deportivo Táchira Fútbol Club ⇒ (3) ≈Dvo. Tachira≈ · ≈Deportivo Tachira≈ · ≈Deportivo Tachira Futbol Club≈
- **Zamora FC** : (2) Zamora · Zamora Fútbol Club ⇒ (1) ≈Zamora Futbol Club≈
- **Deportivo Lara** : (2) Dvo. Lara · Club Deportivo Lara
- **Deportivo Anzoátegui** : (2) Dvo. Anzoátegui · Deportivo Anzoátegui Sport Club ⇒ (3) ≈Dvo. Anzoategui≈ · ≈Deportivo Anzoategui≈ · ≈Deportivo Anzoategui Sport Club≈
- **AC Mineros** : (2) Mineros · Mineros de Guayana
- **Atlético El Vigía** ⇒ (1) ≈Atletico El Vigia≈
- **Llaneros FC** : (2) Llaneros · Llaneros de Guanare
- **Atlético Venezuela** ⇒ (1) ≈Atletico Venezuela≈
- **Zulia FC** : (1) Zulia
- **Aragua FC** : (1) Aragua
- **Estudiantes de Mérida** : (1) Estudiantes ⇒ (1) ≈Estudiantes de Merida≈
- **Tucanes FC** : (2) Tucanes · Tucanes de Amazonas
- **Yaracuyanos FC** : (1) Yaracuyanos
- **Carabobo FC** : (1) Carabobo
- **Trujillanos FC** : (1) Trujillanos




Alphabet

- **Alphabet Specials** (4):  **á**  **é**  **í**  **ú** 
  - **á**×6 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×3 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×1 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ú**×3 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Caracas** (3): 
  - Caracas FC  (2) Caracas · Caracas Fútbol Club
  - Deportivo La Guaira  (1) Dvo. La Guaira
  - Deportivo Petare  (1) Dvo. Petare
- **Barinas** (1): Zamora FC  (2) Zamora · Zamora Fútbol Club
- **Barquisimeto** (1): Deportivo Lara  (2) Dvo. Lara · Club Deportivo Lara
- **Ciudad Guayana** (1): AC Mineros  (2) Mineros · Mineros de Guayana
- **El Vigía** (1): Atlético El Vigía 
- **Guanare** (1): Llaneros FC  (2) Llaneros · Llaneros de Guanare
- **Maiquetía** (1): Atlético Venezuela 
- **Maracaibo** (1): Zulia FC  (1) Zulia
- **Maracay** (1): Aragua FC  (1) Aragua
- **Mérida** (1): Estudiantes de Mérida  (1) Estudiantes
- **Puerto Ayacucho** (1): Tucanes FC  (2) Tucanes · Tucanes de Amazonas
- **Puerto La Cruz** (1): Deportivo Anzoátegui  (2) Dvo. Anzoátegui · Deportivo Anzoátegui Sport Club
- **San Cristóbal** (1): Deportivo Táchira  (2) Dvo. Táchira · Deportivo Táchira Fútbol Club
- **San Felipe** (1): Yaracuyanos FC  (1) Yaracuyanos
- **Valencia** (1): Carabobo FC  (1) Carabobo
- **Valera** (1): Trujillanos FC  (1) Trujillanos




By Region

- **Caracas†** (3):   Caracas FC · Deportivo La Guaira · Deportivo Petare
- **San Cristóbal†** (1):   Deportivo Táchira
- **Barinas†** (1):   Zamora FC
- **Barquisimeto†** (1):   Deportivo Lara
- **Puerto La Cruz†** (1):   Deportivo Anzoátegui
- **Ciudad Guayana†** (1):   AC Mineros
- **El Vigía†** (1):   Atlético El Vigía
- **Guanare†** (1):   Llaneros FC
- **Maiquetía†** (1):   Atlético Venezuela
- **Maracaibo†** (1):   Zulia FC
- **Maracay†** (1):   Aragua FC
- **Mérida†** (1):   Estudiantes de Mérida
- **Puerto Ayacucho†** (1):   Tucanes FC
- **San Felipe†** (1):   Yaracuyanos FC
- **Valencia†** (1):   Carabobo FC
- **Valera†** (1):   Trujillanos FC




By Year

- **1967** (1):   Caracas FC
- ? (17):   Deportivo La Guaira · Deportivo Petare · Deportivo Táchira · Zamora FC · Deportivo Lara · Deportivo Anzoátegui · AC Mineros · Atlético El Vigía · Llaneros FC · Atlético Venezuela · Zulia FC · Aragua FC · Estudiantes de Mérida · Tucanes FC · Yaracuyanos FC · Carabobo FC · Trujillanos FC






By A to Z

- **A** (5): Aragua · Aragua FC · AC Mineros · Atlético El Vigía · Atlético Venezuela
- **C** (6): Caracas · Carabobo · Caracas FC · Carabobo FC · Caracas Fútbol Club · Club Deportivo Lara
- **D** (12): Dvo. Lara · Dvo. Petare · Dvo. Táchira · Deportivo Lara · Dvo. La Guaira · Dvo. Anzoátegui · Deportivo Petare · Deportivo Táchira · Deportivo La Guaira · Deportivo Anzoátegui · Deportivo Táchira Fútbol Club · Deportivo Anzoátegui Sport Club
- **E** (2): Estudiantes · Estudiantes de Mérida
- **L** (3): Llaneros · Llaneros FC · Llaneros de Guanare
- **M** (2): Mineros · Mineros de Guayana
- **T** (5): Tucanes · Tucanes FC · Trujillanos · Trujillanos FC · Tucanes de Amazonas
- **Y** (2): Yaracuyanos · Yaracuyanos FC
- **Z** (5): Zulia · Zamora · Zulia FC · Zamora FC · Zamora Fútbol Club




