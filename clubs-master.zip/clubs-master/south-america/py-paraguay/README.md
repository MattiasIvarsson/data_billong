4 clubs

- **Libertad Ascunción** : (2) Libertad · Club Libertad Asunción ⇒ (2) ≈Libertad Ascuncion≈ · ≈Club Libertad Asuncion≈
- **Club Olimpia** : (1) Olimpia
- **Club Nacional** : (2) Nacional · Nacional de Asunción ⇒ (1) ≈Nacional de Asuncion≈
- **Cerro Porteño** : (1) Club Cerro Porteño ⇒ (2) ≈Cerro Porteno≈ · ≈Club Cerro Porteno≈




Alphabet

- **Alphabet Specials** (2):  **ñ**  **ó** 
  - **ñ**×2 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×3 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Asunción** (4): 
  - Libertad Ascunción  (2) Club Libertad Asunción · Libertad
  - Club Olimpia  (1) Olimpia
  - Club Nacional  (2) Nacional · Nacional de Asunción
  - Cerro Porteño  (1) Club Cerro Porteño




By Region

- **Asunción†** (4):   Libertad Ascunción · Club Olimpia · Club Nacional · Cerro Porteño




By Year

- ? (4):   Libertad Ascunción · Club Olimpia · Club Nacional · Cerro Porteño






By A to Z

- **C** (5): Club Olimpia · Cerro Porteño · Club Nacional · Club Cerro Porteño · Club Libertad Asunción
- **L** (2): Libertad · Libertad Ascunción
- **N** (2): Nacional · Nacional de Asunción
- **O** (1): Olimpia




