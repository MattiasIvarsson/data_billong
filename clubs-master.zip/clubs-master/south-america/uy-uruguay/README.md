16 clubs

- **Liverpool Montevideo** : (4) Liverpool · Liverpool FC · Liverpool Fútbol Club · Liverpool FC Montevideo ⇒ (1) ≈Liverpool Futbol Club≈
- **Nacional de Montevideo** : (3) Nacional · C. N. de F. · Club Nacional de Football
- **Defensor Sporting** : (3) Defensor · Defensor Sp. · Defensor Sporting Club
- **CA Peñarol** : (2) Peñarol · Club Atlético Peñarol ⇒ (3) ≈Penarol≈ · ≈CA Penarol≈ · ≈Club Atletico Penarol≈
- **CA Cerro** : (2) Cerro · Club Atlético Cerro ⇒ (1) ≈Club Atletico Cerro≈
- **Danubio FC** : (2) Danubio · Danubio Fútbol Club ⇒ (1) ≈Danubio Futbol Club≈
- **El Tanque Sisley** : (1) Deportivo El Tanque Sisley
- **Centro Atlético Fénix** : (1) Fénix ⇒ (2) ≈Fenix≈ · ≈Centro Atletico Fenix≈
- **CS Miramar Misiones** : (2) Miramar Misiones · Club Sportivo Miramar Misiones
- **Montevideo Wanderers** : (3) Wanderers · Montevideo Wanderers FC · Montevideo Wanderers Fútbol Club ⇒ (1) ≈Montevideo Wanderers Futbol Club≈
- **Racing CM** : (2) Racing · Racing Club de Montevideo
- **CA Rentistas** : (2) Rentistas · Club Atlético Rentistas ⇒ (1) ≈Club Atletico Rentistas≈
- **CA River Plate** : (2) River Plate · Club Atlético River Plate ⇒ (1) ≈Club Atletico River Plate≈
- **Juventud de Las Piedras** : (2) Juventud · Club Atlético Juventud de Las Piedras ⇒ (1) ≈Club Atletico Juventud de Las Piedras≈
- **Cerro Largo** : (2) Cerro Largo FC · Cerro Largo Fútbol Club ⇒ (1) ≈Cerro Largo Futbol Club≈
- **Sud América** : (2) I.A.S.A · Institución Atlética Sud América ⇒ (2) ≈Sud America≈ · ≈Institucion Atletica Sud America≈




Alphabet

- **Alphabet Specials** (4):  **é**  **ñ**  **ó**  **ú** 
  - **é**×11 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ñ**×3 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×4 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Montevideo** (13): 
  - Liverpool Montevideo  (4) Liverpool · Liverpool FC · Liverpool Fútbol Club · Liverpool FC Montevideo
  - Nacional de Montevideo  (3) Nacional · Club Nacional de Football · C. N. de F.
  - Defensor Sporting  (3) Defensor · Defensor Sp. · Defensor Sporting Club
  - CA Peñarol  (2) Peñarol · Club Atlético Peñarol
  - CA Cerro  (2) Cerro · Club Atlético Cerro
  - Danubio FC  (2) Danubio · Danubio Fútbol Club
  - El Tanque Sisley  (1) Deportivo El Tanque Sisley
  - Centro Atlético Fénix  (1) Fénix
  - CS Miramar Misiones  (2) Miramar Misiones · Club Sportivo Miramar Misiones
  - Montevideo Wanderers  (3) Wanderers · Montevideo Wanderers FC · Montevideo Wanderers Fútbol Club
  - Racing CM  (2) Racing · Racing Club de Montevideo
  - CA Rentistas  (2) Rentistas · Club Atlético Rentistas
  - CA River Plate  (2) River Plate · Club Atlético River Plate
- **Las Piedras** (1): Juventud de Las Piedras  (2) Juventud · Club Atlético Juventud de Las Piedras
- **Melo** (1): Cerro Largo  (2) Cerro Largo FC · Cerro Largo Fútbol Club
- **San José** (1): Sud América  (2) Institución Atlética Sud América · I.A.S.A




By Region

- **Montevideo†** (13):   Liverpool Montevideo · Nacional de Montevideo · Defensor Sporting · CA Peñarol · CA Cerro · Danubio FC · El Tanque Sisley · Centro Atlético Fénix · CS Miramar Misiones · Montevideo Wanderers · Racing CM · CA Rentistas · CA River Plate
- **Las Piedras†** (1):   Juventud de Las Piedras
- **Melo†** (1):   Cerro Largo
- **San José†** (1):   Sud América




By Year

- **1899** (1):   Nacional de Montevideo
- **1902** (1):   Montevideo Wanderers
- **1906** (1):   CS Miramar Misiones
- **1914** (1):   Sud América
- **1916** (1):   Centro Atlético Fénix
- **1919** (1):   Racing CM
- **1922** (1):   CA Cerro
- **1932** (2):   Danubio FC · CA River Plate
- **1933** (1):   CA Rentistas
- **1935** (1):   Juventud de Las Piedras
- **1941** (1):   El Tanque Sisley
- **2002** (1):   Cerro Largo
- ? (3):   Liverpool Montevideo · Defensor Sporting · CA Peñarol






By A to Z

- **C** (18): Cerro · CA Cerro · CA Peñarol · C. N. de F. · Cerro Largo · CA Rentistas · CA River Plate · Cerro Largo FC · CS Miramar Misiones · Club Atlético Cerro · Centro Atlético Fénix · Club Atlético Peñarol · Cerro Largo Fútbol Club · Club Atlético Rentistas · Club Atlético River Plate · Club Nacional de Football · Club Sportivo Miramar Misiones · Club Atlético Juventud de Las Piedras
- **D** (8): Danubio · Defensor · Danubio FC · Defensor Sp. · Defensor Sporting · Danubio Fútbol Club · Defensor Sporting Club · Deportivo El Tanque Sisley
- **E** (1): El Tanque Sisley
- **F** (1): Fénix
- **I** (2): I.A.S.A · Institución Atlética Sud América
- **J** (2): Juventud · Juventud de Las Piedras
- **L** (5): Liverpool · Liverpool FC · Liverpool Montevideo · Liverpool Fútbol Club · Liverpool FC Montevideo
- **M** (4): Miramar Misiones · Montevideo Wanderers · Montevideo Wanderers FC · Montevideo Wanderers Fútbol Club
- **N** (2): Nacional · Nacional de Montevideo
- **P** (1): Peñarol
- **R** (5): Racing · Racing CM · Rentistas · River Plate · Racing Club de Montevideo
- **S** (1): Sud América
- **W** (1): Wanderers




