49 clubs

- [**Corinthians SP**](https://en.wikipedia.org/wiki/Sport_Club_Corinthians_Paulista) : (4) Corinthians · Corinthians São Paulo · SC Corinthians Paulista · Sport Club Corinthians Paulista ⇒ (1) ≈Corinthians Sao Paulo≈
- [**São Paulo FC**](https://en.wikipedia.org/wiki/São_Paulo_FC) : (5) Sao Paulo · São Paulo · São Paulo SP · FC São Paulo · São Paulo Futebol Clube ⇒ (5) ≈Sao Paulo≈ · ≈Sao Paulo FC≈ · ≈Sao Paulo SP≈ · ≈FC Sao Paulo≈ · ≈Sao Paulo Futebol Clube≈
- [**Palmeiras SP**](https://en.wikipedia.org/wiki/Sociedade_Esportiva_Palmeiras) : (4) Palmeiras · SE Palmeiras · SE Palmeiras São Paulo · Sociedade Esportiva Palmeiras ⇒ (1) ≈SE Palmeiras Sao Paulo≈
- [**Santos SP**](https://en.wikipedia.org/wiki/Santos_FC) : (4) Santos · Santos FC · FC Santos · Santos Futebol Clube
- [**Ponte Preta**](https://en.wikipedia.org/wiki/Associação_Atlética_Ponte_Preta) : (2) AA Ponte Preta · Associação Atlética Ponte Preta ⇒ (1) ≈Associacao Atletica Ponte Preta≈
- **CA Bragantino** : (2) Bragantino · Clube Atlético Bragantino ⇒ (1) ≈Clube Atletico Bragantino≈
- [**RB Bragantino**](https://en.wikipedia.org/wiki/Red_Bull_Bragantino) : (2) Bragantino · Red Bull Bragantino
- [**Oeste SP**](https://en.wikipedia.org/wiki/Oeste_Futebol_Clube) : (3) Oeste · Oeste FC · Oeste Futebol Clube
- **Portuguesa** : (1) Associação Portuguesa de Desportos ⇒ (1) ≈Associacao Portuguesa de Desportos≈
- [**Botafogo SP**](https://en.wikipedia.org/wiki/Botafogo_Futebol_Clube_(SP)) : (3) Botafogo FC · Botafogo Futebol Clube · Botafogo Futebol Clube (SP)
- [**Guarani FC**](https://en.wikipedia.org/wiki/Guarani_FC) : (2) Guarani · Guarani Futebol Clube
- [**São Bento**](https://en.wikipedia.org/wiki/Esporte_Clube_São_Bento) : (1) Esporte Clube São Bento ⇒ (2) ≈Sao Bento≈ · ≈Esporte Clube Sao Bento≈
- [**Botafogo RJ**](https://en.wikipedia.org/wiki/Botafogo_de_Futebol_e_Regatas) : (3) Botafogo · Botafogo FR · Botafogo de Futebol e Regatas
- [**Flamengo RJ**](https://en.wikipedia.org/wiki/Clube_de_Regatas_do_Flamengo) : (4) Flamengo · CR Flamengo · Flamengo Rio de Janeiro · Clube de Regatas do Flamengo
- [**Fluminense RJ**](https://en.wikipedia.org/wiki/Fluminense_FC) : (4) Fluminense · Fluminense FC · Fluminense Football Club · Fluminense Rio de Janeiro
- [**CR Vasco da Gama**](https://en.wikipedia.org/wiki/CR_Vasco_da_Gama) : (5) Vasco · Vasco RJ · Vasco da Gama · Vasco da Gama Rio de Janeiro · Club de Regatas Vasco da Gama
- [**Atlético MG**](https://en.wikipedia.org/wiki/Clube_Atlético_Mineiro) : (5) Atlético/MG · Atletico-MG · Atlético Mineiro · C Atlético Mineiro · Clube Atlético Mineiro ⇒ (5) ≈Atletico MG≈ · ≈Atletico/MG≈ · ≈Atletico Mineiro≈ · ≈C Atletico Mineiro≈ · ≈Clube Atletico Mineiro≈
- [**Cruzeiro MG**](https://en.wikipedia.org/wiki/Cruzeiro_Esporte_Clube) : (4) Cruzeiro · Cruzeiro EC · Cruzeiro Esporte Clube · Cruzeiro Belo Horizonte
- [**América MG**](https://en.wikipedia.org/wiki/América_Futebol_Clube_(MG)) : (5) America MG · América FC · América Mineiro · América Futebol Clube · América Futebol Clube (MG) ⇒ (5) ≈America MG≈ · ≈America FC≈ · ≈America Mineiro≈ · ≈America Futebol Clube≈ · ≈America Futebol Clube (MG)≈
- **Tupi MG** : (3) Tupi · Tupi FC · Tupi Football Club
- [**Grêmio RS**](https://en.wikipedia.org/wiki/Grêmio_Foot-Ball_Porto_Alegrense) : (5) Gremio · Grêmio · Grêmio FBPA · Grêmio Porto Alegre · Grêmio Foot-Ball Porto Alegrense ⇒ (5) ≈Gremio≈ · ≈Gremio RS≈ · ≈Gremio FBPA≈ · ≈Gremio Porto Alegre≈ · ≈Gremio Foot-Ball Porto Alegrense≈
- [**Internacional Porto Alegre**](https://en.wikipedia.org/wiki/Sport_Club_Internacional) : (4) Internacional · SC Internacional · Internacional RS · Sport Club Internacional
- [**Brasil RS**](https://en.wikipedia.org/wiki/Grêmio_Esportivo_Brasil) : (4) GE Brasil · Brasil de Pelotas · Grêmio Esportivo Brasil · Grêmio Esportivo Brasil de Pelotas ⇒ (2) ≈Gremio Esportivo Brasil≈ · ≈Gremio Esportivo Brasil de Pelotas≈
- [**Atlético PR**](https://en.wikipedia.org/wiki/Club_Athletico_Paranaense) : (7) Atletico-PR · Atlético/PR · Athletico-PR [en] · Atlético Paranaense · C Atlético Paranaense · Clube Atlético Paranaense · Club Athletico Paranaense [en] ⇒ (5) ≈Atletico PR≈ · ≈Atletico/PR≈ · ≈Atletico Paranaense≈ · ≈C Atletico Paranaense≈ · ≈Clube Atletico Paranaense≈
- [**Coritiba PR**](https://en.wikipedia.org/wiki/Coritiba_Foot_Ball_Club) : (3) Coritiba · Coritiba FC · Coritiba Football Club
- [**Londrina EC**](https://en.wikipedia.org/wiki/Londrina_Esporte_Clube) : (2) Londrina · Londrina Esporte Clube
- [**Paraná Clube**](https://en.wikipedia.org/wiki/Paraná_Clube) : (1) Parana ⇒ (1) ≈Parana Clube≈
- [**Operário Ferroviário**](https://en.wikipedia.org/wiki/Operário_Ferroviário_Esporte_Clube) : (2) Operário · Operário Ferroviário Esporte Clube ⇒ (3) ≈Operario≈ · ≈Operario Ferroviario≈ · ≈Operario Ferroviario Esporte Clube≈
- [**Figueirense**](https://en.wikipedia.org/wiki/Figueirense_FC) : (3) Figueirense FC · Figueirense SC · Figueirense Futebol Clube
- [**Chapecoense**](https://en.wikipedia.org/wiki/Associação_Chapecoense_de_Futebol) : (2) Chapecoense-SC · Associação Chapecoense de Futebol ⇒ (1) ≈Associacao Chapecoense de Futebol≈
- [**Criciúma EC**](https://en.wikipedia.org/wiki/Criciúma_Esporte_Clube) : (3) Criciuma · Criciúma · Criciúma Esporte Clube ⇒ (3) ≈Criciuma≈ · ≈Criciuma EC≈ · ≈Criciuma Esporte Clube≈
- [**Avaí FC**](https://en.wikipedia.org/wiki/Avaí_FC) : (2) Avai · Avaí Futebol Clube ⇒ (2) ≈Avai FC≈ · ≈Avai Futebol Clube≈
- **Joinvile EC** : (3) Joinvile · Joinville · Joinville Esporte Clube
- [**Sport Recife**](https://en.wikipedia.org/wiki/Sport_Club_do_Recife) : (3) Sport · Sport PE · Sport Club do Recife
- **Santa Cruz** : (2) Santa Cruz FC · Santa Cruz Futebol Clube
- **Náutico PE** : (4) Nautico · Náutico · C Náutico Capibaribe · Clube Náutico Capibaribe ⇒ (4) ≈Nautico≈ · ≈Nautico PE≈ · ≈C Nautico Capibaribe≈ · ≈Clube Nautico Capibaribe≈
- [**EC Vitória**](https://en.wikipedia.org/wiki/Esporte_Clube_Vitória) : (3) Vitoria · Vitória · Esporte Clube Vitória ⇒ (3) ≈Vitoria≈ · ≈EC Vitoria≈ · ≈Esporte Clube Vitoria≈
- [**EC Bahia**](https://en.wikipedia.org/wiki/Esporte_Clube_Bahia) : (3) Bahia · Bahia BA · Esporte Clube Bahia
- [**Goiás EC**](https://en.wikipedia.org/wiki/Goiás_Esporte_Clube) : (3) Goias · Goiás · Goiás Esporte Clube ⇒ (3) ≈Goias≈ · ≈Goias EC≈ · ≈Goias Esporte Clube≈
- [**Atlético GO**](https://en.wikipedia.org/wiki/Atlético_Clube_Goianiense) : (3) Atletico GO · Atlético Goianiense · Atlético Clube Goianiense ⇒ (3) ≈Atletico GO≈ · ≈Atletico Goianiense≈ · ≈Atletico Clube Goianiense≈
- [**Vila Nova GO**](https://en.wikipedia.org/wiki/Vila_Nova_Futebol_Clube) : (4) Vila Nova · Vila Nova FC · Vila Nova de Goias · Vila Nova Futebol Clube
- [**Ceára SC**](https://en.wikipedia.org/wiki/Ceará_Sporting_Club) : (3) Ceara · Ceará · Ceará Sporting Club ⇒ (3) ≈Ceara≈ · ≈Ceara SC≈ · ≈Ceara Sporting Club≈
- [**Fortaleza**](https://en.wikipedia.org/wiki/Fortaleza_Esporte_Clube) : (1) Fortaleza Esporte Clube
- **Paysandu SC** : (2) Paysandu · Paysandu Sport Club
- [**CRB AL**](https://en.wikipedia.org/wiki/Clube_de_Regatas_Brasil) : (2) CRB · Clube de Regatas Brasil
- [**CSA**](https://en.wikipedia.org/wiki/Centro_Sportivo_Alagoano) : (1) Centro Sportivo Alagoano
- **Luverdense EC** : (2) Luverdense · Luverdense Esporte Clube
- [**Cuiabá**](https://en.wikipedia.org/wiki/Cuiabá_Esporte_Clube) : (1) Cuiabá Esporte Clube ⇒ (2) ≈Cuiaba≈ · ≈Cuiaba Esporte Clube≈
- **Sampaio Corrêa FC** : (2) Sampaio Corrêa · Sampaio Corrêa Futebol Clube ⇒ (3) ≈Sampaio Correa≈ · ≈Sampaio Correa FC≈ · ≈Sampaio Correa Futebol Clube≈




Alphabet

- **Alphabet Specials** (8):  **á**  **ã**  **ç**  **é**  **ê**  **í**  **ó**  **ú** 
  - **á**×18 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **ã**×12 U+00E3 (227) - LATIN SMALL LETTER A WITH TILDE ⇒ a
  - **ç**×3 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **é**×20 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ê**×10 U+00EA (234) - LATIN SMALL LETTER E WITH CIRCUMFLEX ⇒ e
  - **í**×2 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×3 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×3 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates

- **São Paulo FC**, São Paulo (1):
  - `saopaulo` (2): **Sao Paulo** · **Sao Paulo**
- **Atlético MG**, Belo Horizonte (2):
  - `atléticomg` (2): Atlético MG · Atlético/MG
  - `atleticomg` (3): Atletico-MG · Atletico MG · Atletico/MG
- **América MG**, Belo Horizonte (1):
  - `americamg` (2): **America MG** · **America MG**
- **Grêmio RS**, Porto Alegre (1):
  - `gremio` (2): **Gremio** · **Gremio**
- **Atlético PR**, Curitiba (2):
  - `atléticopr` (2): Atlético PR · Atlético/PR
  - `atleticopr` (3): Atletico-PR · Atletico PR · Atletico/PR
- **Criciúma EC**, Criciúma (1):
  - `criciuma` (2): **Criciuma** · **Criciuma**
- **Náutico PE**, Recife (1):
  - `nautico` (2): **Nautico** · **Nautico**
- **EC Vitória**, Salvador (1):
  - `vitoria` (2): **Vitoria** · **Vitoria**
- **Goiás EC**, Goiânia (1):
  - `goias` (2): **Goias** · **Goias**
- **Atlético GO**, Goiânia (1):
  - `atleticogo` (2): **Atletico GO** · **Atletico GO**
- **Ceára SC**, Fortaleza (1):
  - `ceara` (2): **Ceara** · **Ceara**




By City

- **Rio de Janeiro, Rio de Janeiro** (4): 
  - Botafogo RJ  (3) Botafogo · Botafogo FR · Botafogo de Futebol e Regatas
  - Flamengo RJ  (4) Flamengo · CR Flamengo · Flamengo Rio de Janeiro · Clube de Regatas do Flamengo
  - Fluminense RJ  (4) Fluminense · Fluminense FC · Fluminense Rio de Janeiro · Fluminense Football Club
  - CR Vasco da Gama  (5) Vasco · Vasco RJ · Vasco da Gama · Vasco da Gama Rio de Janeiro · Club de Regatas Vasco da Gama
- **São Paulo, São Paulo** (4): 
  - Corinthians SP  (4) Corinthians · SC Corinthians Paulista · Corinthians São Paulo · Sport Club Corinthians Paulista
  - São Paulo FC  (5) Sao Paulo · São Paulo · FC São Paulo · São Paulo SP · São Paulo Futebol Clube
  - Palmeiras SP  (4) Palmeiras · SE Palmeiras · SE Palmeiras São Paulo · Sociedade Esportiva Palmeiras
  - Portuguesa  (1) Associação Portuguesa de Desportos
- **Belo Horizonte, Minas Gerais** (3): 
  - Atlético MG  (5) Atlético Mineiro · C Atlético Mineiro · Clube Atlético Mineiro · Atletico-MG · Atlético/MG
  - Cruzeiro MG  (4) Cruzeiro · Cruzeiro EC · Cruzeiro Esporte Clube · Cruzeiro Belo Horizonte
  - América MG  (5) América Mineiro · América FC · América Futebol Clube · America MG · América Futebol Clube (MG)
- **Curitiba, Paraná** (3): 
  - Atlético PR  (7) Atlético Paranaense · C Atlético Paranaense · Clube Atlético Paranaense · Atletico-PR · Atlético/PR · Athletico-PR [en] · Club Athletico Paranaense [en]
  - Coritiba PR  (3) Coritiba · Coritiba FC · Coritiba Football Club
  - Paraná Clube  (1) Parana
- **Goiânia, Goiás** (3): 
  - Goiás EC  (3) Goias · Goiás · Goiás Esporte Clube
  - Atlético GO  (3) Atletico GO · Atlético Goianiense · Atlético Clube Goianiense
  - Vila Nova GO  (4) Vila Nova · Vila Nova de Goias · Vila Nova FC · Vila Nova Futebol Clube
- **Recife, Pernambuco** (3): 
  - Sport Recife  (3) Sport · Sport PE · Sport Club do Recife
  - Santa Cruz  (2) Santa Cruz FC · Santa Cruz Futebol Clube
  - Náutico PE  (4) Nautico · Náutico · C Náutico Capibaribe · Clube Náutico Capibaribe
- **Bragança Paulista, São Paulo** (2): 
  - CA Bragantino  (2) Bragantino · Clube Atlético Bragantino
  - RB Bragantino  (2) Bragantino · Red Bull Bragantino
- **Campinas, São Paulo** (2): 
  - Ponte Preta  (2) AA Ponte Preta · Associação Atlética Ponte Preta
  - Guarani FC  (2) Guarani · Guarani Futebol Clube
- **Florianópolis, Santa Catarina** (2): 
  - Figueirense  (3) Figueirense FC · Figueirense SC · Figueirense Futebol Clube
  - Avaí FC  (2) Avai · Avaí Futebol Clube
- **Fortaleza, Ceará** (2): 
  - Ceára SC  (3) Ceara · Ceará · Ceará Sporting Club
  - Fortaleza  (1) Fortaleza Esporte Clube
- **Maceió, Alagoas** (2): 
  - CRB AL  (2) CRB · Clube de Regatas Brasil
  - CSA  (1) Centro Sportivo Alagoano
- **Porto Alegre, Rio Grande do Sul** (2): 
  - Grêmio RS  (5) Gremio · Grêmio · Grêmio Porto Alegre · Grêmio FBPA · Grêmio Foot-Ball Porto Alegrense
  - Internacional Porto Alegre  (4) Internacional · SC Internacional · Internacional RS · Sport Club Internacional
- **Salvador, Bahia** (2): 
  - EC Vitória  (3) Vitoria · Vitória · Esporte Clube Vitória
  - EC Bahia  (3) Bahia · Bahia BA · Esporte Clube Bahia
- **Belém, Pará** (1): Paysandu SC  (2) Paysandu · Paysandu Sport Club
- **Chapecó, Santa Catarina** (1): Chapecoense  (2) Chapecoense-SC · Associação Chapecoense de Futebol
- **Criciúma, Santa Catarina** (1): Criciúma EC  (3) Criciuma · Criciúma · Criciúma Esporte Clube
- **Cuiabá, Mato Grosso** (1): Cuiabá  (1) Cuiabá Esporte Clube
- **Itápolis, São Paulo** (1): Oeste SP  (3) Oeste · Oeste FC · Oeste Futebol Clube
- **Joinville, Santa Catarina** (1): Joinvile EC  (3) Joinvile · Joinville · Joinville Esporte Clube
- **Juiz de Fora, Minas Gerais** (1): Tupi MG  (3) Tupi · Tupi FC · Tupi Football Club
- **Londrina, Paraná** (1): Londrina EC  (2) Londrina · Londrina Esporte Clube
- **Lucas do Rio Verde, Mato Grosso** (1): Luverdense EC  (2) Luverdense · Luverdense Esporte Clube
- **Pelotas, Rio Grande do Sul** (1): Brasil RS  (4) Brasil de Pelotas · GE Brasil · Grêmio Esportivo Brasil · Grêmio Esportivo Brasil de Pelotas
- **Ponta Grossa, Paraná** (1): Operário Ferroviário  (2) Operário · Operário Ferroviário Esporte Clube
- **Ribeirão Preto, São Paulo** (1): Botafogo SP  (3) Botafogo FC · Botafogo Futebol Clube · Botafogo Futebol Clube (SP)
- **Santos, São Paulo** (1): Santos SP  (4) Santos · Santos FC · FC Santos · Santos Futebol Clube
- **Sorocaba, São Paulo** (1): São Bento  (1) Esporte Clube São Bento
- **São Luís, Maranhão** (1): Sampaio Corrêa FC  (2) Sampaio Corrêa · Sampaio Corrêa Futebol Clube




By Region

- **São Paulo** (12):   Corinthians SP · São Paulo FC · Palmeiras SP · Santos SP · Ponte Preta · CA Bragantino · RB Bragantino · Oeste SP · Portuguesa · Botafogo SP · Guarani FC · São Bento
- **Rio de Janeiro** (4):   Botafogo RJ · Flamengo RJ · Fluminense RJ · CR Vasco da Gama
- **Minas Gerais** (4):   Atlético MG · Cruzeiro MG · América MG · Tupi MG
- **Rio Grande do Sul** (3):   Grêmio RS · Internacional Porto Alegre · Brasil RS
- **Paraná** (5):   Atlético PR · Coritiba PR · Londrina EC · Paraná Clube · Operário Ferroviário
- **Santa Catarina** (5):   Figueirense · Chapecoense · Criciúma EC · Avaí FC · Joinvile EC
- **Pernambuco** (3):   Sport Recife · Santa Cruz · Náutico PE
- **Bahia** (2):   EC Vitória · EC Bahia
- **Goiás** (3):   Goiás EC · Atlético GO · Vila Nova GO
- **Ceará** (2):   Ceára SC · Fortaleza
- **Pará** (1):   Paysandu SC
- **Alagoas** (2):   CRB AL · CSA
- **Mato Grosso** (2):   Luverdense EC · Cuiabá
- **Maranhão** (1):   Sampaio Corrêa FC




By Year

- **1911** (1):   Guarani FC
- ? (48):   Corinthians SP · São Paulo FC · Palmeiras SP · Santos SP · Ponte Preta · CA Bragantino · RB Bragantino · Oeste SP · Portuguesa · Botafogo SP · São Bento · Botafogo RJ · Flamengo RJ · Fluminense RJ · CR Vasco da Gama · Atlético MG · Cruzeiro MG · América MG · Tupi MG · Grêmio RS · Internacional Porto Alegre · Brasil RS · Atlético PR · Coritiba PR · Londrina EC · Paraná Clube · Operário Ferroviário · Figueirense · Chapecoense · Criciúma EC · Avaí FC · Joinvile EC · Sport Recife · Santa Cruz · Náutico PE · EC Vitória · EC Bahia · Goiás EC · Atlético GO · Vila Nova GO · Ceára SC · Fortaleza · Paysandu SC · CRB AL · CSA · Luverdense EC · Cuiabá · Sampaio Corrêa FC






By A to Z

- **A** (26): Avai · Avaí FC · America MG · América FC · América MG · Atletico GO · Atletico-MG · Atletico-PR · Atlético GO · Atlético MG · Atlético PR · Atlético/MG · Atlético/PR · AA Ponte Preta · América Mineiro · Atlético Mineiro · Athletico-PR [en] · Avaí Futebol Clube · Atlético Goianiense · Atlético Paranaense · América Futebol Clube · Atlético Clube Goianiense · América Futebol Clube (MG) · Associação Atlética Ponte Preta · Associação Chapecoense de Futebol · Associação Portuguesa de Desportos
- **B** (13): Bahia · Bahia BA · Botafogo · Brasil RS · !! **Bragantino (2)** !! · Botafogo FC · Botafogo FR · Botafogo RJ · Botafogo SP · Brasil de Pelotas · Botafogo Futebol Clube · Botafogo Futebol Clube (SP) · Botafogo de Futebol e Regatas
- **C** (42): CRB · CSA · Ceara · Ceará · CRB AL · Cuiabá · Ceára SC · Coritiba · Criciuma · Criciúma · Cruzeiro · CR Flamengo · Chapecoense · Corinthians · Coritiba FC · Coritiba PR · Criciúma EC · Cruzeiro EC · Cruzeiro MG · CA Bragantino · Chapecoense-SC · Corinthians SP · CR Vasco da Gama · C Atlético Mineiro · Ceará Sporting Club · C Náutico Capibaribe · Cuiabá Esporte Clube · C Atlético Paranaense · Corinthians São Paulo · Clube Atlético Mineiro · Coritiba Football Club · Criciúma Esporte Clube · Cruzeiro Esporte Clube · Clube de Regatas Brasil · Cruzeiro Belo Horizonte · Centro Sportivo Alagoano · Clube Náutico Capibaribe · Clube Atlético Bragantino · Clube Atlético Paranaense · Clube de Regatas do Flamengo · Club de Regatas Vasco da Gama · Club Athletico Paranaense [en]
- **E** (5): EC Bahia · EC Vitória · Esporte Clube Bahia · Esporte Clube Vitória · Esporte Clube São Bento
- **F** (16): Flamengo · FC Santos · Fortaleza · Fluminense · Figueirense · Flamengo RJ · FC São Paulo · Fluminense FC · Fluminense RJ · Figueirense FC · Figueirense SC · Flamengo Rio de Janeiro · Fortaleza Esporte Clube · Fluminense Football Club · Figueirense Futebol Clube · Fluminense Rio de Janeiro
- **G** (16): Goias · Goiás · Gremio · Grêmio · Guarani · Goiás EC · GE Brasil · Grêmio RS · Guarani FC · Grêmio FBPA · Goiás Esporte Clube · Grêmio Porto Alegre · Guarani Futebol Clube · Grêmio Esportivo Brasil · Grêmio Foot-Ball Porto Alegrense · Grêmio Esportivo Brasil de Pelotas
- **I** (3): Internacional · Internacional RS · Internacional Porto Alegre
- **J** (4): Joinvile · Joinville · Joinvile EC · Joinville Esporte Clube
- **L** (6): Londrina · Luverdense · Londrina EC · Luverdense EC · Londrina Esporte Clube · Luverdense Esporte Clube
- **N** (3): Nautico · Náutico · Náutico PE
- **O** (7): Oeste · Oeste FC · Oeste SP · Operário · Oeste Futebol Clube · Operário Ferroviário · Operário Ferroviário Esporte Clube
- **P** (9): Parana · Paysandu · Palmeiras · Portuguesa · Paysandu SC · Ponte Preta · Palmeiras SP · Paraná Clube · Paysandu Sport Club
- **R** (2): RB Bragantino · Red Bull Bragantino
- **S** (27): Sport · Santos · Sport PE · Santos FC · Santos SP · Sao Paulo · São Bento · São Paulo · Santa Cruz · SE Palmeiras · Sport Recife · São Paulo FC · São Paulo SP · Santa Cruz FC · Sampaio Corrêa · SC Internacional · Sampaio Corrêa FC · Santos Futebol Clube · Sport Club do Recife · SE Palmeiras São Paulo · SC Corinthians Paulista · São Paulo Futebol Clube · Santa Cruz Futebol Clube · Sport Club Internacional · Sampaio Corrêa Futebol Clube · Sociedade Esportiva Palmeiras · Sport Club Corinthians Paulista
- **T** (4): Tupi · Tupi FC · Tupi MG · Tupi Football Club
- **V** (11): Vasco · Vitoria · Vitória · Vasco RJ · Vila Nova · Vila Nova FC · Vila Nova GO · Vasco da Gama · Vila Nova de Goias · Vila Nova Futebol Clube · Vasco da Gama Rio de Janeiro




