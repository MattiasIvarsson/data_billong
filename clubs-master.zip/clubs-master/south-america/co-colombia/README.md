6 clubs

- **Millonarios Bogotá** : (3) Millonarios · Millonarios FC · Millonarios Fútbol Club ⇒ (2) ≈Millonarios Bogota≈ · ≈Millonarios Futbol Club≈
- **Independiente Santa Fe** : (2) Santa Fe · Corporación Deportiva Santa Fe ⇒ (1) ≈Corporacion Deportiva Santa Fe≈
- **Atlético Nacional** : (2) At. Nacional · Club Atlético Nacional S.A. ⇒ (2) ≈Atletico Nacional≈ · ≈Club Atletico Nacional S.A.≈
- **Junior de Barranquilla** : (2) Junior · Corporación Popular Deportiva Junior ⇒ (1) ≈Corporacion Popular Deportiva Junior≈
- **Once Caldas** : (1) Corporación Deportiva Once Caldas ⇒ (1) ≈Corporacion Deportiva Once Caldas≈
- **Deportes Tolima**




Alphabet

- **Alphabet Specials** (4):  **á**  **é**  **ó**  **ú** 
  - **á**×1 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ó**×3 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Bogotá** (2): 
  - Millonarios Bogotá  (3) Millonarios · Millonarios FC · Millonarios Fútbol Club
  - Independiente Santa Fe  (2) Santa Fe · Corporación Deportiva Santa Fe
- **Barranquilla** (1): Junior de Barranquilla  (2) Junior · Corporación Popular Deportiva Junior
- **Ibagué** (1): Deportes Tolima 
- **Manizales** (1): Once Caldas  (1) Corporación Deportiva Once Caldas
- **Medellín** (1): Atlético Nacional  (2) At. Nacional · Club Atlético Nacional S.A.




By Region

- **Bogotá†** (2):   Millonarios Bogotá · Independiente Santa Fe
- **Medellín†** (1):   Atlético Nacional
- **Barranquilla†** (1):   Junior de Barranquilla
- **Manizales†** (1):   Once Caldas
- **Ibagué†** (1):   Deportes Tolima




By Year

- ? (6):   Millonarios Bogotá · Independiente Santa Fe · Atlético Nacional · Junior de Barranquilla · Once Caldas · Deportes Tolima






By A to Z

- **A** (2): At. Nacional · Atlético Nacional
- **C** (4): Club Atlético Nacional S.A. · Corporación Deportiva Santa Fe · Corporación Deportiva Once Caldas · Corporación Popular Deportiva Junior
- **D** (1): Deportes Tolima
- **I** (1): Independiente Santa Fe
- **J** (2): Junior · Junior de Barranquilla
- **M** (4): Millonarios · Millonarios FC · Millonarios Bogotá · Millonarios Fútbol Club
- **O** (1): Once Caldas
- **S** (1): Santa Fe




