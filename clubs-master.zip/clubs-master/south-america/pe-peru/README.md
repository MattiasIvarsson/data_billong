6 clubs

- **Alianza Lima** : (1) Club Alianza Lima
- **Sporting Cristal** : (1) Club Sporting Cristal
- **Juan Aurich** : (1) Club Juan Aurich S.A
- **Sport Huancayo**
- **Real Garcilaso** : (1) Asociación Civil Real Atlético Garcilaso ⇒ (1) ≈Asociacion Civil Real Atletico Garcilaso≈
- **Universidad César Vallejo** : (1) Club Deportivo Universidad César Vallejo ⇒ (2) ≈Universidad Cesar Vallejo≈ · ≈Club Deportivo Universidad Cesar Vallejo≈




Alphabet

- **Alphabet Specials** (2):  **é**  **ó** 
  - **é**×3 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Lima** (2): 
  - Alianza Lima  (1) Club Alianza Lima
  - Sporting Cristal  (1) Club Sporting Cristal
- **Chiclayo** (1): Juan Aurich  (1) Club Juan Aurich S.A
- **Cusco** (1): Real Garcilaso  (1) Asociación Civil Real Atlético Garcilaso
- **Huancayo** (1): Sport Huancayo 
- **Trujillo** (1): Universidad César Vallejo  (1) Club Deportivo Universidad César Vallejo




By Region

- **Lima†** (2):   Alianza Lima · Sporting Cristal
- **Chiclayo†** (1):   Juan Aurich
- **Huancayo†** (1):   Sport Huancayo
- **Cusco†** (1):   Real Garcilaso
- **Trujillo†** (1):   Universidad César Vallejo




By Year

- ? (6):   Alianza Lima · Sporting Cristal · Juan Aurich · Sport Huancayo · Real Garcilaso · Universidad César Vallejo






By A to Z

- **A** (2): Alianza Lima · Asociación Civil Real Atlético Garcilaso
- **C** (4): Club Alianza Lima · Club Juan Aurich S.A · Club Sporting Cristal · Club Deportivo Universidad César Vallejo
- **J** (1): Juan Aurich
- **R** (1): Real Garcilaso
- **S** (2): Sport Huancayo · Sporting Cristal
- **U** (1): Universidad César Vallejo




