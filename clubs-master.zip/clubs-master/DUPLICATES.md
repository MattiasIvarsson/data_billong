Duplicates

- **2** matching clubs for **`valencia`**:
  - Valencia FC, Léogâne, Haiti (ht)
  - Valencia CF, Valencia, Spain (es)
- **2** matching clubs for **`olimpia`**:
  - CD Olimpia, city:tegucigalpa, Honduras (hn)
  - Club Olimpia, Asunción, Paraguay (py)
- **2** matching clubs for **`apollon`**:
  - Apollon Limassol FC, , Cyprus (cy)
  - Apollon Smyrnis FC, Athens, Greece (gr)
- **2** matching clubs for **`arsenalfc`**:
  - Arsenal FC, London, England (eng)
  - Arsenal de Sarandí, Sarandí, Argentina (ar)
- **3** matching clubs for **`arsenal`**:
  - Arsenal FC, London, England (eng)
  - Arsenal Tula, Tula, Russia (ru)
  - Arsenal de Sarandí, Sarandí, Argentina (ar)
- **2** matching clubs for **`liverpoolfc`**:
  - Liverpool FC, Liverpool, England (eng)
  - Liverpool Montevideo, Montevideo, Uruguay (uy)
- **2** matching clubs for **`liverpool`**:
  - Liverpool FC, Liverpool, England (eng)
  - Liverpool Montevideo, Montevideo, Uruguay (uy)
- **2** matching clubs for **`hibernians`**:
  - Hibernians FC, , Malta (mt)
  - Hibernian FC, Edinburgh, Scotland (sco)
- **3** matching clubs for **`nacional`**:
  - CD Nacional Madeira, Funchal, Portugal (pt)
  - Club Nacional, Asunción, Paraguay (py)
  - Nacional de Montevideo, Montevideo, Uruguay (uy)
- **2** matching clubs for **`barcelona`**:
  - FC Barcelona, Barcelona, Spain (es)
  - Barcelona Guayaquil, Guayaquil, Ecuador (ec)
- **2** matching clubs for **`cdguadalajara`**:
  - CD Guadalajara, Guadalajara, Spain (es)
  - CD Guadalajara Chivas, Guadalajara, Mexico (mx)
- **2** matching clubs for **`sanjose`**:
  - San Jose Earthquakes, San Jose, United States (us)
  - Club Deportivo San José, Oruro, Bolivia (bo)
- **2** matching clubs for **`riverplate`**:
  - River Plate, Buenos Aires, Argentina (ar)
  - CA River Plate, Montevideo, Uruguay (uy)
- **2** matching clubs for **`clubatléticoriverplate`**:
  - River Plate, Buenos Aires, Argentina (ar)
  - CA River Plate, Montevideo, Uruguay (uy)
- **2** matching clubs for **`clubatleticoriverplate`**:
  - River Plate, Buenos Aires, Argentina (ar)
  - CA River Plate, Montevideo, Uruguay (uy)
- **2** matching clubs for **`racing`**:
  - Racing Club, Avellaneda, Argentina (ar)
  - Racing CM, Montevideo, Uruguay (uy)
- **2** matching clubs for **`estudiantes`**:
  - Estudiantes LP, La Plata, Argentina (ar)
  - Estudiantes de Mérida, Mérida, Venezuela (ve)
- **2** matching clubs for **`clubatléticosanmartín`**:
  - San Martín, San Juan, Argentina (ar)
  - San Martín de Tucumán, San Miguel de Tucumán, Argentina (ar)
- **2** matching clubs for **`clubatleticosanmartin`**:
  - San Martín, San Juan, Argentina (ar)
  - San Martín de Tucumán, San Miguel de Tucumán, Argentina (ar)
- **2** matching clubs for **`bragantino`**:
  - CA Bragantino, Bragança Paulista, Brazil (br)
  - RB Bragantino, Bragança Paulista, Brazil (br)




Club Name Duplicates

**Egypt (eg)**

- **Al Ahly**, Cairo (1):
  - `alahly` (2): Al Ahly · Al-Ahly




**Morocco (ma)**





**China (cn)**

- **Tianjin TEDA**, Tianjin (1):
  - `tianjinteda` (2): Tianjin TEDA · Tianjin Teda




**Japan (jp)**





**Kazakhstan (kz)**





**South Korea (kr)**

- **Busan I'Park**, city:busan (1):
  - `busanipark` (2): Busan I'Park · Busan IPark




**Haiti (ht)**





**Puerto Rico (pr)**





**Trinidad and Tobago (tt)**





**Costa Rica (cr)**





**Guatemala (gt)**





**Honduras (hn)**





**Nicaragua (ni)**





**Panama (pa)**





**El Salvador (sv)**





**Albania (al)**





**Andorra (ad)**





**Armenia (am)**





**Austria (at)**





**Azerbaijan (az)**





**Bosnia and Herzegovina (ba)**





**Belgium (be)**

- **RSC Anderlecht**, Brussels (1):
  - `rscanderlecht` (2): RSC Anderlecht · R.S.C. Anderlecht
- **KVC Westerlo**, Westerlo (1):
  - `kvcwesterlo` (2): KVC Westerlo · K.V.C. Westerlo
- **KRC Genk**, Genk (1):
  - `krcgenk` (2): KRC Genk · K.R.C. Genk
- **KAA Gent**, Gent (1):
  - `kaagent` (2): KAA Gent · K.A.A. Gent
- **Cercle Brugge**, Brugge (1):
  - `cerclebruggeksv` (2): Cercle Brugge KSV · Cercle Brugge K.S.V.
- **KV Kortrijk**, Kortrijk (1):
  - `kvkortrijk` (2): KV Kortrijk · K.V. Kortrijk
- **KV Oostende**, Oostende (1):
  - `kvoostende` (2): KV Oostende · K.V. Oostende
- **SV Zulte Waregem**, Waregem (1):
  - `svzultewaregem` (2): SV Zulte Waregem · S.V. Zulte Waregem
- **Royal Excel Mouscron**, Mouscron (1):
  - `mouscronperuwelz` (2): **Mouscron-Peruwelz** · **Mouscron-Peruwelz**
- **Standard Liège**, Liège (1):
  - `standardliege` (2): **Standard Liege** · **Standard Liege**




**Bulgaria (bg)**

- **PFC CSKA Sofia**, Sofia (2):
  - `pfccskasofia` (2): PFC CSKA Sofia · PFC CSKA-Sofia
  - `cskasofia` (2): CSKA Sofia · CSKA-Sofia




**Belarus (by)**

- **FC BATE Borisov**, Barysaw (1):
  - `bateborisov` (2): BATE Borisov · Bate Borisov




**Cyprus (cy)**





**Czech Republic (cz)**





**Denmark (dk)**

- **FC København**, København (1):
  - `kobenhavn` (2): **Kobenhavn** · **Kobenhavn**
- **Brøndby IF**, Brøndbyvester (2):
  - `brondby` (2): **Brondby** · **Brondby**
  - `brondbyif` (2): **Brondby IF** · **Brondby IF**
- **FC Nordsjælland**, Farum (1):
  - `nordsjaelland` (2): **Nordsjaelland** · **Nordsjaelland**
- **FC Helsingør**, Helsingør (1):
  - `helsingor` (2): **Helsingor** · **Helsingor**
- **Sønderjysk Elitesport**, Haderslev (1):
  - `sonderjyske` (2): Sonderjyske · SonderjyskE




**Estonia (ee)**





**England (eng)**

- **Manchester United FC**, Manchester (2):
  - `manunited` (2): Man United · Man. United
  - `manchesteru` (2): Manchester U. · Manchester U
- **Manchester City FC**, Manchester (1):
  - `mancity` (2): Man City · Man. City
- **Norwich City FC**, Norwich (1):
  - `norwichcityfc` (2): Norwich City FC · Norwich City F.C.
- **Watford FC**, Watford (1):
  - `watfordfc` (2): Watford FC · Watford F.C.
- **AFC Bournemouth**, Bournemouth (1):
  - `afcbournemouth` (2): AFC Bournemouth · A.F.C. Bournemouth
- **Accrington FC (1878-1896)**, Accrington (1):
  - `accringtonfc` (2): Accrington FC (1878-1896) · Accrington F.C.




**Finland (fi)**

- **Myllykosken Pallo -47**, Myllykoski (2):
  - `myllykoskenpallo47` (2): Myllykosken Pallo -47 · Myllykosken Pallo-47
  - `mypa` (2): MYPA · MyPa
- **JJK Jyväskylä**, Jyväskylä (1):
  - `jjkjyvaskyla` (2): **JJK Jyvaskyla** · **JJK Jyvaskyla**




**Faroe Islands (fo)**

- **Víkingur**,  (1):
  - `vikingur` (2): **Vikingur** · **Vikingur**




**France (fr)**

- **Paris Saint-Germain**, Paris (1):
  - `parissaintgermain` (2): Paris Saint-Germain · Paris Saint Germain
- **AS Saint-Étienne**, Saint-Étienne (2):
  - `stetienne` (2): St Etienne · St-Etienne
  - `assaintetienne` (2): **AS Saint-Etienne** · **AS Saint-Etienne**
- **AS Nancy Lorraine**, Nancy (1):
  - `asnancylorraine` (2): AS Nancy Lorraine · AS Nancy-Lorraine
- **US Quevilly-Rouen Métropole**, Petit-Quevilly (1):
  - `quevillyrouen` (2): Quevilly Rouen · Quevilly-Rouen
- **AC Arles-Avignon**, Avignon (1):
  - `acarlesavignon` (2): AC Arles-Avignon · AC Arles Avignon
- **Évian TG FC**, Thonon-les-Bains (2):
  - `évianthonongaillardfc` (2): Évian Thonon Gaillard FC · Évian Thonon-Gaillard FC
  - `evianthonongaillardfc` (2): Evian Thonon Gaillard FC · Evian Thonon-Gaillard FC




**Georgia (ge)**





**Germany (de)**

- **Bor. Mönchengladbach**, Mönchengladbach (2):
  - `borussiamonchengladbach` (2): **Borussia Monchengladbach** · **Borussia Monchengladbach**
  - `bormoenchengladbach` (2): **Bor. Moenchengladbach** · **Bor. Moenchengladbach**
- **Rot-Weiß Oberhausen**, Oberhausen (1):
  - `rotweissoberhausen` (2): **Rot-Weiss Oberhausen** · **Rot-Weiss Oberhausen**
- **1. FC Saarbrücken**, Saarbrücken (2):
  - `saarbrucken` (2): **Saarbrucken** · **Saarbrucken**
  - `1fcsaarbruecken` (2): **1. FC Saarbruecken** · **1. FC Saarbruecken**
- **Blau-Weiß 90 Berlin (-1992)**, Berlin (1):
  - `blauweiss90berlin` (2): **Blau-Weiss 90 Berlin** · **Blau-Weiss 90 Berlin**
- **FC St. Pauli**, Hamburg (1):
  - `stpauli` (2): St Pauli · St. Pauli
- **VfB Lübeck**, Lübeck (1):
  - `lubeck` (2): **Lubeck** · **Lubeck**




**Gibraltar (gi)**





**Greece (gr)**





**Croatia (hr)**





**Hungary (hu)**

- **Ferencvárosi TC**, Budapest (1):
  - `ferencvaros` (2): **Ferencvaros** · **Ferencvaros**




**Ireland (ie)**

- **Bohemian F.C.**, Dublin (1):
  - `bohemianfc` (2): Bohemian F.C. · Bohemian FC
- **St Patrick's Athletic F.C.**, Dublin (1):
  - `stpatricks` (2): St Patrick's · St. Patricks
- **University College Dublin A.F.C.**, Dublin (1):
  - `universitycollegedublinafc` (2): University College Dublin A.F.C. · University College Dublin AFC
- **Cork City F.C.**, Cork (1):
  - `corkcityfc` (2): Cork City F.C. · Cork City FC
- **Drogheda United F.C.**, Drogheda (1):
  - `droghedaunitedfc` (2): Drogheda United F.C. · Drogheda United FC
- **Dundalk F.C.**, Dundalk (1):
  - `dundalkfc` (2): Dundalk F.C. · Dundalk FC
- **Sligo Rovers F.C.**, Sligo (1):
  - `sligoroversfc` (2): Sligo Rovers F.C. · Sligo Rovers FC




**Iceland (is)**

- **KR Reykjavík**, Reykjavík (1):
  - `krreykjavik` (2): **KR Reykjavik** · **KR Reykjavik**
- **ÍA Akranes**, Akranes (1):
  - `iaakranes` (2): **IA Akranes** · **IA Akranes**




**Italy (it)**

- **Hellas Verona FC**, Verona (1):
  - `hellasveronafc` (2): Hellas Verona FC · Hellas Verona F.C.
- **US Sassuolo Calcio**, Sassuolo (1):
  - `ussassuolocalcio` (2): US Sassuolo Calcio · U.S. Sassuolo Calcio
- **SPAL**, Ferrara (1):
  - `spal` (2): SPAL · Spal
- **AS Livorno Calcio**, Livorno (1):
  - `aslivornocalcio` (2): AS Livorno Calcio · A.S. Livorno Calcio




**Kosovo (xk)**





**Liechtenstein (li)**





**Lithuania (lt)**





**Luxembourg (lu)**





**Latvia (lv)**





**Moldova (md)**





**Montenegro (me)**





**Macedonia (mk)**

- **FK Rabotnički**,  (2):
  - `rabotnicki` (2): **Rabotnicki** · **Rabotnicki**
  - `fkrabotnicki` (2): **FK Rabotnicki** · **FK Rabotnicki**




**Monaco (mc)**





**Malta (mt)**





**Netherlands (nl)**

- **VVV Venlo**, Venlo (1):
  - `vvvvenlo` (2): VVV Venlo · VVV-Venlo




**Northern Ireland (nir)**

- **Derry City F.C.**, Derry (1):
  - `derrycityfc` (2): Derry City F.C. · Derry City FC




**Norway (no)**

- **Vålerenga Fotball**, Oslo (1):
  - `valerenga` (2): **Valerenga** · **Valerenga**
- **Tromsø IL**, Tromsø (1):
  - `tromso` (2): **Tromso** · **Tromso**
- **Strømsgodset IF**, Drammen (1):
  - `stromsgodset` (2): **Stromsgodset** · **Stromsgodset**
- **Lillestrøm SK**, Lillestrøm (1):
  - `lillestrom` (2): **Lillestrom** · **Lillestrom**
- **Stabæk**, Bærum (1):
  - `stabaek` (2): **Stabaek** · **Stabaek**
- **Mjøndalen IF**, Mjøndalen (1):
  - `mjondalen` (2): **Mjondalen** · **Mjondalen**
- **Bodø/Glimt**, Bodø (1):
  - `bodoglimt` (2): **Bodo/Glimt** · **Bodo/Glimt**
- **Hønefoss BK**, Hønefoss (1):
  - `honefoss` (2): **Honefoss** · **Honefoss**




**Poland (pl)**





**Portugal (pt)**

- **CS Marítimo**, Funchal (1):
  - `maritimo` (2): **Maritimo** · **Maritimo**
- **FC Paços de Ferreira**, Paços de Ferreira (1):
  - `pacosferreira` (2): **Pacos Ferreira** · **Pacos Ferreira**
- **Académica de Coimbra**, Coimbra (1):
  - `academica` (2): **Academica** · **Academica**




**Romania (ro)**

- **Steaua București**, București (2):
  - `steauabucuresti` (2): **Steaua Bucuresti** · **Steaua Bucuresti**
  - `fcsteauabucuresti` (2): **FC Steaua Bucuresti** · **FC Steaua Bucuresti**
- **Dinamo București**, București (2):
  - `dinamobucuresti` (3): **Dinamo Bucuresti** · **Dinamo Bucuresti** · **Dinamo Bucuresti**
  - `fcdinamobucuresti` (2): **FC Dinamo Bucuresti** · **FC Dinamo Bucuresti**
- **Rapid București**, București (2):
  - `fcrapidbucuresti` (2): **FC Rapid Bucuresti** · **FC Rapid Bucuresti**
  - `rapidbucuresti` (2): **Rapid Bucuresti** · **Rapid Bucuresti**
- **Daco-Getica București**, București (1):
  - `dacogeticabucuresti` (2): **Daco-Getica Bucuresti** · **Daco-Getica Bucuresti**
- **U Cluj**, Cluj (1):
  - `ucluj` (2): U Cluj · U. Cluj
- **Ceahlăul Piatra Neamț**, Piatra Neamț (1):
  - `ceahlaulpiatraneamt` (2): **Ceahlaul Piatra Neamt** · **Ceahlaul Piatra Neamt**
- **Gaz Metan Mediaș**, Mediaș (1):
  - `gazmetanmedias` (2): **Gaz Metan Medias** · **Gaz Metan Medias**
- **Gloria Bistrița**, Bistrița (1):
  - `gloriabistrita` (2): **Gloria Bistrita** · **Gloria Bistrita**
- **FC Petrolul Ploiești**, Ploiești (2):
  - `petrolulploiesti` (2): **Petrolul Ploiesti** · **Petrolul Ploiesti**
  - `fcpetrolulploiesti` (2): **FC Petrolul Ploiesti** · **FC Petrolul Ploiesti**
- **FC Botoșani**, Botoșani (1):
  - `fcbotosani` (2): **FC Botosani** · **FC Botosani**
- **Oțelul Galați**, Galați (1):
  - `otelul` (2): **Otelul** · **Otelul**
- **FC Politehnica Iași**, Iași (1):
  - `poliiasi` (2): **Poli Iasi** · **Poli Iasi**
- **Târgu Mureș**, Târgu Mureș (2):
  - `targumures` (2): **Targu Mures** · **Targu Mures**
  - `asatargumures` (2): **ASA Targu Mures** · **ASA Targu Mures**




**Serbia (rs)**

- **Red Star Belgrade**, Belgrade (1):
  - `crvenazvezda` (2): Crvena Zvezda · Crvena zvezda




**Russia (ru)**

- **FC Sibir Novosibirsk**, Novosibirsk (1):
  - `sibir` (2): Sibir' · Sibir
- **PFC Krylya Sovetov Samara**, Samara (1):
  - `kryliasovetov` (2): Krylia Sovetov · Kryl'ia Sovetov
- **FC Kuban**, Krasnodar (1):
  - `kuban` (2): Kuban · Kuban'
- **Tom Tomsk**, Tomsk (1):
  - `tom` (2): Tom · Tom'




**Scotland (sco)**

- **Queen's Park**, Glasgow (1):
  - `queenspark` (2): Queen's Park · Queens Park
- **St Johnstone FC**, Perth (1):
  - `stjohnstone` (2): St Johnstone · St. Johnstone




**Sweden (se)**

- **Djurgårdens IF**, Stockholm (1):
  - `djurgarden` (2): **Djurgarden** · **Djurgarden**
- **IFK Göteborg**, Göteborg (2):
  - `goteborg` (2): **Goteborg** · **Goteborg**
  - `ifkgoteborg` (2): **IFK Goteborg** · **IFK Goteborg**
- **GAIS**, Göteborg (1):
  - `gais` (2): GAIS · Gais
- **BK Häcken**, Göteborg (1):
  - `hacken` (2): **Hacken** · **Hacken**
- **Malmö FF**, Malmö (1):
  - `malmoff` (2): **Malmo FF** · **Malmo FF**
- **Örebro SK**, Örebro (1):
  - `orebro` (2): **Orebro** · **Orebro**
- **IFK Norrköping**, Norrköping (1):
  - `norrkoping` (2): **Norrkoping** · **Norrkoping**




**Slovenia (si)**





**Slovakia (sk)**

- **ŠK Slovan Bratislava**, Bratislava (1):
  - `skslovanbratislava` (2): **SK Slovan Bratislava** · **SK Slovan Bratislava**




**San Marino (sm)**

- **AC Juvenes-Dogana**,  (1):
  - `acjuvenesdogana` (2): AC Juvenes-Dogana · AC Juvenes/Dogana




**Spain (es)**





**Switzerland (ch)**

- **Grasshoppers Zürich**, Zürich (1):
  - `grasshopperszurich` (2): **Grasshoppers Zurich** · **Grasshoppers Zurich**
- **FC Zürich**, Zürich (2):
  - `zurich` (2): **Zurich** · **Zurich**
  - `fczurich` (2): **FC Zurich** · **FC Zurich**




**Turkey (tr)**

- **Galatasaray İstanbul AŞ**, İstanbul (1):
  - `galatasarayistanbul` (2): Galatasaray İstanbul · Galatasaray Istanbul
- **İstanbulspor**, İstanbul (1):
  - `istanbulspor` (2): İstanbulspor · Istanbulspor
- **Mersin İdmanyurdu**, Mersin (1):
  - `mersinidmanyurdu` (4): Mersin İdmanyurdu · Mersin İdman Yurdu · Mersin Idmanyurdu · Mersin Idman Yurdu




**Ukraine (ua)**





**Wales (wal)**





**Israel (il)**





**Canada (ca)**





**Mexico (mx)**





**United States (us)**

- **D.C. United**, Washington (1):
  - `dcunited` (2): D.C. United · DC United




**Australia (au)**





**New Zealand (nz)**





**Argentina (ar)**

- **Vélez Sarsfield**, Buenos Aires (1):
  - `velezsarsfield` (2): **Velez Sarsfield** · **Velez Sarsfield**
- **Huracán**, Buenos Aires (1):
  - `huracan` (2): **Huracan** · **Huracan**
- **CA Lanús**, Lanús (1):
  - `lanus` (2): **Lanus** · **Lanus**
- **Estudiantes LP**, La Plata (1):
  - `estudianteslp` (2): Estudiantes LP · Estudiantes L.P.
- **Olimpo Bahía Blanca**, Bahía Blanca (1):
  - `olimpobahiablanca` (2): **Olimpo Bahia Blanca** · **Olimpo Bahia Blanca**
- **Sarmiento Junín**, Junín (1):
  - `sarmientojunin` (2): **Sarmiento Junin** · **Sarmiento Junin**
- **Colón Santa Fe**, Santa Fe (1):
  - `colonsantafe` (2): Colon Santa FE · Colon Santa Fe
- **Newell's Old Boys**, Rosario (1):
  - `newellsoldboys` (2): Newell's Old Boys · Newells Old Boys




**Bolivia (bo)**





**Brazil (br)**

- **São Paulo FC**, São Paulo (1):
  - `saopaulo` (2): **Sao Paulo** · **Sao Paulo**
- **Atlético MG**, Belo Horizonte (2):
  - `atléticomg` (2): Atlético MG · Atlético/MG
  - `atleticomg` (3): Atletico-MG · Atletico MG · Atletico/MG
- **América MG**, Belo Horizonte (1):
  - `americamg` (2): **America MG** · **America MG**
- **Grêmio RS**, Porto Alegre (1):
  - `gremio` (2): **Gremio** · **Gremio**
- **Atlético PR**, Curitiba (2):
  - `atléticopr` (2): Atlético PR · Atlético/PR
  - `atleticopr` (3): Atletico-PR · Atletico PR · Atletico/PR
- **Criciúma EC**, Criciúma (1):
  - `criciuma` (2): **Criciuma** · **Criciuma**
- **Náutico PE**, Recife (1):
  - `nautico` (2): **Nautico** · **Nautico**
- **EC Vitória**, Salvador (1):
  - `vitoria` (2): **Vitoria** · **Vitoria**
- **Goiás EC**, Goiânia (1):
  - `goias` (2): **Goias** · **Goias**
- **Atlético GO**, Goiânia (1):
  - `atleticogo` (2): **Atletico GO** · **Atletico GO**
- **Ceára SC**, Fortaleza (1):
  - `ceara` (2): **Ceara** · **Ceara**




**Chile (cl)**





**Colombia (co)**





**Ecuador (ec)**





**Guyana (gy)**





**Peru (pe)**





**Paraguay (py)**





**Uruguay (uy)**





**Venezuela (ve)**









