12 clubs

- **ŠK Slovan Bratislava** : (2) Slovan Bratislava · SK Slovan Bratislava ⇒ (1) ≈SK Slovan Bratislava≈
- **MŠK Žilina** : (1) Žilina ⇒ (2) ≈Zilina≈ · ≈MSK Zilina≈
- **FC Spartak Trnava** : (1) Spartak Trnava
- **FK Senica** : (1) Senica
- **MFK Košice** : (1) Košice ⇒ (2) ≈Kosice≈ · ≈MFK Kosice≈
- **Dukla Banská Bystrica** : (1) Banská Bystrica ⇒ (2) ≈Banska Bystrica≈ · ≈Dukla Banska Bystrica≈
- **FC Nitra** : (1) Nitra
- **MFK Petržalka** ⇒ (1) ≈MFK Petrzalka≈
- **AS Trenčín** : (1) Trenčín ⇒ (2) ≈Trencin≈ · ≈AS Trencin≈
- **FC DAC 1904 Dunajská Streda** : (1) Dunajská Streda ⇒ (2) ≈Dunajska Streda≈ · ≈FC DAC 1904 Dunajska Streda≈
- **MFK Ružomberok** : (1) Ružomberok ⇒ (2) ≈Ruzomberok≈ · ≈MFK Ruzomberok≈
- **TJ Spartak Myjava** : (1) Spartak Myjava




Alphabet

- **Alphabet Specials** (7):  **á**  **í**  **č**  **Š**  **š**  **Ž**  **ž** 
  - **á**×4 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **í**×2 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **č**×2 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **Š**×2 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **š**×2 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s
  - **Ž**×2 U+017D (381) - LATIN CAPITAL LETTER Z WITH CARON ⇒ Z
  - **ž**×3 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates

- **ŠK Slovan Bratislava**, Bratislava (1):
  - `skslovanbratislava` (2): **SK Slovan Bratislava** · **SK Slovan Bratislava**




By City

- **Bratislava** (1): ŠK Slovan Bratislava  (2) Slovan Bratislava · SK Slovan Bratislava
- ? (11): 
  - MŠK Žilina  (1) Žilina
  - FC Spartak Trnava  (1) Spartak Trnava
  - FK Senica  (1) Senica
  - MFK Košice  (1) Košice
  - Dukla Banská Bystrica  (1) Banská Bystrica
  - FC Nitra  (1) Nitra
  - MFK Petržalka 
  - AS Trenčín  (1) Trenčín
  - FC DAC 1904 Dunajská Streda  (1) Dunajská Streda
  - MFK Ružomberok  (1) Ružomberok
  - TJ Spartak Myjava  (1) Spartak Myjava




By Region

- **Bratislava†** (1):   ŠK Slovan Bratislava




By Year

- ? (12):   ŠK Slovan Bratislava · MŠK Žilina · FC Spartak Trnava · FK Senica · MFK Košice · Dukla Banská Bystrica · FC Nitra · MFK Petržalka · AS Trenčín · FC DAC 1904 Dunajská Streda · MFK Ružomberok · TJ Spartak Myjava






By A to Z

- **A** (1): AS Trenčín
- **B** (1): Banská Bystrica
- **D** (2): Dunajská Streda · Dukla Banská Bystrica
- **F** (4): FC Nitra · FK Senica · FC Spartak Trnava · FC DAC 1904 Dunajská Streda
- **K** (1): Košice
- **M** (4): MFK Košice · MŠK Žilina · MFK Petržalka · MFK Ružomberok
- **N** (1): Nitra
- **R** (1): Ružomberok
- **S** (5): Senica · Spartak Myjava · Spartak Trnava · Slovan Bratislava · SK Slovan Bratislava
- **T** (2): Trenčín · TJ Spartak Myjava
- **Š** (1): ŠK Slovan Bratislava
- **Ž** (1): Žilina




