7 clubs

- **HB Tórshavn** : (3) HB · Havnar Bóltfelag · Havnar Bóltfelag Tórshavn ⇒ (3) ≈HB Torshavn≈ · ≈Havnar Boltfelag≈ · ≈Havnar Boltfelag Torshavn≈
- **B36 Tórshavn** : (1) B36 ⇒ (1) ≈B36 Torshavn≈
- **EB/Streymur**
- **NSÍ Runavík** ⇒ (1) ≈NSI Runavik≈
- **Víkingur** : (1) Vikingur ⇒ (1) ≈Vikingur≈
- **ÍF Fuglafjørdur** ⇒ (1) ≈IF Fuglafjordur≈
- **KÍ Klaksvík** ⇒ (1) ≈KI Klaksvik≈




Alphabet

- **Alphabet Specials** (4):  **Í**  **í**  **ó**  **ø** 
  - **Í**×3 U+00CD (205) - LATIN CAPITAL LETTER I WITH ACUTE ⇒ I
  - **í**×3 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×5 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ø**×1 U+00F8 (248) - LATIN SMALL LETTER O WITH STROKE ⇒ o




Duplicates

- **Víkingur**,  (1):
  - `vikingur` (2): **Vikingur** · **Vikingur**




By City

- ? (7): 
  - HB Tórshavn  (3) Havnar Bóltfelag · Havnar Bóltfelag Tórshavn · HB
  - B36 Tórshavn  (1) B36
  - EB/Streymur 
  - NSÍ Runavík 
  - Víkingur  (1) Vikingur
  - ÍF Fuglafjørdur 
  - KÍ Klaksvík 




By Region





By Year

- ? (7):   HB Tórshavn · B36 Tórshavn · EB/Streymur · NSÍ Runavík · Víkingur · ÍF Fuglafjørdur · KÍ Klaksvík






By A to Z

- **B** (2): B36 · B36 Tórshavn
- **E** (1): EB/Streymur
- **H** (4): HB · HB Tórshavn · Havnar Bóltfelag · Havnar Bóltfelag Tórshavn
- **K** (1): KÍ Klaksvík
- **N** (1): NSÍ Runavík
- **V** (2): Vikingur · Víkingur
- **Í** (1): ÍF Fuglafjørdur




