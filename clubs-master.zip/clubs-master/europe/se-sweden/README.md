28 clubs

- **AIK** : (2) AIK Fotboll · Allmänna Idrottsklubben ⇒ (2) ≈Allmanna Idrottsklubben≈ · ≈Allmaenna Idrottsklubben≈
- **IF Brommapojkarna** : (1) Brommapojkarna
- **Djurgårdens IF** : (2) Djurgården · Djurgarden ⇒ (2) ≈Djurgarden≈ · ≈Djurgardens IF≈
- **Hammarby IF** : (1) Hammarby
- **IFK Göteborg** : (4) Göteborg · Goteborg · IFK Goteborg · Idrottsföreningen Kamraterna Göteborg ⇒ (6) ≈Goteborg≈ · ≈Goeteborg≈ · ≈IFK Goteborg≈ · ≈IFK Goeteborg≈ · ≈Idrottsforeningen Kamraterna Goteborg≈ · ≈Idrottsfoereningen Kamraterna Goeteborg≈
- **GAIS** : (2) Gais · Göteborgs Atlet- och Idrottssällskap ⇒ (2) ≈Goteborgs Atlet- och Idrottssallskap≈ · ≈Goeteborgs Atlet- och Idrottssaellskap≈
- **BK Häcken** : (3) Hacken · Häcken · Bollklubben Häcken ⇒ (6) ≈Hacken≈ · ≈Haecken≈ · ≈BK Hacken≈ · ≈BK Haecken≈ · ≈Bollklubben Hacken≈ · ≈Bollklubben Haecken≈
- **Malmö FF** : (3) Malmö · Malmo FF · Malmö Fotbollförening ⇒ (6) ≈Malmo≈ · ≈Malmoe≈ · ≈Malmo FF≈ · ≈Malmoe FF≈ · ≈Malmo Fotbollforening≈ · ≈Malmoe Fotbollfoerening≈
- **IF Elfsborg** : (1) Elfsborg
- **Helsingborgs IF** : (1) Helsingborg
- **Kalmar FF** : (1) Kalmar
- **Örebro SK** : (3) Örebro · Orebro · Örebro Sportklubb ⇒ (6) ≈Orebro≈ · ≈OErebro≈ · ≈Orebro SK≈ · ≈OErebro SK≈ · ≈Orebro Sportklubb≈ · ≈OErebro Sportklubb≈
- **Gefle IF** : (1) Gefle
- **AFC Eskilstuna**
- **Mjällby AIF** : (1) Mjallby ⇒ (2) ≈Mjallby AIF≈ · ≈Mjaellby AIF≈
- **Åtvidabergs FF** : (5) ÅFF · Åtvid · Åtvidaberg · Atvidabergs · Åtvidabergs Fotbollförening ⇒ (6) ≈AFF≈ · ≈Atvid≈ · ≈Atvidaberg≈ · ≈Atvidabergs FF≈ · ≈Atvidabergs Fotbollforening≈ · ≈Åtvidabergs Fotbollfoerening≈
- **Dalkurd FF** : (1) Dalkurd
- **IK Sirius** : (1) Sirius
- **Falkenbergs FF** : (1) Falkenbergs
- **Halmstads BK** : (2) Halmstad · Halmstads Bollklubb
- **Jönköpings Södra IF** : (1) Jonkopings ⇒ (2) ≈Jonkopings Sodra IF≈ · ≈Joenkoepings Soedra IF≈
- **Ljungskile SK** : (1) Ljungskile
- **IFK Norrköping** : (3) Norrköping · Norrkoping · IFK Norrköping FK ⇒ (6) ≈Norrkoping≈ · ≈Norrkoeping≈ · ≈IFK Norrkoping≈ · ≈IFK Norrkoeping≈ · ≈IFK Norrkoping FK≈ · ≈IFK Norrkoeping FK≈
- **Östers IF** : (1) Osters ⇒ (2) ≈Osters IF≈ · ≈OEsters IF≈
- **Östersunds FK** : (2) Östersund · Ostersunds ⇒ (4) ≈Ostersund≈ · ≈OEstersund≈ · ≈Ostersunds FK≈ · ≈OEstersunds FK≈
- **GIF Sundsvall** : (1) Sundsvall
- **Syrianska FC** : (1) Syrianska
- **Trelleborgs FF** : (1) Trelleborgs




Alphabet

- **Alphabet Specials** (5):  **Å**  **Ö**  **ä**  **å**  **ö** 
  - **Å**×5 U+00C5 (197) - LATIN CAPITAL LETTER A WITH RING ABOVE ⇒ A
  - **Ö**×6 U+00D6 (214) - LATIN CAPITAL LETTER O WITH DIAERESIS ⇒ O•OE
  - **ä**×6 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **å**×2 U+00E5 (229) - LATIN SMALL LETTER A WITH RING ABOVE ⇒ a
  - **ö**×16 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe




Duplicates

- **Djurgårdens IF**, Stockholm (1):
  - `djurgarden` (2): **Djurgarden** · **Djurgarden**
- **IFK Göteborg**, Göteborg (2):
  - `goteborg` (2): **Goteborg** · **Goteborg**
  - `ifkgoteborg` (2): **IFK Goteborg** · **IFK Goteborg**
- **GAIS**, Göteborg (1):
  - `gais` (2): GAIS · Gais
- **BK Häcken**, Göteborg (1):
  - `hacken` (2): **Hacken** · **Hacken**
- **Malmö FF**, Malmö (1):
  - `malmoff` (2): **Malmo FF** · **Malmo FF**
- **Örebro SK**, Örebro (1):
  - `orebro` (2): **Orebro** · **Orebro**
- **IFK Norrköping**, Norrköping (1):
  - `norrkoping` (2): **Norrkoping** · **Norrkoping**




By City

- **Stockholm** (4): 
  - AIK  (2) AIK Fotboll · Allmänna Idrottsklubben
  - IF Brommapojkarna  (1) Brommapojkarna
  - Djurgårdens IF  (2) Djurgården · Djurgarden
  - Hammarby IF  (1) Hammarby
- **Göteborg** (3): 
  - IFK Göteborg  (4) Göteborg · Goteborg · IFK Goteborg · Idrottsföreningen Kamraterna Göteborg
  - GAIS  (2) Gais · Göteborgs Atlet- och Idrottssällskap
  - BK Häcken  (3) Hacken · Häcken · Bollklubben Häcken
- **Uppsala** (2): 
  - Dalkurd FF  (1) Dalkurd
  - IK Sirius  (1) Sirius
- **Borås** (1): IF Elfsborg  (1) Elfsborg
- **Eskilstuna** (1): AFC Eskilstuna 
- **Falkenberg** (1): Falkenbergs FF  (1) Falkenbergs
- **Gävle** (1): Gefle IF  (1) Gefle
- **Halmstad** (1): Halmstads BK  (2) Halmstad · Halmstads Bollklubb
- **Helsingborg** (1): Helsingborgs IF  (1) Helsingborg
- **Jönköping** (1): Jönköpings Södra IF  (1) Jonkopings
- **Kalmar** (1): Kalmar FF  (1) Kalmar
- **Ljungskile** (1): Ljungskile SK  (1) Ljungskile
- **Malmö** (1): Malmö FF  (3) Malmö · Malmo FF · Malmö Fotbollförening
- **Mjällby** (1): Mjällby AIF  (1) Mjallby
- **Norrköping** (1): IFK Norrköping  (3) Norrköping · Norrkoping · IFK Norrköping FK
- **Sundsvall** (1): GIF Sundsvall  (1) Sundsvall
- **Södertälje** (1): Syrianska FC  (1) Syrianska
- **Trelleborg** (1): Trelleborgs FF  (1) Trelleborgs
- **Växjö** (1): Östers IF  (1) Osters
- **Åtvidaberg** (1): Åtvidabergs FF  (5) Atvidabergs · Åtvidaberg · Åtvid · ÅFF · Åtvidabergs Fotbollförening
- **Örebro** (1): Örebro SK  (3) Örebro · Orebro · Örebro Sportklubb
- **Östersund** (1): Östersunds FK  (2) Östersund · Ostersunds




By Region

- **Stockholm†** (4):   AIK · IF Brommapojkarna · Djurgårdens IF · Hammarby IF
- **Göteborg†** (3):   IFK Göteborg · GAIS · BK Häcken
- **Malmö†** (1):   Malmö FF
- **Borås†** (1):   IF Elfsborg
- **Helsingborg†** (1):   Helsingborgs IF
- **Kalmar†** (1):   Kalmar FF
- **Örebro†** (1):   Örebro SK
- **Gävle†** (1):   Gefle IF
- **Eskilstuna†** (1):   AFC Eskilstuna
- **Mjällby†** (1):   Mjällby AIF
- **Åtvidaberg†** (1):   Åtvidabergs FF
- **Uppsala†** (2):   Dalkurd FF · IK Sirius
- **Falkenberg†** (1):   Falkenbergs FF
- **Halmstad†** (1):   Halmstads BK
- **Jönköping†** (1):   Jönköpings Södra IF
- **Ljungskile†** (1):   Ljungskile SK
- **Norrköping†** (1):   IFK Norrköping
- **Växjö†** (1):   Östers IF
- **Östersund†** (1):   Östersunds FK
- **Sundsvall†** (1):   GIF Sundsvall
- **Södertälje†** (1):   Syrianska FC
- **Trelleborg†** (1):   Trelleborgs FF




By Year

- ? (28):   AIK · IF Brommapojkarna · Djurgårdens IF · Hammarby IF · IFK Göteborg · GAIS · BK Häcken · Malmö FF · IF Elfsborg · Helsingborgs IF · Kalmar FF · Örebro SK · Gefle IF · AFC Eskilstuna · Mjällby AIF · Åtvidabergs FF · Dalkurd FF · IK Sirius · Falkenbergs FF · Halmstads BK · Jönköpings Södra IF · Ljungskile SK · IFK Norrköping · Östers IF · Östersunds FK · GIF Sundsvall · Syrianska FC · Trelleborgs FF






By A to Z

- **A** (5): AIK · AIK Fotboll · Atvidabergs · AFC Eskilstuna · Allmänna Idrottsklubben
- **B** (3): BK Häcken · Brommapojkarna · Bollklubben Häcken
- **D** (5): Dalkurd · Dalkurd FF · Djurgarden · Djurgården · Djurgårdens IF
- **E** (1): Elfsborg
- **F** (2): Falkenbergs · Falkenbergs FF
- **G** (8): GAIS · Gais · Gefle · Gefle IF · Goteborg · Göteborg · GIF Sundsvall · Göteborgs Atlet- och Idrottssällskap
- **H** (9): Hacken · Häcken · Halmstad · Hammarby · Hammarby IF · Helsingborg · Halmstads BK · Helsingborgs IF · Halmstads Bollklubb
- **I** (8): IK Sirius · IF Elfsborg · IFK Goteborg · IFK Göteborg · IFK Norrköping · IF Brommapojkarna · IFK Norrköping FK · Idrottsföreningen Kamraterna Göteborg
- **J** (2): Jonkopings · Jönköpings Södra IF
- **K** (2): Kalmar · Kalmar FF
- **L** (2): Ljungskile · Ljungskile SK
- **M** (6): Malmö · Mjallby · Malmo FF · Malmö FF · Mjällby AIF · Malmö Fotbollförening
- **N** (2): Norrkoping · Norrköping
- **O** (3): Orebro · Osters · Ostersunds
- **S** (4): Sirius · Sundsvall · Syrianska · Syrianska FC
- **T** (2): Trelleborgs · Trelleborgs FF
- **Å** (5): ÅFF · Åtvid · Åtvidaberg · Åtvidabergs FF · Åtvidabergs Fotbollförening
- **Ö** (6): Örebro · Örebro SK · Östers IF · Östersund · Östersunds FK · Örebro Sportklubb




