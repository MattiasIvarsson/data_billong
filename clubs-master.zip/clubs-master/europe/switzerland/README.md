22 clubs

- [**Grasshoppers Zürich**](https://en.wikipedia.org/wiki/Grasshopper_Club_Zürich) : (3) Grasshoppers · Grasshoppers Zurich · Grasshopper Club Zürich ⇒ (4) ≈Grasshoppers Zurich≈ · ≈Grasshoppers Zuerich≈ · ≈Grasshopper Club Zurich≈ · ≈Grasshopper Club Zuerich≈
- [**FC Zürich**](https://en.wikipedia.org/wiki/FC_Zürich) : (3) Zürich · Zurich · FC Zurich ⇒ (4) ≈Zurich≈ · ≈Zuerich≈ · ≈FC Zurich≈ · ≈FC Zuerich≈
- **FC Winterthur** : (1) Winterthur
- [**FC Basel**](https://en.wikipedia.org/wiki/FC_Basel) : (2) Basel · FC Basel 1893
- [**BSC Young Boys**](https://en.wikipedia.org/wiki/BSC_Young_Boys) : (4) BSC YB · Young Boys · Young Boys Bern · Berner Sport Club Young Boys
- **FC Biel-Bienne** : (1) Biel-Bienne
- [**FC Thun**](https://en.wikipedia.org/wiki/FC_Thun) : (2) Thun · FC Thun 1898
- [**FC Luzern**](https://en.wikipedia.org/wiki/FC_Luzern) : (1) Luzern
- [**FC St. Gallen**](https://en.wikipedia.org/wiki/FC_St._Gallen) : (1) St. Gallen
- **FC Wil** : (2) Wil · FC Wil 1900
- **FC Schaffhausen**
- **FC Aarau** : (1) Aarau
- **FC Wohlen** : (1) Wohlen
- [**FC Sion**](https://en.wikipedia.org/wiki/FC_Sion) : (1) Sion
- [**Xamax Neuchâtel**](https://en.wikipedia.org/wiki/Neuchâtel_Xamax_FCS) : (2) Xamax · Neuchâtel Xamax FCS ⇒ (2) ≈Xamax Neuchatel≈ · ≈Neuchatel Xamax FCS≈
- [**FC Lausanne**](https://en.wikipedia.org/wiki/FC_Lausanne-Sport) : (2) Lausanne · FC Lausanne-Sport
- **FC Le Mont** : (1) FC Le Mont-sur-Lausanne,
- **Servette FC** : (3) Servette · Servette Genève · Servette FC Genève ⇒ (2) ≈Servette Geneve≈ · ≈Servette FC Geneve≈
- [**FC Lugano**](https://en.wikipedia.org/wiki/FC_Lugano) : (1) Lugano
- **FC Chiasso** : (1) Chiasso
- **FC Locarno** : (1) Locarno
- **AC Bellinzona** : (1) Bellinzona




Alphabet

- **Alphabet Specials** (3):  **â**  **è**  **ü** 
  - **â**×2 U+00E2 (226) - LATIN SMALL LETTER A WITH CIRCUMFLEX ⇒ a
  - **è**×2 U+00E8 (232) - LATIN SMALL LETTER E WITH GRAVE ⇒ e
  - **ü**×4 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue




Duplicates

- **Grasshoppers Zürich**, Zürich (1):
  - `grasshopperszurich` (2): **Grasshoppers Zurich** · **Grasshoppers Zurich**
- **FC Zürich**, Zürich (2):
  - `zurich` (2): **Zurich** · **Zurich**
  - `fczurich` (2): **FC Zurich** · **FC Zurich**




By City

- **Zürich, Zürich** (2): 
  - Grasshoppers Zürich  (3) Grasshoppers · Grasshoppers Zurich · Grasshopper Club Zürich
  - FC Zürich  (3) Zürich · Zurich · FC Zurich
- **Aarau, Aargau** (1): FC Aarau  (1) Aarau
- **Basel, Basel-Stadt** (1): FC Basel  (2) Basel · FC Basel 1893
- **Bellinzona, Ticino** (1): AC Bellinzona  (1) Bellinzona
- **Bern, Bern** (1): BSC Young Boys  (4) Young Boys · Young Boys Bern · Berner Sport Club Young Boys · BSC YB
- **Biel/Bienne, Bern** (1): FC Biel-Bienne  (1) Biel-Bienne
- **Chiasso, Ticino** (1): FC Chiasso  (1) Chiasso
- **Genève, Genève** (1): Servette FC  (3) Servette · Servette Genève · Servette FC Genève
- **Lausanne, Lausanne** (1): FC Lausanne  (2) Lausanne · FC Lausanne-Sport
- **Le Mont-sur-Lausanne, Lausanne** (1): FC Le Mont  (1) FC Le Mont-sur-Lausanne,
- **Locarno, Ticino** (1): FC Locarno  (1) Locarno
- **Lugano, Ticino** (1): FC Lugano  (1) Lugano
- **Luzern, Luzern** (1): FC Luzern  (1) Luzern
- **Neuchâtel, Neuchâtel** (1): Xamax Neuchâtel  (2) Xamax · Neuchâtel Xamax FCS
- **Schaffhausen, Schaffhausen** (1): FC Schaffhausen 
- **Sion, Valais** (1): FC Sion  (1) Sion
- **St. Gallen, St. Gallen** (1): FC St. Gallen  (1) St. Gallen
- **Thun, Bern** (1): FC Thun  (2) Thun · FC Thun 1898
- **Wil, St. Gallen** (1): FC Wil  (2) Wil · FC Wil 1900
- **Winterthur, Zürich** (1): FC Winterthur  (1) Winterthur
- **Wohlen, Aargau** (1): FC Wohlen  (1) Wohlen




By Region

- **Zürich** (3):   Grasshoppers Zürich · FC Zürich · FC Winterthur
- **Basel-Stadt** (1):   FC Basel
- **Bern** (3):   BSC Young Boys · FC Biel-Bienne · FC Thun
- **Luzern** (1):   FC Luzern
- **St. Gallen** (2):   FC St. Gallen · FC Wil
- **Schaffhausen** (1):   FC Schaffhausen
- **Aargau** (2):   FC Aarau · FC Wohlen
- **Valais** (1):   FC Sion
- **Neuchâtel** (1):   Xamax Neuchâtel
- **Lausanne** (2):   FC Lausanne · FC Le Mont
- **Genève** (1):   Servette FC
- **Ticino** (4):   FC Lugano · FC Chiasso · FC Locarno · AC Bellinzona




By Year

- **1879** (1):   FC St. Gallen
- **1886** (1):   Grasshoppers Zürich
- **1890** (1):   Servette FC
- **1893** (1):   FC Basel
- **1896** (5):   FC Zürich · FC Winterthur · FC Biel-Bienne · FC Schaffhausen · FC Lausanne
- **1898** (2):   BSC Young Boys · FC Thun
- **1900** (1):   FC Wil
- **1901** (1):   FC Luzern
- **1902** (1):   FC Aarau
- **1904** (2):   FC Wohlen · AC Bellinzona
- **1905** (1):   FC Chiasso
- **1906** (1):   FC Locarno
- **1908** (1):   FC Lugano
- **1909** (1):   FC Sion
- **1942** (1):   FC Le Mont
- ? (1):   Xamax Neuchâtel






By A to Z

- **A** (2): Aarau · AC Bellinzona
- **B** (6): Basel · BSC YB · Bellinzona · Biel-Bienne · BSC Young Boys · Berner Sport Club Young Boys
- **C** (1): Chiasso
- **F** (23): FC Wil · FC Sion · FC Thun · FC Aarau · FC Basel · FC Lugano · FC Luzern · FC Wohlen · FC Zurich · FC Zürich · FC Chiasso · FC Le Mont · FC Locarno · FC Lausanne · FC Wil 1900 · FC Thun 1898 · FC Basel 1893 · FC St. Gallen · FC Winterthur · FC Biel-Bienne · FC Schaffhausen · FC Lausanne-Sport · FC Le Mont-sur-Lausanne,
- **G** (4): Grasshoppers · Grasshoppers Zurich · Grasshoppers Zürich · Grasshopper Club Zürich
- **L** (4): Lugano · Luzern · Locarno · Lausanne
- **N** (1): Neuchâtel Xamax FCS
- **S** (6): Sion · Servette · St. Gallen · Servette FC · Servette Genève · Servette FC Genève
- **T** (1): Thun
- **W** (3): Wil · Wohlen · Winterthur
- **X** (2): Xamax · Xamax Neuchâtel
- **Y** (2): Young Boys · Young Boys Bern
- **Z** (2): Zurich · Zürich




