133 clubs

- [**Bayern München**](https://en.wikipedia.org/wiki/FC_Bayern_Munich) : (4) Bayern · FC Bayern München · Bayern Munich [en] · FC Bayern Munich [en] ⇒ (4) ≈Bayern Munchen≈ · ≈Bayern Muenchen≈ · ≈FC Bayern Munchen≈ · ≈FC Bayern Muenchen≈
- [**TSV 1860 München**](https://en.wikipedia.org/wiki/TSV_1860_Munich) : (4) 1860 München · TSV München 1860 · Munich 1860 [en] · TSV 1860 Munich [en] ⇒ (6) ≈1860 Munchen≈ · ≈1860 Muenchen≈ · ≈TSV 1860 Munchen≈ · ≈TSV Munchen 1860≈ · ≈TSV 1860 Muenchen≈ · ≈TSV Muenchen 1860≈
- [**1. FC Nürnberg**](https://en.wikipedia.org/wiki/1._FC_Nürnberg) : (1) Nürnberg ⇒ (4) ≈Nurnberg≈ · ≈Nuernberg≈ · ≈1. FC Nurnberg≈ · ≈1. FC Nuernberg≈
- [**SpVgg Greuther Fürth**](https://en.wikipedia.org/wiki/SpVgg_Greuther_Fürth) : (1) Greuther Fürth ⇒ (4) ≈Greuther Furth≈ · ≈Greuther Fuerth≈ · ≈SpVgg Greuther Furth≈ · ≈SpVgg Greuther Fuerth≈
- [**FC Augsburg**](https://en.wikipedia.org/wiki/FC_Augsburg) : (1) Augsburg
- [**SpVgg Unterhaching**](https://en.wikipedia.org/wiki/SpVgg_Unterhaching) : (2) U'haching · Unterhaching
- [**FC Ingolstadt 04**](https://en.wikipedia.org/wiki/FC_Ingolstadt_04) : (1) Ingolstadt
- [**SSV Jahn Regensburg**](https://en.wikipedia.org/wiki/SSV_Jahn_Regensburg) : (2) Regensburg · Jahn Regensburg
- **1. FC Schweinfurt 05** : (1) Schweinfurt
- [**Würzburger Kickers**](https://en.wikipedia.org/wiki/Würzburger_Kickers) : (1) FC Würzburger Kickers ⇒ (4) ≈Wurzburger Kickers≈ · ≈Wuerzburger Kickers≈ · ≈FC Wurzburger Kickers≈ · ≈FC Wuerzburger Kickers≈
- **Wacker Burghausen** : (1) Burghausen
- **TSV 1860 Rosenheim**
- **FV Illertissen**
- [**1. FC Köln**](https://en.wikipedia.org/wiki/1._FC_Köln) : (1) FC Köln ⇒ (4) ≈FC Koln≈ · ≈FC Koeln≈ · ≈1. FC Koln≈ · ≈1. FC Koeln≈
- [**Fortuna Köln**](https://en.wikipedia.org/wiki/SC_Fortuna_Köln) : (3) F Köln · SC Fortuna Köln · Sportclub Fortuna Köln ⇒ (8) ≈F Koln≈ · ≈F Koeln≈ · ≈Fortuna Koln≈ · ≈Fortuna Koeln≈ · ≈SC Fortuna Koln≈ · ≈SC Fortuna Koeln≈ · ≈Sportclub Fortuna Koln≈ · ≈Sportclub Fortuna Koeln≈
- **FC Viktoria Köln** ⇒ (2) ≈FC Viktoria Koln≈ · ≈FC Viktoria Koeln≈
- [**Fortuna Düsseldorf**](https://en.wikipedia.org/wiki/Fortuna_Düsseldorf) : (2) Düsseldorf · F. Düsseldorf ⇒ (6) ≈Dusseldorf≈ · ≈Duesseldorf≈ · ≈F. Dusseldorf≈ · ≈F. Duesseldorf≈ · ≈Fortuna Dusseldorf≈ · ≈Fortuna Duesseldorf≈
- [**Borussia Dortmund**](https://en.wikipedia.org/wiki/Borussia_Dortmund) : (3) Dortmund · Bor. Dortmund · BV 09 Borussia Dortmund
- **Borussia Dortmund II** : (2) Dortmund II · Bor. Dortmund II
- [**FC Schalke 04**](https://en.wikipedia.org/wiki/FC_Schalke_04) : (2) Schalke · Schalke 04
- [**Bayer 04 Leverkusen**](https://en.wikipedia.org/wiki/Bayer_04_Leverkusen) : (3) Leverkusen · Bay. Leverkusen · Bayer Leverkusen
- [**MSV Duisburg**](https://en.wikipedia.org/wiki/MSV_Duisburg) : (2) Duisburg · Meidericher SV
- [**Bor. Mönchengladbach**](https://en.wikipedia.org/wiki/Borussia_Mönchengladbach) : (8) M'Gladbach · Mönchengladbach · Bor. M'gladbach · Borussia M'gladbach · Bor. Moenchengladbach · Borussia Monchengladbach · Borussia Mönchengladbach · VfL Borussia Mönchengladbach ⇒ (8) ≈Monchengladbach≈ · ≈Moenchengladbach≈ · ≈Bor. Monchengladbach≈ · ≈Bor. Moenchengladbach≈ · ≈Borussia Monchengladbach≈ · ≈Borussia Moenchengladbach≈ · ≈VfL Borussia Monchengladbach≈ · ≈VfL Borussia Moenchengladbach≈
- [**VfL Bochum**](https://en.wikipedia.org/wiki/VfL_Bochum) : (2) Bochum · VfL Bochum 1848
- **SG Wattenscheid 09** : (2) Wattenscheid · Wattenscheid 09
- [**Arminia Bielefeld**](https://en.wikipedia.org/wiki/Arminia_Bielefeld) : (2) Bielefeld · DSC Arminia Bielefeld
- [**Preußen Münster**](https://en.wikipedia.org/wiki/SC_Preußen_Münster) : (3) Münster · SC Preußen 06 · SC Preußen Münster ⇒ (7) ≈Munster≈ · ≈Muenster≈ · ≈SC Preussen 06≈ · ≈Preussen Munster≈ · ≈Preussen Muenster≈ · ≈SC Preussen Munster≈ · ≈SC Preussen Muenster≈
- **Gütersloh** ⇒ (2) ≈Gutersloh≈ · ≈Guetersloh≈
- [**KFC Uerdingen**](https://en.wikipedia.org/wiki/KFC_Uerdingen_05) : (5) Uerdingen · Bayer Uerdingen · KFC Uerdingen 05 · Bayer 05 Uerdingen · FC Bayer 05 Uerdingen
- **Alemannia Aachen** : (2) Aachen · TSV Alemannia Aachen
- [**SC Paderborn 07**](https://en.wikipedia.org/wiki/SC_Paderborn_07) : (1) Paderborn
- **Rot Weiss Ahlen** : (1) Ahlen
- **Rot-Weiß Oberhausen** : (2) Oberhausen · Rot-Weiss Oberhausen ⇒ (1) ≈Rot-Weiss Oberhausen≈
- **SF Siegen** : (2) Siegen · Sportfreunde Siegen
- **Wuppertaler SV** : (1) Wuppertaler
- **Rot-Weiss Essen** : (2) Essen · RW Essen
- **SF Baumberg** : (1) Sportfreunde Baumberg
- [**SF Lotte**](https://en.wikipedia.org/wiki/Sportfreunde_Lotte) : (1) Sportfreunde Lotte
- **SV Lippstadt 08**
- **SC Wiedenbrück** : (1) SC Wiedenbrück 2000 ⇒ (4) ≈SC Wiedenbruck≈ · ≈SC Wiedenbrueck≈ · ≈SC Wiedenbruck 2000≈ · ≈SC Wiedenbrueck 2000≈
- **FC Hennef 05**
- **TuS Erndtebrück** ⇒ (2) ≈TuS Erndtebruck≈ · ≈TuS Erndtebrueck≈
- **1. FC Saarbrücken** : (3) Saarbrucken · Saarbrücken · 1. FC Saarbruecken ⇒ (4) ≈Saarbrucken≈ · ≈Saarbruecken≈ · ≈1. FC Saarbrucken≈ · ≈1. FC Saarbruecken≈
- **FC 08 Homburg** : (3) Homburg · FC Homburg · FC Homburg/Saar
- **VfB Borussia Neunkirchen** : (1) Borussia Neunkirchen
- **SV Elversberg** : (1) SV 07 Elversberg
- [**VfL Osnabrück**](https://en.wikipedia.org/wiki/VfL_Osnabrück) : (1) Osnabruck ⇒ (2) ≈VfL Osnabruck≈ · ≈VfL Osnabrueck≈
- [**VfL Wolfsburg**](https://en.wikipedia.org/wiki/VfL_Wolfsburg) : (1) Wolfsburg
- [**Hannover 96**](https://en.wikipedia.org/wiki/Hannover_96) : (2) Hannover · Hannover 1896
- [**Eintracht Braunschweig**](https://en.wikipedia.org/wiki/Eintracht_Braunschweig) : (2) Braunschweig · Eintr. Braunschweig
- **FT Braunschweig** : (1) Freie Turnerschaft Braunschweig
- [**SV Meppen**](https://en.wikipedia.org/wiki/SV_Meppen) : (1) Meppen
- **VfB Oldenburg** : (1) Oldenburg
- **SV Wilhelmshaven**
- **BSV Schwarz-Weiß Rehden** ⇒ (1) ≈BSV Schwarz-Weiss Rehden≈
- **TSV Havelse**
- [**Energie Cottbus**](https://en.wikipedia.org/wiki/FC_Energie_Cottbus) : (2) Cottbus · FC Energie Cottbus
- **SV Babelsberg 03** : (1) Babelsberg
- **FSV Optik Rathenow**
- **SV Falkensee-Finkenkrug**
- [**Hertha BSC**](https://en.wikipedia.org/wiki/Hertha_BSC) : (3) Hertha · Hertha BSC Berlin · Hertha Berliner Sport-Club
- **Tennis Borussia Berlin** : (2) TB Berlin · TeBe Berlin
- [**1. FC Union Berlin**](https://en.wikipedia.org/wiki/1._FC_Union_Berlin) : (1) Union Berlin
- **Blau-Weiß 90 Berlin (-1992)** : (1) Blau-Weiss 90 Berlin ⇒ (1) ≈Blau-Weiss 90 Berlin≈
- **SC Tasmania 1900 Berlin (-1973)** : (2) Tasmania Berlin · Tasmania 1900 Berlin
- **BFC Dynamo Berlin** : (1) BFC Dynamo
- **Berliner AK 07**
- **FC Viktoria 1889 Berlin**
- [**Hamburger SV**](https://en.wikipedia.org/wiki/Hamburger_SV) : (1) Hamburg
- [**FC St. Pauli**](https://en.wikipedia.org/wiki/FC_St._Pauli) : (3) St Pauli · St. Pauli · FC Sankt Pauli
- **SC Victoria Hamburg** : (1) Victoria Hamburg
- **USC Paloma Hamburg**
- **HSV Barmbek-Uhlenhorst**
- [**Werder Bremen**](https://en.wikipedia.org/wiki/SV_Werder_Bremen) : (2) Bremen · SV Werder Bremen
- **Werder Bremen II**
- **SG Aumund-Vegesack**
- **FC Oberneuland**
- **Bremer SV**
- [**VfB Stuttgart**](https://en.wikipedia.org/wiki/VfB_Stuttgart) : (1) Stuttgart
- **VfB Stuttgart II** : (1) Stuttgart II
- **Stuttgarter Kickers** : (2) Stutt. Kick. · Stuttgarter K
- [**SC Freiburg**](https://en.wikipedia.org/wiki/SC_Freiburg) : (1) Freiburg
- [**TSG 1899 Hoffenheim**](https://en.wikipedia.org/wiki/TSG_1899_Hoffenheim) : (2) Hoffenheim · 1899 Hoffenheim
- [**Karlsruher SC**](https://en.wikipedia.org/wiki/Karlsruher_SC) : (1) Karlsruhe
- **SSV Ulm 1846** : (1) Ulm
- [**VfR Aalen**](https://en.wikipedia.org/wiki/VfR_Aalen) : (1) Aalen
- [**1. FC Heidenheim**](https://en.wikipedia.org/wiki/1._FC_Heidenheim) : (2) Heidenheim · 1. FC Heidenheim 1846
- **SSV Reutlingen 05** : (1) Reutlingen
- [**SV Sandhausen**](https://en.wikipedia.org/wiki/SV_Sandhausen) : (2) Sandhausen · SV Sandhausen 1916
- **VfR Mannheim** : (1) Mannheim
- **SV Waldhof Mannheim** : (2) Waldhof Mannheim · SV Waldhof Mannheim 07
- [**SG Großaspach**](https://en.wikipedia.org/wiki/SG_Sonnenhof_Großaspach) : (3) Großaspach · SG Sonnenhof Großaspach · Sportgemeinschaft Sonnenhof Großaspach ⇒ (4) ≈Grossaspach≈ · ≈SG Grossaspach≈ · ≈SG Sonnenhof Grossaspach≈ · ≈Sportgemeinschaft Sonnenhof Grossaspach≈
- **FC Nöttingen** ⇒ (2) ≈FC Nottingen≈ · ≈FC Noettingen≈
- **Bahlinger SC**
- **Neckarsulmer Sport-Union**
- **Offenburger FV**
- **FC-Astoria Walldorf**
- **SV Waldkirch**
- [**Eintracht Frankfurt**](https://en.wikipedia.org/wiki/Eintracht_Frankfurt) : (3) E. Frankfurt · Ein Frankfurt · SG Eintracht Frankfurt
- **FSV Frankfurt** : (2) Frankfurt FSV · FSV Frankfurt 1899
- [**SV Darmstadt 98**](https://en.wikipedia.org/wiki/SV_Darmstadt_98) : (1) Darmstadt
- [**SV Wehen Wiesbaden**](https://en.wikipedia.org/wiki/SV_Wehen_Wiesbaden) : (2) Wehen · Wiesbaden
- **Kickers Offenbach** : (1) Offenbach
- **KSV Hessen Kassel**
- [**1. FC Kaiserslautern**](https://en.wikipedia.org/wiki/1._FC_Kaiserslautern) : (3) K'lautern · Kaiserslautern · 1. FC K'lautern
- [**1. FSV Mainz 05**](https://en.wikipedia.org/wiki/1._FSV_Mainz_05) : (2) Mainz · FSV Mainz 05
- **1. FSV Mainz 05 II**
- **Eintracht Trier** : (1) Ein Trier
- **TuS Koblenz** : (1) Koblenz
- **TSG Pfeddersheim**
- **SV Roßbach/Verscheid** ⇒ (1) ≈SV Rossbach/Verscheid≈
- **Wormatia Worms**
- **SV Alemannia Waldalgesheim**
- **FSV Salmrohr**
- **FK Pirmasens** : (1) FK 03 Pirmasens
- **VfB Lübeck** : (2) Lübeck · Lubeck ⇒ (4) ≈Lubeck≈ · ≈Luebeck≈ · ≈VfB Lubeck≈ · ≈VfB Luebeck≈
- [**Holstein Kiel**](https://en.wikipedia.org/wiki/Holstein_Kiel) : (1) Kiel
- **VfR Neumünster** ⇒ (2) ≈VfR Neumunster≈ · ≈VfR Neumuenster≈
- [**Hansa Rostock**](https://en.wikipedia.org/wiki/F.C._Hansa_Rostock) : (2) Rostock · FC Hansa Rostock
- **TSG Neustrelitz**
- **FC Schönberg 95** ⇒ (2) ≈FC Schonberg 95≈ · ≈FC Schoenberg 95≈
- **1. FC Neubrandenburg 04**
- [**Dynamo Dresden**](https://en.wikipedia.org/wiki/Dynamo_Dresden) : (2) Dresden · SG Dynamo Dresden
- [**RB Leipzig**](https://en.wikipedia.org/wiki/RB_Leipzig)
- **VfB Leipzig (-2004)** : (1) Leipzig
- **Chemnitzer FC** : (1) Chemnitz
- [**FC Erzgebirge Aue**](https://en.wikipedia.org/wiki/FC_Erzgebirge_Aue) : (2) Aue · Erzgebirge Aue
- [**FSV Zwickau**](https://en.wikipedia.org/wiki/FSV_Zwickau) : (1) Zwickau
- [**Hallescher FC**](https://en.wikipedia.org/wiki/Hallescher_FC) : (1) Halle
- [**1. FC Magdeburg**](https://en.wikipedia.org/wiki/1._FC_Magdeburg) : (1) Magdeburg
- [**FC Carl Zeiss Jena**](https://en.wikipedia.org/wiki/FC_Carl_Zeiss_Jena) : (1) CZ Jena
- **SV Schott Jena**
- **FC Rot-Weiß Erfurt** : (3) Erfurt · RW Erfurt · Rot-Weiß Erfurt ⇒ (2) ≈Rot-Weiss Erfurt≈ · ≈FC Rot-Weiss Erfurt≈




Alphabet

- **Alphabet Specials** (3):  **ß**  **ö**  **ü** 
  - **ß**×13 U+00DF (223) - LATIN SMALL LETTER SHARP S ⇒ ss
  - **ö**×13 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **ü**×27 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue




Duplicates

- **Bor. Mönchengladbach**, Mönchengladbach (2):
  - `borussiamonchengladbach` (2): **Borussia Monchengladbach** · **Borussia Monchengladbach**
  - `bormoenchengladbach` (2): **Bor. Moenchengladbach** · **Bor. Moenchengladbach**
- **Rot-Weiß Oberhausen**, Oberhausen (1):
  - `rotweissoberhausen` (2): **Rot-Weiss Oberhausen** · **Rot-Weiss Oberhausen**
- **1. FC Saarbrücken**, Saarbrücken (2):
  - `saarbrucken` (2): **Saarbrucken** · **Saarbrucken**
  - `1fcsaarbruecken` (2): **1. FC Saarbruecken** · **1. FC Saarbruecken**
- **Blau-Weiß 90 Berlin (-1992)**, Berlin (1):
  - `blauweiss90berlin` (2): **Blau-Weiss 90 Berlin** · **Blau-Weiss 90 Berlin**
- **FC St. Pauli**, Hamburg (1):
  - `stpauli` (2): St Pauli · St. Pauli
- **VfB Lübeck**, Lübeck (1):
  - `lubeck` (2): **Lubeck** · **Lubeck**




By City

- **Berlin, Berlin** (6): 
  - Hertha BSC  (3) Hertha · Hertha BSC Berlin · Hertha Berliner Sport-Club
  - Tennis Borussia Berlin  (2) TB Berlin · TeBe Berlin
  - 1\. FC Union Berlin  (1) Union Berlin
  - Blau-Weiß 90 Berlin (-1992)  (1) Blau-Weiss 90 Berlin
  - SC Tasmania 1900 Berlin (-1973)  (2) Tasmania 1900 Berlin · Tasmania Berlin
  - BFC Dynamo Berlin  (1) BFC Dynamo
- **Köln, Nordrhein-Westfalen** (3): 
  - 1\. FC Köln  (1) FC Köln
  - Fortuna Köln  (3) F Köln · SC Fortuna Köln · Sportclub Fortuna Köln
  - FC Viktoria Köln 
- **Stuttgart, Baden-Württemberg** (3): 
  - VfB Stuttgart  (1) Stuttgart
  - VfB Stuttgart II  (1) Stuttgart II
  - Stuttgarter Kickers  (2) Stuttgarter K · Stutt. Kick.
- **Bochum, Nordrhein-Westfalen** (2): 
  - VfL Bochum  (2) Bochum · VfL Bochum 1848
  - SG Wattenscheid 09  (2) Wattenscheid · Wattenscheid 09
- **Bremen, Bremen** (2): 
  - Werder Bremen  (2) Bremen · SV Werder Bremen
  - Werder Bremen II 
- **Dortmund, Nordrhein-Westfalen** (2): 
  - Borussia Dortmund  (3) Dortmund · Bor. Dortmund · BV 09 Borussia Dortmund
  - Borussia Dortmund II  (2) Dortmund II · Bor. Dortmund II
- **Frankfurt am Main, Hessen** (2): 
  - Eintracht Frankfurt  (3) Ein Frankfurt · E. Frankfurt · SG Eintracht Frankfurt
  - FSV Frankfurt  (2) Frankfurt FSV · FSV Frankfurt 1899
- **Hamburg, Hamburg** (2): 
  - Hamburger SV  (1) Hamburg
  - FC St. Pauli  (3) St Pauli · St. Pauli · FC Sankt Pauli
- **Leipzig, Sachsen** (2): 
  - RB Leipzig 
  - VfB Leipzig (-2004)  (1) Leipzig
- **Mainz, Rheinland-Pfalz** (2): 
  - 1\. FSV Mainz 05  (2) Mainz · FSV Mainz 05
  - 1\. FSV Mainz 05 II 
- **Mannheim, Baden-Württemberg** (2): 
  - VfR Mannheim  (1) Mannheim
  - SV Waldhof Mannheim  (2) Waldhof Mannheim · SV Waldhof Mannheim 07
- **München, Bayern** (2): 
  - Bayern München  (4) Bayern · FC Bayern München · Bayern Munich [en] · FC Bayern Munich [en]
  - TSV 1860 München  (4) 1860 München · TSV München 1860 · Munich 1860 [en] · TSV 1860 Munich [en]
- **Aachen, Nordrhein-Westfalen** (1): Alemannia Aachen  (2) Aachen · TSV Alemannia Aachen
- **Aalen, Baden-Württemberg** (1): VfR Aalen  (1) Aalen
- **Ahlen, Nordrhein-Westfalen** (1): Rot Weiss Ahlen  (1) Ahlen
- **Aue, Sachsen** (1): FC Erzgebirge Aue  (2) Aue · Erzgebirge Aue
- **Augsburg, Bayern** (1): FC Augsburg  (1) Augsburg
- **Bielefeld, Nordrhein-Westfalen** (1): Arminia Bielefeld  (2) Bielefeld · DSC Arminia Bielefeld
- **Braunschweig, Niedersachsen** (1): Eintracht Braunschweig  (2) Braunschweig · Eintr. Braunschweig
- **Burghausen, Bayern** (1): Wacker Burghausen  (1) Burghausen
- **Chemnitz, Sachsen** (1): Chemnitzer FC  (1) Chemnitz
- **Cottbus, Brandenburg** (1): Energie Cottbus  (2) Cottbus · FC Energie Cottbus
- **Darmstadt, Hessen** (1): SV Darmstadt 98  (1) Darmstadt
- **Dresden, Sachsen** (1): Dynamo Dresden  (2) Dresden · SG Dynamo Dresden
- **Duisburg, Nordrhein-Westfalen** (1): MSV Duisburg  (2) Duisburg · Meidericher SV
- **Düsseldorf, Nordrhein-Westfalen** (1): Fortuna Düsseldorf  (2) Düsseldorf · F. Düsseldorf
- **Erfurt, Thüringen** (1): FC Rot-Weiß Erfurt  (3) Erfurt · Rot-Weiß Erfurt · RW Erfurt
- **Essen, Nordrhein-Westfalen** (1): Rot-Weiss Essen  (2) Essen · RW Essen
- **Freiburg, Baden-Württemberg** (1): SC Freiburg  (1) Freiburg
- **Fürth, Bayern** (1): SpVgg Greuther Fürth  (1) Greuther Fürth
- **Gelsenkirchen, Nordrhein-Westfalen** (1): FC Schalke 04  (2) Schalke · Schalke 04
- **Gütersloh, Nordrhein-Westfalen** (1): Gütersloh 
- **Hannover, Niedersachsen** (1): Hannover 96  (2) Hannover · Hannover 1896
- **Heidenheim an der Brenz, Baden-Württemberg** (1): 1. FC Heidenheim  (2) Heidenheim · 1. FC Heidenheim 1846
- **Homburg, Saarland** (1): FC 08 Homburg  (3) Homburg · FC Homburg · FC Homburg/Saar
- **Ingolstadt, Bayern** (1): FC Ingolstadt 04  (1) Ingolstadt
- **Jena, Thüringen** (1): FC Carl Zeiss Jena  (1) CZ Jena
- **Kaiserslautern, Rheinland-Pfalz** (1): 1. FC Kaiserslautern  (3) K'lautern · Kaiserslautern · 1. FC K'lautern
- **Karlsruhe, Baden-Württemberg** (1): Karlsruher SC  (1) Karlsruhe
- **Kiel, Schleswig-Holstein** (1): Holstein Kiel  (1) Kiel
- **Koblenz, Rheinland-Pfalz** (1): TuS Koblenz  (1) Koblenz
- **Krefeld, Nordrhein-Westfalen** (1): KFC Uerdingen  (5) Uerdingen · KFC Uerdingen 05 · Bayer 05 Uerdingen · FC Bayer 05 Uerdingen · Bayer Uerdingen
- **Leverkusen, Nordrhein-Westfalen** (1): Bayer 04 Leverkusen  (3) Leverkusen · Bayer Leverkusen · Bay. Leverkusen
- **Lübeck, Schleswig-Holstein** (1): VfB Lübeck  (2) Lübeck · Lubeck
- **Magdeburg, Sachsen-Anhalt** (1): 1. FC Magdeburg  (1) Magdeburg
- **Meppen, Niedersachsen** (1): SV Meppen  (1) Meppen
- **Mönchengladbach, Nordrhein-Westfalen** (1): Bor. Mönchengladbach  (8) Mönchengladbach · M'Gladbach · Borussia Monchengladbach · Borussia M'gladbach · Bor. M'gladbach · Bor. Moenchengladbach · Borussia Mönchengladbach · VfL Borussia Mönchengladbach
- **Münster, Nordrhein-Westfalen** (1): Preußen Münster  (3) Münster · SC Preußen 06 · SC Preußen Münster
- **Neunkirchen, Saarland** (1): VfB Borussia Neunkirchen  (1) Borussia Neunkirchen
- **Nürnberg, Bayern** (1): 1. FC Nürnberg  (1) Nürnberg
- **Oberhausen, Nordrhein-Westfalen** (1): Rot-Weiß Oberhausen  (2) Oberhausen · Rot-Weiss Oberhausen
- **Offenbach am Main, Hessen** (1): Kickers Offenbach  (1) Offenbach
- **Oldenburg, Niedersachsen** (1): VfB Oldenburg  (1) Oldenburg
- **Osnabrück, Niedersachsen** (1): VfL Osnabrück  (1) Osnabruck
- **Paderborn, Nordrhein-Westfalen** (1): SC Paderborn 07  (1) Paderborn
- **Potsdam, Brandenburg** (1): SV Babelsberg 03  (1) Babelsberg
- **Regensburg, Bayern** (1): SSV Jahn Regensburg  (2) Regensburg · Jahn Regensburg
- **Reutlingen, Baden-Württemberg** (1): SSV Reutlingen 05  (1) Reutlingen
- **Rosenheim, Bayern** (1): TSV 1860 Rosenheim 
- **Rostock, Mecklenburg-Vorpommern** (1): Hansa Rostock  (2) Rostock · FC Hansa Rostock
- **Saarbrücken, Saarland** (1): 1. FC Saarbrücken  (3) Saarbrucken · Saarbrücken · 1. FC Saarbruecken
- **Sandhausen, Baden-Württemberg** (1): SV Sandhausen  (2) Sandhausen · SV Sandhausen 1916
- **Schweinfurt, Bayern** (1): 1. FC Schweinfurt 05  (1) Schweinfurt
- **Siegen, Nordrhein-Westfalen** (1): SF Siegen  (2) Siegen · Sportfreunde Siegen
- **Sinsheim, Baden-Württemberg** (1): TSG 1899 Hoffenheim  (2) Hoffenheim · 1899 Hoffenheim
- **Trier, Rheinland-Pfalz** (1): Eintracht Trier  (1) Ein Trier
- **Ulm, Baden-Württemberg** (1): SSV Ulm 1846  (1) Ulm
- **Unterhaching, Bayern** (1): SpVgg Unterhaching  (2) U'haching · Unterhaching
- **Wiesbaden, Hessen** (1): SV Wehen Wiesbaden  (2) Wehen · Wiesbaden
- **Wolfsburg, Niedersachsen** (1): VfL Wolfsburg  (1) Wolfsburg
- **Wuppertal, Nordrhein-Westfalen** (1): Wuppertaler SV  (1) Wuppertaler
- **Würzburg, Bayern** (1): Würzburger Kickers  (1) FC Würzburger Kickers
- **Zwickau, Sachsen** (1): FSV Zwickau  (1) Zwickau
- ? (42): 
  - FV Illertissen 
  - SF Baumberg  (1) Sportfreunde Baumberg
  - SF Lotte  (1) Sportfreunde Lotte
  - SV Lippstadt 08 
  - SC Wiedenbrück  (1) SC Wiedenbrück 2000
  - FC Hennef 05 
  - TuS Erndtebrück 
  - SV Elversberg  (1) SV 07 Elversberg
  - FT Braunschweig  (1) Freie Turnerschaft Braunschweig
  - SV Wilhelmshaven 
  - BSV Schwarz-Weiß Rehden 
  - TSV Havelse 
  - FSV Optik Rathenow 
  - SV Falkensee-Finkenkrug 
  - Berliner AK 07 
  - FC Viktoria 1889 Berlin 
  - SC Victoria Hamburg  (1) Victoria Hamburg
  - USC Paloma Hamburg 
  - HSV Barmbek-Uhlenhorst 
  - SG Aumund-Vegesack 
  - FC Oberneuland 
  - Bremer SV 
  - SG Großaspach  (3) Großaspach · SG Sonnenhof Großaspach · Sportgemeinschaft Sonnenhof Großaspach
  - FC Nöttingen 
  - Bahlinger SC 
  - Neckarsulmer Sport-Union 
  - Offenburger FV 
  - FC-Astoria Walldorf 
  - SV Waldkirch 
  - KSV Hessen Kassel 
  - TSG Pfeddersheim 
  - SV Roßbach/Verscheid 
  - Wormatia Worms 
  - SV Alemannia Waldalgesheim 
  - FSV Salmrohr 
  - FK Pirmasens  (1) FK 03 Pirmasens
  - VfR Neumünster 
  - TSG Neustrelitz 
  - FC Schönberg 95 
  - 1\. FC Neubrandenburg 04 
  - Hallescher FC  (1) Halle
  - SV Schott Jena 




By Region

- **Bayern** (12):   Bayern München · TSV 1860 München · 1. FC Nürnberg · SpVgg Greuther Fürth · FC Augsburg · SpVgg Unterhaching · FC Ingolstadt 04 · SSV Jahn Regensburg · 1. FC Schweinfurt 05 · Würzburger Kickers · Wacker Burghausen · TSV 1860 Rosenheim
- **Nordrhein-Westfalen** (23):   1. FC Köln · Fortuna Köln · FC Viktoria Köln · Fortuna Düsseldorf · Borussia Dortmund · Borussia Dortmund II · FC Schalke 04 · Bayer 04 Leverkusen · MSV Duisburg · Bor. Mönchengladbach · VfL Bochum · SG Wattenscheid 09 · Arminia Bielefeld · Preußen Münster · Gütersloh · KFC Uerdingen · Alemannia Aachen · SC Paderborn 07 · Rot Weiss Ahlen · Rot-Weiß Oberhausen · SF Siegen · Wuppertaler SV · Rot-Weiss Essen
- **Saarland** (3):   1. FC Saarbrücken · FC 08 Homburg · VfB Borussia Neunkirchen
- **Niedersachsen** (6):   VfL Osnabrück · VfL Wolfsburg · Hannover 96 · Eintracht Braunschweig · SV Meppen · VfB Oldenburg
- **Brandenburg** (2):   Energie Cottbus · SV Babelsberg 03
- **Berlin** (6):   Hertha BSC · Tennis Borussia Berlin · 1. FC Union Berlin · Blau-Weiß 90 Berlin (-1992) · SC Tasmania 1900 Berlin (-1973) · BFC Dynamo Berlin
- **Hamburg** (2):   Hamburger SV · FC St. Pauli
- **Bremen** (2):   Werder Bremen · Werder Bremen II
- **Baden-Württemberg** (13):   VfB Stuttgart · VfB Stuttgart II · Stuttgarter Kickers · SC Freiburg · TSG 1899 Hoffenheim · Karlsruher SC · SSV Ulm 1846 · VfR Aalen · 1. FC Heidenheim · SSV Reutlingen 05 · SV Sandhausen · VfR Mannheim · SV Waldhof Mannheim
- **Hessen** (5):   Eintracht Frankfurt · FSV Frankfurt · SV Darmstadt 98 · SV Wehen Wiesbaden · Kickers Offenbach
- **Rheinland-Pfalz** (5):   1. FC Kaiserslautern · 1. FSV Mainz 05 · 1. FSV Mainz 05 II · Eintracht Trier · TuS Koblenz
- **Schleswig-Holstein** (2):   VfB Lübeck · Holstein Kiel
- **Mecklenburg-Vorpommern** (1):   Hansa Rostock
- **Sachsen** (6):   Dynamo Dresden · RB Leipzig · VfB Leipzig (-2004) · Chemnitzer FC · FC Erzgebirge Aue · FSV Zwickau
- **Sachsen-Anhalt** (1):   1. FC Magdeburg
- **Thüringen** (2):   FC Carl Zeiss Jena · FC Rot-Weiß Erfurt




By Year

- **1860** (1):   TSV 1860 München
- **1887** (1):   Hamburger SV
- **1892** (1):   Hertha BSC
- **1893** (1):   VfB Stuttgart
- **1894** (1):   Karlsruher SC
- **1895** (2):   Fortuna Düsseldorf · Eintracht Braunschweig
- **1896** (1):   Hannover 96
- **1898** (1):   SV Darmstadt 98
- **1899** (4):   Werder Bremen · TSG 1899 Hoffenheim · Eintracht Frankfurt · FSV Frankfurt
- **1900** (4):   Bayern München · 1. FC Nürnberg · Bor. Mönchengladbach · 1. FC Kaiserslautern
- **1903** (1):   SpVgg Greuther Fürth
- **1904** (3):   FC Schalke 04 · Bayer 04 Leverkusen · SC Freiburg
- **1905** (2):   Arminia Bielefeld · 1. FSV Mainz 05
- **1907** (3):   FC Augsburg · Würzburger Kickers · SC Paderborn 07
- **1909** (1):   Borussia Dortmund
- **1910** (1):   FC St. Pauli
- **1916** (1):   SV Sandhausen
- **1921** (1):   VfR Aalen
- **1938** (1):   VfL Bochum
- **1948** (2):   1. FC Köln · Fortuna Köln
- **1949** (1):   FC Erzgebirge Aue
- **1953** (1):   Dynamo Dresden
- **1965** (2):   Hansa Rostock · 1. FC Magdeburg
- **1966** (2):   Energie Cottbus · 1. FC Union Berlin
- **1994** (1):   SG Großaspach
- **2004** (1):   FC Ingolstadt 04
- **2007** (1):   1. FC Heidenheim
- **2009** (1):   RB Leipzig
- ? (90):   SpVgg Unterhaching · SSV Jahn Regensburg · 1. FC Schweinfurt 05 · Wacker Burghausen · TSV 1860 Rosenheim · FV Illertissen · FC Viktoria Köln · Borussia Dortmund II · MSV Duisburg · SG Wattenscheid 09 · Preußen Münster · Gütersloh · KFC Uerdingen · Alemannia Aachen · Rot Weiss Ahlen · Rot-Weiß Oberhausen · SF Siegen · Wuppertaler SV · Rot-Weiss Essen · SF Baumberg · SF Lotte · SV Lippstadt 08 · SC Wiedenbrück · FC Hennef 05 · TuS Erndtebrück · 1. FC Saarbrücken · FC 08 Homburg · VfB Borussia Neunkirchen · SV Elversberg · VfL Osnabrück · VfL Wolfsburg · FT Braunschweig · SV Meppen · VfB Oldenburg · SV Wilhelmshaven · BSV Schwarz-Weiß Rehden · TSV Havelse · SV Babelsberg 03 · FSV Optik Rathenow · SV Falkensee-Finkenkrug · Tennis Borussia Berlin · Blau-Weiß 90 Berlin (-1992) · SC Tasmania 1900 Berlin (-1973) · BFC Dynamo Berlin · Berliner AK 07 · FC Viktoria 1889 Berlin · SC Victoria Hamburg · USC Paloma Hamburg · HSV Barmbek-Uhlenhorst · Werder Bremen II · SG Aumund-Vegesack · FC Oberneuland · Bremer SV · VfB Stuttgart II · Stuttgarter Kickers · SSV Ulm 1846 · SSV Reutlingen 05 · VfR Mannheim · SV Waldhof Mannheim · FC Nöttingen · Bahlinger SC · Neckarsulmer Sport-Union · Offenburger FV · FC-Astoria Walldorf · SV Waldkirch · SV Wehen Wiesbaden · Kickers Offenbach · KSV Hessen Kassel · 1. FSV Mainz 05 II · Eintracht Trier · TuS Koblenz · TSG Pfeddersheim · SV Roßbach/Verscheid · Wormatia Worms · SV Alemannia Waldalgesheim · FSV Salmrohr · FK Pirmasens · VfB Lübeck · Holstein Kiel · VfR Neumünster · TSG Neustrelitz · FC Schönberg 95 · 1. FC Neubrandenburg 04 · VfB Leipzig (-2004) · Chemnitzer FC · FSV Zwickau · Hallescher FC · FC Carl Zeiss Jena · SV Schott Jena · FC Rot-Weiß Erfurt




Historic

- **1973** (1):   SC Tasmania 1900 Berlin (-1973)
- **1992** (1):   Blau-Weiß 90 Berlin (-1992)
- **2004** (1):   VfB Leipzig (-2004)






By A to Z

- **1** (16): 1. FC Köln · 1860 München · 1. FC Nürnberg · 1. FC K'lautern · 1. FC Magdeburg · 1. FSV Mainz 05 · 1899 Hoffenheim · 1. FC Heidenheim · 1. FC Saarbrücken · 1. FC Saarbruecken · 1. FC Union Berlin · 1. FSV Mainz 05 II · 1. FC Kaiserslautern · 1. FC Schweinfurt 05 · 1. FC Heidenheim 1846 · 1. FC Neubrandenburg 04
- **A** (7): Aue · Aalen · Ahlen · Aachen · Augsburg · Alemannia Aachen · Arminia Bielefeld
- **B** (34): Bayern · Bochum · Bremen · Bielefeld · Bremer SV · BFC Dynamo · Babelsberg · Burghausen · Bahlinger SC · Braunschweig · Bor. Dortmund · Bayern München · Berliner AK 07 · Bay. Leverkusen · Bayer Uerdingen · Bor. M'gladbach · Bayer Leverkusen · Bor. Dortmund II · BFC Dynamo Berlin · Borussia Dortmund · Bayer 05 Uerdingen · Bayern Munich [en] · Bayer 04 Leverkusen · Borussia M'gladbach · Blau-Weiss 90 Berlin · Bor. Mönchengladbach · Borussia Dortmund II · Borussia Neunkirchen · Bor. Moenchengladbach · BSV Schwarz-Weiß Rehden · BV 09 Borussia Dortmund · Borussia Monchengladbach · Borussia Mönchengladbach · Blau-Weiß 90 Berlin (-1992)
- **C** (4): CZ Jena · Cottbus · Chemnitz · Chemnitzer FC
- **D** (8): Dresden · Dortmund · Duisburg · Darmstadt · Düsseldorf · Dortmund II · Dynamo Dresden · DSC Arminia Bielefeld
- **E** (11): Essen · Erfurt · Ein Trier · E. Frankfurt · Ein Frankfurt · Erzgebirge Aue · Eintracht Trier · Energie Cottbus · Eintr. Braunschweig · Eintracht Frankfurt · Eintracht Braunschweig
- **F** (42): F Köln · FC Köln · Freiburg · FC Homburg · FC Augsburg · FSV Zwickau · FC Hennef 05 · FC Nöttingen · FC St. Pauli · FK Pirmasens · FSV Mainz 05 · FSV Salmrohr · Fortuna Köln · F. Düsseldorf · FC 08 Homburg · FC Schalke 04 · FSV Frankfurt · Frankfurt FSV · FC Oberneuland · FC Sankt Pauli · FV Illertissen · FC Homburg/Saar · FC Schönberg 95 · FK 03 Pirmasens · FT Braunschweig · FC Hansa Rostock · FC Ingolstadt 04 · FC Viktoria Köln · FC Bayern München · FC Erzgebirge Aue · FC Carl Zeiss Jena · FC Energie Cottbus · FC Rot-Weiß Erfurt · FSV Frankfurt 1899 · FSV Optik Rathenow · Fortuna Düsseldorf · FC-Astoria Walldorf · FC Bayer 05 Uerdingen · FC Bayern Munich [en] · FC Würzburger Kickers · FC Viktoria 1889 Berlin · Freie Turnerschaft Braunschweig
- **G** (3): Gütersloh · Großaspach · Greuther Fürth
- **H** (17): Halle · Hertha · Hamburg · Homburg · Hannover · Heidenheim · Hertha BSC · Hoffenheim · Hannover 96 · Hamburger SV · Hallescher FC · Hannover 1896 · Hansa Rostock · Holstein Kiel · Hertha BSC Berlin · HSV Barmbek-Uhlenhorst · Hertha Berliner Sport-Club
- **I** (1): Ingolstadt
- **J** (1): Jahn Regensburg
- **K** (10): Kiel · Koblenz · K'lautern · Karlsruhe · KFC Uerdingen · Karlsruher SC · Kaiserslautern · KFC Uerdingen 05 · KSV Hessen Kassel · Kickers Offenbach
- **L** (4): Lubeck · Lübeck · Leipzig · Leverkusen
- **M** (10): Mainz · Meppen · Münster · Mannheim · Magdeburg · M'Gladbach · MSV Duisburg · Meidericher SV · Mönchengladbach · Munich 1860 [en]
- **N** (2): Nürnberg · Neckarsulmer Sport-Union
- **O** (5): Offenbach · Oldenburg · Osnabruck · Oberhausen · Offenburger FV
- **P** (2): Paderborn · Preußen Münster
- **R** (11): Rostock · RW Essen · RW Erfurt · RB Leipzig · Regensburg · Reutlingen · Rot Weiss Ahlen · Rot-Weiss Essen · Rot-Weiß Erfurt · Rot-Weiß Oberhausen · Rot-Weiss Oberhausen
- **S** (60): Siegen · Schalke · SF Lotte · St Pauli · SF Siegen · SV Meppen · St. Pauli · Stuttgart · Sandhausen · Schalke 04 · SC Freiburg · SF Baumberg · Saarbrucken · Saarbrücken · Schweinfurt · SSV Ulm 1846 · SV Waldkirch · Stutt. Kick. · Stuttgart II · SC Preußen 06 · SG Großaspach · SV Elversberg · SV Sandhausen · Stuttgarter K · SC Wiedenbrück · SV Schott Jena · SC Fortuna Köln · SC Paderborn 07 · SV Darmstadt 98 · SV Lippstadt 08 · SV 07 Elversberg · SV Babelsberg 03 · SV Werder Bremen · SV Wilhelmshaven · SG Dynamo Dresden · SSV Reutlingen 05 · SC Preußen Münster · SG Aumund-Vegesack · SG Wattenscheid 09 · SV Sandhausen 1916 · SV Wehen Wiesbaden · SpVgg Unterhaching · Sportfreunde Lotte · SC Victoria Hamburg · SC Wiedenbrück 2000 · SSV Jahn Regensburg · SV Waldhof Mannheim · Sportfreunde Siegen · Stuttgarter Kickers · SV Roßbach/Verscheid · SpVgg Greuther Fürth · Sportfreunde Baumberg · SG Eintracht Frankfurt · SV Waldhof Mannheim 07 · Sportclub Fortuna Köln · SG Sonnenhof Großaspach · SV Falkensee-Finkenkrug · SV Alemannia Waldalgesheim · SC Tasmania 1900 Berlin (-1973) · Sportgemeinschaft Sonnenhof Großaspach
- **T** (16): TB Berlin · TSV Havelse · TeBe Berlin · TuS Koblenz · TSG Neustrelitz · Tasmania Berlin · TuS Erndtebrück · TSG Pfeddersheim · TSV 1860 München · TSV München 1860 · TSV 1860 Rosenheim · TSG 1899 Hoffenheim · TSV 1860 Munich [en] · TSV Alemannia Aachen · Tasmania 1900 Berlin · Tennis Borussia Berlin
- **U** (6): Ulm · U'haching · Uerdingen · Union Berlin · Unterhaching · USC Paloma Hamburg
- **V** (15): VfR Aalen · VfB Lübeck · VfL Bochum · VfR Mannheim · VfB Oldenburg · VfB Stuttgart · VfL Osnabrück · VfL Wolfsburg · VfR Neumünster · VfL Bochum 1848 · VfB Stuttgart II · Victoria Hamburg · VfB Leipzig (-2004) · VfB Borussia Neunkirchen · VfL Borussia Mönchengladbach
- **W** (13): Wehen · Wiesbaden · Wolfsburg · Wuppertaler · Wattenscheid · Werder Bremen · Wormatia Worms · Wuppertaler SV · Wattenscheid 09 · Waldhof Mannheim · Werder Bremen II · Wacker Burghausen · Würzburger Kickers
- **Z** (1): Zwickau




