8 clubs

- **FC Levadia Tallinn** : (2) Levadia · Levadia Tallinn
- **FC Flora Tallinn** : (1) Flora
- **FC TVMK Tallinn**
- **FCI Tallinn**
- **JK Trans Narva** : (1) JK Narva Trans
- **JK Nõmme Kalju** : (2) Kalju · Nõmme Kalju FC ⇒ (2) ≈JK Nomme Kalju≈ · ≈Nomme Kalju FC≈
- **JK Sillamäe Kalev** ⇒ (2) ≈JK Sillamae Kalev≈ · ≈JK Sillamaee Kalev≈
- **FC Santos Tartu**




Alphabet

- **Alphabet Specials** (2):  **ä**  **õ** 
  - **ä**×1 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **õ**×2 U+00F5 (245) - LATIN SMALL LETTER O WITH TILDE ⇒ o




Duplicates





By City

- ? (8): 
  - FC Levadia Tallinn  (2) Levadia · Levadia Tallinn
  - FC Flora Tallinn  (1) Flora
  - FC TVMK Tallinn 
  - FCI Tallinn 
  - JK Trans Narva  (1) JK Narva Trans
  - JK Nõmme Kalju  (2) Kalju · Nõmme Kalju FC
  - JK Sillamäe Kalev 
  - FC Santos Tartu 




By Region





By Year

- ? (8):   FC Levadia Tallinn · FC Flora Tallinn · FC TVMK Tallinn · FCI Tallinn · JK Trans Narva · JK Nõmme Kalju · JK Sillamäe Kalev · FC Santos Tartu






By A to Z

- **F** (6): Flora · FCI Tallinn · FC Santos Tartu · FC TVMK Tallinn · FC Flora Tallinn · FC Levadia Tallinn
- **J** (4): JK Narva Trans · JK Nõmme Kalju · JK Trans Narva · JK Sillamäe Kalev
- **K** (1): Kalju
- **L** (2): Levadia · Levadia Tallinn
- **N** (1): Nõmme Kalju FC




