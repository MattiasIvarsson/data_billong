13 clubs

- [**PFC CSKA Sofia**](https://en.wikipedia.org/wiki/PFC_CSKA_Sofia) : (4) CSKA Sofia · CDNA Sofia · CSKA-Sofia · PFC CSKA-Sofia
- [**PFC Levski Sofia**](https://en.wikipedia.org/wiki/PFC_Levski_Sofia) : (3) Levski · Levski Sofia · Professional Football Club Levski Sofia
- [**PFC Slavia Sofia**](https://en.wikipedia.org/wiki/PFC_Slavia_Sofia) : (2) Slavia Sofia · Professional Football Club Slavia Sofia
- [**PFC Lokomotiv Sofia**](https://en.wikipedia.org/wiki/PFC_Lokomotiv_Sofia) : (1) Lokomotiv Sofia
- [**PFC Botev Plovdiv**](https://en.wikipedia.org/wiki/PFC_Botev_Plovdiv) : (1) Botev Plovdiv
- [**PFC Lokomotiv Plovdiv**](https://en.wikipedia.org/wiki/PFC_Lokomotiv_Plovdiv) : (2) Lokomotiv Plovdiv · PFC Lokomotiv Plovdiv 1936
- [**PFC Litex Lovech**](https://en.wikipedia.org/wiki/PFC_Litex_Lovech) : (2) Litex · Professional Football Club Litex Lovech
- [**PFC Cherno More Varna**](https://en.wikipedia.org/wiki/PFC_Cherno_More_Varna) : (1) Cherno More
- [**PFC Ludogorets Razgrad**](https://en.wikipedia.org/wiki/PFC_Ludogorets_Razgrad) : (4) Ludogorets · Ludogorets Razgrad · PFC Ludogorets 1945 · Professional Football Club Ludogorets Razgrad
- [**PFC Beroe Stara Zagora**](https://en.wikipedia.org/wiki/PFC_Beroe_Stara_Zagora) : (2) Beroe · Professional Football Club Beroe
- [**PFC Montana**](https://en.wikipedia.org/wiki/PFC_Montana) : (3) Montana · PFC Montana 1921 · Professional Football Club Montana
- [**FC Pirin Blagoevgrad**](https://en.wikipedia.org/wiki/FC_Pirin_Blagoevgrad) : (2) Blagoevgrad · PFC Pirin Blagoevgrad
- **FC Dunav Ruse** : (2) Dunav · FC Dunav




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **PFC CSKA Sofia**, Sofia (2):
  - `pfccskasofia` (2): PFC CSKA Sofia · PFC CSKA-Sofia
  - `cskasofia` (2): CSKA Sofia · CSKA-Sofia




By City

- **Sofia** (4): 
  - PFC CSKA Sofia  (4) CSKA Sofia · CDNA Sofia · PFC CSKA-Sofia · CSKA-Sofia
  - PFC Levski Sofia  (3) Levski Sofia · Levski · Professional Football Club Levski Sofia
  - PFC Slavia Sofia  (2) Slavia Sofia · Professional Football Club Slavia Sofia
  - PFC Lokomotiv Sofia  (1) Lokomotiv Sofia
- **Plovdiv** (2): 
  - PFC Botev Plovdiv  (1) Botev Plovdiv
  - PFC Lokomotiv Plovdiv  (2) Lokomotiv Plovdiv · PFC Lokomotiv Plovdiv 1936
- **Blagoevgrad** (1): FC Pirin Blagoevgrad  (2) Blagoevgrad · PFC Pirin Blagoevgrad
- **Lovech** (1): PFC Litex Lovech  (2) Litex · Professional Football Club Litex Lovech
- **Montana** (1): PFC Montana  (3) Montana · PFC Montana 1921 · Professional Football Club Montana
- **Razgrad** (1): PFC Ludogorets Razgrad  (4) Ludogorets · Ludogorets Razgrad · Professional Football Club Ludogorets Razgrad · PFC Ludogorets 1945
- **Ruse** (1): FC Dunav Ruse  (2) FC Dunav · Dunav
- **Stara Zagora** (1): PFC Beroe Stara Zagora  (2) Beroe · Professional Football Club Beroe
- **Varna** (1): PFC Cherno More Varna  (1) Cherno More




By Region

- **Sofia†** (4):   PFC CSKA Sofia · PFC Levski Sofia · PFC Slavia Sofia · PFC Lokomotiv Sofia
- **Plovdiv†** (2):   PFC Botev Plovdiv · PFC Lokomotiv Plovdiv
- **Lovech†** (1):   PFC Litex Lovech
- **Varna†** (1):   PFC Cherno More Varna
- **Razgrad†** (1):   PFC Ludogorets Razgrad
- **Stara Zagora†** (1):   PFC Beroe Stara Zagora
- **Montana†** (1):   PFC Montana
- **Blagoevgrad†** (1):   FC Pirin Blagoevgrad
- **Ruse†** (1):   FC Dunav Ruse




By Year

- **1912** (1):   PFC Botev Plovdiv
- **1913** (2):   PFC Slavia Sofia · PFC Cherno More Varna
- **1914** (1):   PFC Levski Sofia
- **1916** (1):   PFC Beroe Stara Zagora
- **1921** (2):   PFC Litex Lovech · PFC Montana
- **1922** (1):   FC Pirin Blagoevgrad
- **1926** (1):   PFC Lokomotiv Plovdiv
- **1929** (1):   PFC Lokomotiv Sofia
- **1945** (1):   PFC Ludogorets Razgrad
- **1948** (1):   PFC CSKA Sofia
- **1949** (1):   FC Dunav Ruse






By A to Z

- **B** (3): Beroe · Blagoevgrad · Botev Plovdiv
- **C** (4): CDNA Sofia · CSKA Sofia · CSKA-Sofia · Cherno More
- **D** (1): Dunav
- **F** (3): FC Dunav · FC Dunav Ruse · FC Pirin Blagoevgrad
- **L** (7): Litex · Levski · Ludogorets · Levski Sofia · Lokomotiv Sofia · Lokomotiv Plovdiv · Ludogorets Razgrad
- **M** (1): Montana
- **P** (22): PFC Montana · PFC CSKA Sofia · PFC CSKA-Sofia · PFC Levski Sofia · PFC Litex Lovech · PFC Montana 1921 · PFC Slavia Sofia · PFC Botev Plovdiv · PFC Lokomotiv Sofia · PFC Ludogorets 1945 · PFC Cherno More Varna · PFC Lokomotiv Plovdiv · PFC Pirin Blagoevgrad · PFC Beroe Stara Zagora · PFC Ludogorets Razgrad · PFC Lokomotiv Plovdiv 1936 · Professional Football Club Beroe · Professional Football Club Montana · Professional Football Club Levski Sofia · Professional Football Club Litex Lovech · Professional Football Club Slavia Sofia · Professional Football Club Ludogorets Razgrad
- **S** (1): Slavia Sofia




