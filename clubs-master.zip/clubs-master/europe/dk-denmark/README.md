19 clubs

- [**FC København**](https://en.wikipedia.org/wiki/F.C._Copenhagen) : (4) Kobenhavn · København · FC Copenhagen · Football Club København ⇒ (3) ≈Kobenhavn≈ · ≈FC Kobenhavn≈ · ≈Football Club Kobenhavn≈
- [**Brøndby IF**](https://en.wikipedia.org/wiki/Brøndby_IF) : (4) Brondby · Brøndby · Brondby IF · Brøndbyernes Idrætsforening ⇒ (3) ≈Brondby≈ · ≈Brondby IF≈ · ≈Brondbyernes Idraetsforening≈
- [**FC Nordsjælland**](https://en.wikipedia.org/wiki/FC_Nordsjælland) : (3) Nordsjælland · Nordsjaelland · Football Club Nordsjælland ⇒ (3) ≈Nordsjaelland≈ · ≈FC Nordsjaelland≈ · ≈Football Club Nordsjaelland≈
- **FC Helsingør** : (2) Helsingør · Helsingor ⇒ (2) ≈Helsingor≈ · ≈FC Helsingor≈
- **Lyngby BK** : (2) Lyngby · Lyngby Boldklub
- [**Aalborg BK**](https://en.wikipedia.org/wiki/Aalborg_Boldspilklub) : (3) AaB · Aalborg · Aalborg Boldspilklub
- [**Hobro IK**](https://en.wikipedia.org/wiki/Hobro_IK) : (2) Hobro · Hobro Idræts Klub ⇒ (1) ≈Hobro Idraets Klub≈
- **Vendsyssel FF** : (1) Vendsyssel
- [**FC Midtjylland**](https://en.wikipedia.org/wiki/FC_Midtjylland) : (2) Midtjylland · Football Club Midtjylland
- [**AGF Aarhus**](https://en.wikipedia.org/wiki/Aarhus_Gymnastikforening) : (3) AGF · Aarhus · Aarhus Gymnastikforening
- [**Viborg FF**](https://en.wikipedia.org/wiki/Viborg_FF) : (2) Viborg · Viborg Fodsports Forening
- **AC Horsens** : (1) Horsens
- **Silkeborg IF** : (3) SIF · Silkeborg · Silkeborg Idrætsforening ⇒ (1) ≈Silkeborg Idraetsforening≈
- [**Randers FC**](https://en.wikipedia.org/wiki/Randers_FC) : (2) Randers · Randers Football Club
- [**Sønderjysk Elitesport**](https://en.wikipedia.org/wiki/SønderjyskE_Fodbold) : (3) Sonderjyske · SønderjyskE · SønderjyskE Fodbold ⇒ (3) ≈SonderjyskE≈ · ≈SonderjyskE Fodbold≈ · ≈Sonderjysk Elitesport≈
- [**Odense BK**](https://en.wikipedia.org/wiki/Odense_Boldklub) : (3) OB · Odense · Odense Boldklub
- [**Esbjerg fB**](https://en.wikipedia.org/wiki/Esbjerg_fB) : (2) Esbjerg · Esbjerg forenede Boldklubber
- **Vejle** : (1) Vejle Boldklub
- **FC Vestsjælland** : (1) Vestsjaelland ⇒ (1) ≈FC Vestsjaelland≈




Alphabet

- **Alphabet Specials** (2):  **æ**  **ø** 
  - **æ**×7 U+00E6 (230) - LATIN SMALL LETTER AE ⇒ ae
  - **ø**×11 U+00F8 (248) - LATIN SMALL LETTER O WITH STROKE ⇒ o




Duplicates

- **FC København**, København (1):
  - `kobenhavn` (2): **Kobenhavn** · **Kobenhavn**
- **Brøndby IF**, Brøndbyvester (2):
  - `brondby` (2): **Brondby** · **Brondby**
  - `brondbyif` (2): **Brondby IF** · **Brondby IF**
- **FC Nordsjælland**, Farum (1):
  - `nordsjaelland` (2): **Nordsjaelland** · **Nordsjaelland**
- **FC Helsingør**, Helsingør (1):
  - `helsingor` (2): **Helsingor** · **Helsingor**
- **Sønderjysk Elitesport**, Haderslev (1):
  - `sonderjyske` (2): Sonderjyske · SonderjyskE




By City

- **Aalborg, Nordjylland** (1): Aalborg BK  (3) AaB · Aalborg · Aalborg Boldspilklub
- **Aarhus, Midtjylland** (1): AGF Aarhus  (3) AGF · Aarhus · Aarhus Gymnastikforening
- **Brøndbyvester, Hovedstaden** (1): Brøndby IF  (4) Brondby · Brøndby · Brondby IF · Brøndbyernes Idrætsforening
- **Esbjerg, Syddanmark** (1): Esbjerg fB  (2) Esbjerg · Esbjerg forenede Boldklubber
- **Farum, Hovedstaden** (1): FC Nordsjælland  (3) Nordsjaelland · Nordsjælland · Football Club Nordsjælland
- **Haderslev, Syddanmark** (1): Sønderjysk Elitesport  (3) Sonderjyske · SønderjyskE · SønderjyskE Fodbold
- **Helsingør, Hovedstaden** (1): FC Helsingør  (2) Helsingør · Helsingor
- **Herning, Midtjylland** (1): FC Midtjylland  (2) Midtjylland · Football Club Midtjylland
- **Hjørring, Nordjylland** (1): Vendsyssel FF  (1) Vendsyssel
- **Hobro, Nordjylland** (1): Hobro IK  (2) Hobro · Hobro Idræts Klub
- **Horsens, Midtjylland** (1): AC Horsens  (1) Horsens
- **København, Hovedstaden** (1): FC København  (4) Kobenhavn · København · Football Club København · FC Copenhagen
- **Lyngby, Hovedstaden** (1): Lyngby BK  (2) Lyngby · Lyngby Boldklub
- **Odense, Syddanmark** (1): Odense BK  (3) OB · Odense · Odense Boldklub
- **Randers, Østjylland** (1): Randers FC  (2) Randers · Randers Football Club
- **Silkeborg, Midtjylland** (1): Silkeborg IF  (3) Silkeborg · SIF · Silkeborg Idrætsforening
- **Slagelse, Sjælland** (1): FC Vestsjælland  (1) Vestsjaelland
- **Vejle, Syddanmark** (1): Vejle  (1) Vejle Boldklub
- **Viborg, Midtjylland** (1): Viborg FF  (2) Viborg · Viborg Fodsports Forening




By Region

- **Hovedstaden** (5):   FC København · Brøndby IF · FC Nordsjælland · FC Helsingør · Lyngby BK
- **Nordjylland** (3):   Aalborg BK · Hobro IK · Vendsyssel FF
- **Midtjylland** (5):   FC Midtjylland · AGF Aarhus · Viborg FF · AC Horsens · Silkeborg IF
- **Østjylland** (1):   Randers FC
- **Syddanmark** (4):   Sønderjysk Elitesport · Odense BK · Esbjerg fB · Vejle
- **Sjælland** (1):   FC Vestsjælland




By Year

- **1880** (1):   AGF Aarhus
- **1885** (1):   Aalborg BK
- **1887** (1):   Odense BK
- **1891** (1):   Vejle
- **1896** (1):   Viborg FF
- **1913** (1):   Hobro IK
- **1917** (1):   Silkeborg IF
- **1921** (1):   Lyngby BK
- **1924** (1):   Esbjerg fB
- **1964** (1):   Brøndby IF
- **1991** (1):   FC Nordsjælland
- **1992** (1):   FC København
- **1999** (1):   FC Midtjylland
- **2003** (1):   Randers FC
- **2004** (1):   Sønderjysk Elitesport
- **2005** (1):   FC Helsingør
- ? (3):   Vendsyssel FF · AC Horsens · FC Vestsjælland






By A to Z

- **A** (9): AGF · AaB · Aarhus · Aalborg · AC Horsens · AGF Aarhus · Aalborg BK · Aalborg Boldspilklub · Aarhus Gymnastikforening
- **B** (5): Brondby · Brøndby · Brondby IF · Brøndby IF · Brøndbyernes Idrætsforening
- **E** (3): Esbjerg · Esbjerg fB · Esbjerg forenede Boldklubber
- **F** (9): FC Helsingør · FC København · FC Copenhagen · FC Midtjylland · FC Nordsjælland · FC Vestsjælland · Football Club København · Football Club Midtjylland · Football Club Nordsjælland
- **H** (6): Hobro · Horsens · Hobro IK · Helsingor · Helsingør · Hobro Idræts Klub
- **K** (2): Kobenhavn · København
- **L** (3): Lyngby · Lyngby BK · Lyngby Boldklub
- **M** (1): Midtjylland
- **N** (2): Nordsjælland · Nordsjaelland
- **O** (4): OB · Odense · Odense BK · Odense Boldklub
- **R** (3): Randers · Randers FC · Randers Football Club
- **S** (8): SIF · Silkeborg · Sonderjyske · SønderjyskE · Silkeborg IF · SønderjyskE Fodbold · Sønderjysk Elitesport · Silkeborg Idrætsforening
- **V** (8): Vejle · Viborg · Viborg FF · Vendsyssel · Vendsyssel FF · Vestsjaelland · Vejle Boldklub · Viborg Fodsports Forening




