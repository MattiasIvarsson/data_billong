12 clubs

- **FC Dinamo Tbilisi** : (1) Dinamo Tbilisi
- **FC Zestafoni**
- **FC Metalurgi Rustavi**
- **FC Dila Gori**
- **FC WIT Georgia**
- **FC Gagra**
- **FC Torpedo Kutaisi**
- **FC Chikhura Sachkhere**
- **FC Samtredia**
- **FC Dinamo Batumi**
- **FC Tskhinvali**
- **FC Sioni Bolnisi**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Tbilisi** (1): FC Dinamo Tbilisi  (1) Dinamo Tbilisi
- ? (11): 
  - FC Zestafoni 
  - FC Metalurgi Rustavi 
  - FC Dila Gori 
  - FC WIT Georgia 
  - FC Gagra 
  - FC Torpedo Kutaisi 
  - FC Chikhura Sachkhere 
  - FC Samtredia 
  - FC Dinamo Batumi 
  - FC Tskhinvali 
  - FC Sioni Bolnisi 




By Region

- **Tbilisi†** (1):   FC Dinamo Tbilisi




By Year

- ? (12):   FC Dinamo Tbilisi · FC Zestafoni · FC Metalurgi Rustavi · FC Dila Gori · FC WIT Georgia · FC Gagra · FC Torpedo Kutaisi · FC Chikhura Sachkhere · FC Samtredia · FC Dinamo Batumi · FC Tskhinvali · FC Sioni Bolnisi






By A to Z

- **D** (1): Dinamo Tbilisi
- **F** (12): FC Gagra · FC Dila Gori · FC Samtredia · FC Zestafoni · FC Tskhinvali · FC WIT Georgia · FC Dinamo Batumi · FC Sioni Bolnisi · FC Dinamo Tbilisi · FC Torpedo Kutaisi · FC Metalurgi Rustavi · FC Chikhura Sachkhere




