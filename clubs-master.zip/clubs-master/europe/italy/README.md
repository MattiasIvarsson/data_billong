83 clubs

- [**AS Roma**](https://en.wikipedia.org/wiki/A.S._Roma) : (2) Roma · Associazione Sportiva Roma
- [**SS Lazio**](https://en.wikipedia.org/wiki/S.S._Lazio) : (3) Lazio · Lazio Roma · Società Sportiva Lazio ⇒ (1) ≈Societa Sportiva Lazio≈
- [**AC Milan**](https://en.wikipedia.org/wiki/A.C._Milan) : (2) Milan · Associazione Calcio Milan
- [**FC Internazionale Milano**](https://en.wikipedia.org/wiki/Inter_Milan) : (3) Inter · Inter Milan · Internazionale
- [**Torino FC**](https://en.wikipedia.org/wiki/Torino_F.C.) : (2) Torino · Torino Football Club
- [**Juventus**](https://en.wikipedia.org/wiki/Juventus_F.C.) : (3) Juventus FC · Juventus Torino · Juventus Football Club
- **Hellas Verona FC** : (4) Verona · Hellas Verona · Hellas Verona F.C. · Hellas Verona Football Club
- [**AC Chievo Verona**](https://en.wikipedia.org/wiki/A.C._ChievoVerona) : (3) Chievo · Chievo Verona · Associazione Calcio Chievo Verona
- [**Genoa CFC**](https://en.wikipedia.org/wiki/Genoa_C.F.C.) : (2) Genoa · Genoa Cricket and Football Club
- [**UC Sampdoria**](https://en.wikipedia.org/wiki/U.C._Sampdoria) : (3) Sampdoria · Sampdoria Genoa · Unione Calcio Sampdoria
- [**Atalanta BC**](https://en.wikipedia.org/wiki/Atalanta_B.C.) : (3) Atalanta · Atalanta Bergamo · Atalanta Bergamasca Calcio
- **Benevento** : (1) Benevento Calcio
- [**Bologna FC**](https://en.wikipedia.org/wiki/Bologna_F.C._1909) : (4) Bologna · FC Bologna · Bologna F.C. 1909 · Bologna Football Club 1909
- [**Cagliari Calcio**](https://en.wikipedia.org/wiki/Cagliari_Calcio) : (1) Cagliari
- **FC Crotone** : (3) Crotone · Crotone FC · Federazione Calcistica Crotone
- [**ACF Fiorentina**](https://en.wikipedia.org/wiki/ACF_Fiorentina) : (3) Fiorentina · AC Firenze · Associazione Calcio Firenze Fiorentina
- [**SSC Napoli**](https://en.wikipedia.org/wiki/S.S.C._Napoli) : (2) Napoli · Società Sportiva Calcio Napoli ⇒ (1) ≈Societa Sportiva Calcio Napoli≈
- [**US Sassuolo Calcio**](https://en.wikipedia.org/wiki/U.S._Sassuolo_Calcio) : (3) Sassuolo · U.S. Sassuolo Calcio · Unione Sportiva Sassuolo Calcio
- [**SPAL**](https://en.wikipedia.org/wiki/S.P.A.L.) : (3) Spal · S.P.A.L. 2013 · SPAL 2013 Ferrara
- [**Udinese Calcio**](https://en.wikipedia.org/wiki/Udinese_Calcio) : (1) Udinese
- **Ascoli**
- **Avellino**
- **Bari**
- **Brescia**
- **Carpi** : (2) Carpi FC 1909 · Carpi Football Club 1909
- **Cesena** : (2) AC Cesena · Associazione Calcio Cesena
- **Cittadella**
- **Cremonese**
- [**Empoli**](https://en.wikipedia.org/wiki/Empoli_F.C.) : (2) Empoli FC · Empoli Football Club
- **Foggia**
- [**Frosinone**](https://en.wikipedia.org/wiki/Frosinone_Calcio) : (1) Frosinone Calcio
- **Novara**
- **Palermo** : (2) US Palermo · Unione Sportiva Città di Palermo ⇒ (1) ≈Unione Sportiva Citta di Palermo≈
- [**Parma**](https://en.wikipedia.org/wiki/Parma_Calcio_1913) : (3) Parma FC · Parma Calcio 1913 · Parma Football Club
- **Perugia**
- **Pescara** : (1) Pescara Calcio
- **Pro Vercelli**
- **Salernitana**
- **Spezia**
- **Ternana**
- **Venezia**
- **Virtus Entella**
- **Piacenza Calcio** : (2) Piacenza · Piacenza Calcio 1919
- **LR Vicenza Virtus** : (1) Vicenza
- **Calcio Padova** : (1) Padova
- **Modena FC** : (1) Modena
- **SS Robur Siena** : (3) Siena · AC Siena · Associazione Calcio Siena
- **US Anconitana ASD** : (1) Ancona
- **Cosenza Calcio** : (1) Cosenza
- **SS Fidelis Andria** : (2) F. Andria · SS Fidelis Andria 1928
- **US Lecce** : (1) Lecce
- **AS Lucchese Libertas** : (2) Lucchese · AS Lucchese Libertas 1905
- **SS Monza** : (2) Monza · SS Monza 1912
- **Ravenna FC** : (2) Ravenna · Ravenna FC 1913
- **AC Reggiana** : (2) Reggiana · AC Reggiana 1919
- **Urbs Reggina** : (2) Reggina · Urbs Reggina 1914
- **ACD Treviso** : (1) Treviso
- **ASD Castel di Sangro** : (1) C. Sangro
- **Unione Calcio Albinoleffe** : (1) Albinoleffe
- **Calcio Catania** : (1) Catania
- **Como 1907** : (1) Como
- **AS Livorno Calcio** : (4) Livorno · AS Livorno · A.S. Livorno Calcio · Associazione Sportiva Livorno Calcio
- **ACR Messina SSD** : (1) Messina
- **US Triestina Calcio** : (2) Triestina · US Triestina Calcio 1918
- **SS Arezzo** : (1) Arezzo
- **US Catanzaro** : (2) Catanzaro · US Catanzaro 1929
- **ASD Virtus Bergamo** : (4) Alzano · Virtus Bergamo · Alzano Virescit · ASD Virtus Bergamo 1909
- **MC Fermana FC** : (1) Fermana
- **Gallipoli Football SSD** : (2) Gallipoli · Gallipoli Football 1909 SSD
- **ASD US Grosseto** : (2) Grosseto · ASD US Grosseto 1912
- **AS Gubbio** : (2) Gubbio · AS Gubbio 1910
- **SS Juve Stabia** : (1) Juve Stabia
- **SSD Latina Calcio** : (2) Latina · SSD Latina Calcio 1932
- **Mantova SSD** : (2) Mantova · Mantova 1911 SSD
- **ASD Nocerina** : (2) Nocerina · ASD Nocerina 1910
- **AC Pisa** : (2) Pisa · AC Pisa 1909
- **US Pistoiese** : (2) Pistoiese · US Pistoiese 1921
- **Portogruaro Calcio ASD** : (1) Portogruaro
- **Rimini FC SSD** : (2) Rimini · Rimini FC 1912 SSD
- **ASD Savoia** : (2) Savoia · ASD Savoia 1908
- **Trapani Calcio** : (1) Trapani
- **Varese Calcio** : (1) Varese
- **Virtus Lanciano** : (1) ASD 1920 Lanciano Calcio




Alphabet

- **Alphabet Specials** (1):  **à** 
  - **à**×3 U+00E0 (224) - LATIN SMALL LETTER A WITH GRAVE ⇒ a




Duplicates

- **Hellas Verona FC**, Verona (1):
  - `hellasveronafc` (2): Hellas Verona FC · Hellas Verona F.C.
- **US Sassuolo Calcio**, Sassuolo (1):
  - `ussassuolocalcio` (2): US Sassuolo Calcio · U.S. Sassuolo Calcio
- **SPAL**, Ferrara (1):
  - `spal` (2): SPAL · Spal
- **AS Livorno Calcio**, Livorno (1):
  - `aslivornocalcio` (2): AS Livorno Calcio · A.S. Livorno Calcio




By City

- **Genova** (2): 
  - Genoa CFC  (2) Genoa · Genoa Cricket and Football Club
  - UC Sampdoria  (3) Sampdoria · Sampdoria Genoa · Unione Calcio Sampdoria
- **Milano** (2): 
  - AC Milan  (2) Milan · Associazione Calcio Milan
  - FC Internazionale Milano  (3) Inter · Internazionale · Inter Milan
- **Roma** (2): 
  - AS Roma  (2) Roma · Associazione Sportiva Roma
  - SS Lazio  (3) Lazio · Lazio Roma · Società Sportiva Lazio
- **Torino** (2): 
  - Torino FC  (2) Torino · Torino Football Club
  - Juventus  (3) Juventus Torino · Juventus FC · Juventus Football Club
- **Verona** (2): 
  - Hellas Verona FC  (4) Verona · Hellas Verona · Hellas Verona F.C. · Hellas Verona Football Club
  - AC Chievo Verona  (3) Chievo · Chievo Verona · Associazione Calcio Chievo Verona
- **Albino e Leffe** (1): Unione Calcio Albinoleffe  (1) Albinoleffe
- **Alzano Lombardo** (1): ASD Virtus Bergamo  (4) Alzano · ASD Virtus Bergamo 1909 · Virtus Bergamo · Alzano Virescit
- **Ancona** (1): US Anconitana ASD  (1) Ancona
- **Andria** (1): SS Fidelis Andria  (2) F. Andria · SS Fidelis Andria 1928
- **Arezzo** (1): SS Arezzo  (1) Arezzo
- **Ascoli Piceno** (1): Ascoli 
- **Avellino** (1): Avellino 
- **Bari** (1): Bari 
- **Benevento** (1): Benevento  (1) Benevento Calcio
- **Bergamo** (1): Atalanta BC  (3) Atalanta · Atalanta Bergamo · Atalanta Bergamasca Calcio
- **Bologna** (1): Bologna FC  (4) Bologna · FC Bologna · Bologna F.C. 1909 · Bologna Football Club 1909
- **Brescia** (1): Brescia 
- **Cagliari** (1): Cagliari Calcio  (1) Cagliari
- **Carpi** (1): Carpi  (2) Carpi FC 1909 · Carpi Football Club 1909
- **Castel di Sangro** (1): ASD Castel di Sangro  (1) C. Sangro
- **Castellammare di Stabia** (1): SS Juve Stabia  (1) Juve Stabia
- **Catania** (1): Calcio Catania  (1) Catania
- **Catanzaro** (1): US Catanzaro  (2) Catanzaro · US Catanzaro 1929
- **Cesena** (1): Cesena  (2) AC Cesena · Associazione Calcio Cesena
- **Chiavari** (1): Virtus Entella 
- **Cittadella** (1): Cittadella 
- **Como** (1): Como 1907  (1) Como
- **Cosenza** (1): Cosenza Calcio  (1) Cosenza
- **Cremona** (1): Cremonese 
- **Crotone** (1): FC Crotone  (3) Crotone · Crotone FC · Federazione Calcistica Crotone
- **Empoli** (1): Empoli  (2) Empoli FC · Empoli Football Club
- **Fermo** (1): MC Fermana FC  (1) Fermana
- **Ferrara** (1): SPAL  (3) Spal · SPAL 2013 Ferrara · S.P.A.L. 2013
- **Firenze** (1): ACF Fiorentina  (3) Fiorentina · AC Firenze · Associazione Calcio Firenze Fiorentina
- **Foggia** (1): Foggia 
- **Frosinone** (1): Frosinone  (1) Frosinone Calcio
- **Gallipoli** (1): Gallipoli Football SSD  (2) Gallipoli · Gallipoli Football 1909 SSD
- **Grosseto** (1): ASD US Grosseto  (2) Grosseto · ASD US Grosseto 1912
- **Gubbio** (1): AS Gubbio  (2) Gubbio · AS Gubbio 1910
- **La Spezia** (1): Spezia 
- **Lanciano** (1): Virtus Lanciano  (1) ASD 1920 Lanciano Calcio
- **Latina** (1): SSD Latina Calcio  (2) Latina · SSD Latina Calcio 1932
- **Lecce** (1): US Lecce  (1) Lecce
- **Livorno** (1): AS Livorno Calcio  (4) Livorno · AS Livorno · A.S. Livorno Calcio · Associazione Sportiva Livorno Calcio
- **Lucca** (1): AS Lucchese Libertas  (2) Lucchese · AS Lucchese Libertas 1905
- **Mantova** (1): Mantova SSD  (2) Mantova · Mantova 1911 SSD
- **Messina** (1): ACR Messina SSD  (1) Messina
- **Modena** (1): Modena FC  (1) Modena
- **Monza** (1): SS Monza  (2) Monza · SS Monza 1912
- **Napoli** (1): SSC Napoli  (2) Napoli · Società Sportiva Calcio Napoli
- **Nocera Inferiore** (1): ASD Nocerina  (2) Nocerina · ASD Nocerina 1910
- **Novara** (1): Novara 
- **Padova** (1): Calcio Padova  (1) Padova
- **Palermo** (1): Palermo  (2) US Palermo · Unione Sportiva Città di Palermo
- **Parma** (1): Parma  (3) Parma FC · Parma Football Club · Parma Calcio 1913
- **Perugia** (1): Perugia 
- **Pescara** (1): Pescara  (1) Pescara Calcio
- **Piacenza** (1): Piacenza Calcio  (2) Piacenza · Piacenza Calcio 1919
- **Pisa** (1): AC Pisa  (2) Pisa · AC Pisa 1909
- **Pistoia** (1): US Pistoiese  (2) Pistoiese · US Pistoiese 1921
- **Portogruaro** (1): Portogruaro Calcio ASD  (1) Portogruaro
- **Ravenna** (1): Ravenna FC  (2) Ravenna · Ravenna FC 1913
- **Reggio Calabria** (1): Urbs Reggina  (2) Reggina · Urbs Reggina 1914
- **Reggio Emilia** (1): AC Reggiana  (2) Reggiana · AC Reggiana 1919
- **Rimini** (1): Rimini FC SSD  (2) Rimini · Rimini FC 1912 SSD
- **Salerno** (1): Salernitana 
- **Sassuolo** (1): US Sassuolo Calcio  (3) Sassuolo · U.S. Sassuolo Calcio · Unione Sportiva Sassuolo Calcio
- **Siena** (1): SS Robur Siena  (3) Siena · AC Siena · Associazione Calcio Siena
- **Terni** (1): Ternana 
- **Torre Annunziata** (1): ASD Savoia  (2) Savoia · ASD Savoia 1908
- **Trapani** (1): Trapani Calcio  (1) Trapani
- **Treviso** (1): ACD Treviso  (1) Treviso
- **Trieste** (1): US Triestina Calcio  (2) Triestina · US Triestina Calcio 1918
- **Udine** (1): Udinese Calcio  (1) Udinese
- **Varese** (1): Varese Calcio  (1) Varese
- **Venezia** (1): Venezia 
- **Vercelli** (1): Pro Vercelli 
- **Vicenza** (1): LR Vicenza Virtus  (1) Vicenza




By Region

- **Roma†** (2):   AS Roma · SS Lazio
- **Milano†** (2):   AC Milan · FC Internazionale Milano
- **Torino†** (2):   Torino FC · Juventus
- **Verona†** (2):   Hellas Verona FC · AC Chievo Verona
- **Genova†** (2):   Genoa CFC · UC Sampdoria
- **Bergamo†** (1):   Atalanta BC
- **Benevento†** (1):   Benevento
- **Bologna†** (1):   Bologna FC
- **Cagliari†** (1):   Cagliari Calcio
- **Crotone†** (1):   FC Crotone
- **Firenze†** (1):   ACF Fiorentina
- **Napoli†** (1):   SSC Napoli
- **Sassuolo†** (1):   US Sassuolo Calcio
- **Ferrara†** (1):   SPAL
- **Udine†** (1):   Udinese Calcio
- **Ascoli Piceno†** (1):   Ascoli
- **Avellino†** (1):   Avellino
- **Bari†** (1):   Bari
- **Brescia†** (1):   Brescia
- **Carpi†** (1):   Carpi
- **Cesena†** (1):   Cesena
- **Cittadella†** (1):   Cittadella
- **Cremona†** (1):   Cremonese
- **Empoli†** (1):   Empoli
- **Foggia†** (1):   Foggia
- **Frosinone†** (1):   Frosinone
- **Novara†** (1):   Novara
- **Palermo†** (1):   Palermo
- **Parma†** (1):   Parma
- **Perugia†** (1):   Perugia
- **Pescara†** (1):   Pescara
- **Vercelli†** (1):   Pro Vercelli
- **Salerno†** (1):   Salernitana
- **La Spezia†** (1):   Spezia
- **Terni†** (1):   Ternana
- **Venezia†** (1):   Venezia
- **Chiavari†** (1):   Virtus Entella
- **Piacenza†** (1):   Piacenza Calcio
- **Vicenza†** (1):   LR Vicenza Virtus
- **Padova†** (1):   Calcio Padova
- **Modena†** (1):   Modena FC
- **Siena†** (1):   SS Robur Siena
- **Ancona†** (1):   US Anconitana ASD
- **Cosenza†** (1):   Cosenza Calcio
- **Andria†** (1):   SS Fidelis Andria
- **Lecce†** (1):   US Lecce
- **Lucca†** (1):   AS Lucchese Libertas
- **Monza†** (1):   SS Monza
- **Ravenna†** (1):   Ravenna FC
- **Reggio Emilia†** (1):   AC Reggiana
- **Reggio Calabria†** (1):   Urbs Reggina
- **Treviso†** (1):   ACD Treviso
- **Castel di Sangro†** (1):   ASD Castel di Sangro
- **Albino e Leffe†** (1):   Unione Calcio Albinoleffe
- **Catania†** (1):   Calcio Catania
- **Como†** (1):   Como 1907
- **Livorno†** (1):   AS Livorno Calcio
- **Messina†** (1):   ACR Messina SSD
- **Trieste†** (1):   US Triestina Calcio
- **Arezzo†** (1):   SS Arezzo
- **Catanzaro†** (1):   US Catanzaro
- **Alzano Lombardo†** (1):   ASD Virtus Bergamo
- **Fermo†** (1):   MC Fermana FC
- **Gallipoli†** (1):   Gallipoli Football SSD
- **Grosseto†** (1):   ASD US Grosseto
- **Gubbio†** (1):   AS Gubbio
- **Castellammare di Stabia†** (1):   SS Juve Stabia
- **Latina†** (1):   SSD Latina Calcio
- **Mantova†** (1):   Mantova SSD
- **Nocera Inferiore†** (1):   ASD Nocerina
- **Pisa†** (1):   AC Pisa
- **Pistoia†** (1):   US Pistoiese
- **Portogruaro†** (1):   Portogruaro Calcio ASD
- **Rimini†** (1):   Rimini FC SSD
- **Torre Annunziata†** (1):   ASD Savoia
- **Trapani†** (1):   Trapani Calcio
- **Varese†** (1):   Varese Calcio
- **Lanciano†** (1):   Virtus Lanciano




By Year

- **1903** (1):   Hellas Verona FC
- **1915** (1):   AS Livorno Calcio
- **1922** (1):   US Sassuolo Calcio
- **1929** (1):   Benevento
- ? (79):   AS Roma · SS Lazio · AC Milan · FC Internazionale Milano · Torino FC · Juventus · AC Chievo Verona · Genoa CFC · UC Sampdoria · Atalanta BC · Bologna FC · Cagliari Calcio · FC Crotone · ACF Fiorentina · SSC Napoli · SPAL · Udinese Calcio · Ascoli · Avellino · Bari · Brescia · Carpi · Cesena · Cittadella · Cremonese · Empoli · Foggia · Frosinone · Novara · Palermo · Parma · Perugia · Pescara · Pro Vercelli · Salernitana · Spezia · Ternana · Venezia · Virtus Entella · Piacenza Calcio · LR Vicenza Virtus · Calcio Padova · Modena FC · SS Robur Siena · US Anconitana ASD · Cosenza Calcio · SS Fidelis Andria · US Lecce · AS Lucchese Libertas · SS Monza · Ravenna FC · AC Reggiana · Urbs Reggina · ACD Treviso · ASD Castel di Sangro · Unione Calcio Albinoleffe · Calcio Catania · Como 1907 · ACR Messina SSD · US Triestina Calcio · SS Arezzo · US Catanzaro · ASD Virtus Bergamo · MC Fermana FC · Gallipoli Football SSD · ASD US Grosseto · AS Gubbio · SS Juve Stabia · SSD Latina Calcio · Mantova SSD · ASD Nocerina · AC Pisa · US Pistoiese · Portogruaro Calcio ASD · Rimini FC SSD · ASD Savoia · Trapani Calcio · Varese Calcio · Virtus Lanciano






By A to Z

- **A** (48): Alzano · Ancona · Arezzo · Ascoli · AC Pisa · AS Roma · AC Milan · AC Siena · Atalanta · Avellino · AC Cesena · AS Gubbio · AC Firenze · AS Livorno · ASD Savoia · AC Reggiana · ACD Treviso · Albinoleffe · Atalanta BC · AC Pisa 1909 · ASD Nocerina · ACF Fiorentina · AS Gubbio 1910 · ACR Messina SSD · ASD Savoia 1908 · ASD US Grosseto · Alzano Virescit · AC Chievo Verona · AC Reggiana 1919 · Atalanta Bergamo · AS Livorno Calcio · ASD Nocerina 1910 · ASD Virtus Bergamo · A.S. Livorno Calcio · AS Lucchese Libertas · ASD Castel di Sangro · ASD US Grosseto 1912 · ASD Virtus Bergamo 1909 · ASD 1920 Lanciano Calcio · AS Lucchese Libertas 1905 · Associazione Calcio Milan · Associazione Calcio Siena · Associazione Calcio Cesena · Associazione Sportiva Roma · Atalanta Bergamasca Calcio · Associazione Calcio Chievo Verona · Associazione Sportiva Livorno Calcio · Associazione Calcio Firenze Fiorentina
- **B** (8): Bari · Bologna · Brescia · Benevento · Bologna FC · Benevento Calcio · Bologna F.C. 1909 · Bologna Football Club 1909
- **C** (21): Como · Carpi · Cesena · Chievo · Catania · Cosenza · Crotone · Cagliari · C. Sangro · Catanzaro · Como 1907 · Cremonese · Cittadella · Crotone FC · Calcio Padova · Carpi FC 1909 · Chievo Verona · Calcio Catania · Cosenza Calcio · Cagliari Calcio · Carpi Football Club 1909
- **E** (3): Empoli · Empoli FC · Empoli Football Club
- **F** (10): Foggia · Fermana · F. Andria · Frosinone · FC Bologna · FC Crotone · Fiorentina · Frosinone Calcio · FC Internazionale Milano · Federazione Calcistica Crotone
- **G** (8): Genoa · Gubbio · Grosseto · Gallipoli · Genoa CFC · Gallipoli Football SSD · Gallipoli Football 1909 SSD · Genoa Cricket and Football Club
- **H** (4): Hellas Verona · Hellas Verona FC · Hellas Verona F.C. · Hellas Verona Football Club
- **I** (3): Inter · Inter Milan · Internazionale
- **J** (5): Juventus · Juve Stabia · Juventus FC · Juventus Torino · Juventus Football Club
- **L** (7): Lazio · Lecce · Latina · Livorno · Lucchese · Lazio Roma · LR Vicenza Virtus
- **M** (9): Milan · Monza · Modena · Mantova · Messina · Modena FC · Mantova SSD · MC Fermana FC · Mantova 1911 SSD
- **N** (3): Napoli · Novara · Nocerina
- **P** (17): Pisa · Parma · Padova · Palermo · Perugia · Pescara · Parma FC · Piacenza · Pistoiese · Portogruaro · Pro Vercelli · Pescara Calcio · Piacenza Calcio · Parma Calcio 1913 · Parma Football Club · Piacenza Calcio 1919 · Portogruaro Calcio ASD
- **R** (9): Roma · Rimini · Ravenna · Reggina · Reggiana · Ravenna FC · Rimini FC SSD · Ravenna FC 1913 · Rimini FC 1912 SSD
- **S** (24): SPAL · Spal · Siena · Savoia · Spezia · SS Lazio · SS Monza · Sassuolo · SS Arezzo · Sampdoria · SSC Napoli · Salernitana · S.P.A.L. 2013 · SS Monza 1912 · SS Juve Stabia · SS Robur Siena · Sampdoria Genoa · SPAL 2013 Ferrara · SS Fidelis Andria · SSD Latina Calcio · SS Fidelis Andria 1928 · SSD Latina Calcio 1932 · Società Sportiva Lazio · Società Sportiva Calcio Napoli
- **T** (8): Torino · Ternana · Trapani · Treviso · Torino FC · Triestina · Trapani Calcio · Torino Football Club
- **U** (20): Udinese · US Lecce · US Palermo · UC Sampdoria · US Catanzaro · US Pistoiese · Urbs Reggina · Udinese Calcio · US Anconitana ASD · US Catanzaro 1929 · US Pistoiese 1921 · Urbs Reggina 1914 · US Sassuolo Calcio · US Triestina Calcio · U.S. Sassuolo Calcio · Unione Calcio Sampdoria · US Triestina Calcio 1918 · Unione Calcio Albinoleffe · Unione Sportiva Sassuolo Calcio · Unione Sportiva Città di Palermo
- **V** (8): Varese · Verona · Venezia · Vicenza · Varese Calcio · Virtus Bergamo · Virtus Entella · Virtus Lanciano




