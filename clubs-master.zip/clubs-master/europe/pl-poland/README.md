27 clubs

- **Legia Warszawa** : (2) Legia · Legia Warsaw [en]
- **KSP Polonia Warszawa** : (1) Polonia Warszawa
- [**Górnik Zabrze**](https://en.wikipedia.org/wiki/Górnik_Zabrze) : (1) Górnik Z. ⇒ (2) ≈Gornik Z.≈ · ≈Gornik Zabrze≈
- **KKS Lech Poznań** : (2) Lech · Lech Poznań ⇒ (2) ≈Lech Poznan≈ · ≈KKS Lech Poznan≈
- **Wisła Kraków** : (1) Wisła ⇒ (2) ≈Wisla≈ · ≈Wisla Krakow≈
- [**KS Cracovia**](https://en.wikipedia.org/wiki/KS_Cracovia_(football)) : (2) Cracovia · MKS Cracovia Kraków ⇒ (1) ≈MKS Cracovia Krakow≈
- **WKS Śląsk Wrocław** : (2) Śląsk · Śląsk Wrocław ⇒ (3) ≈Slask≈ · ≈Slask Wroclaw≈ · ≈WKS Slask Wroclaw≈
- **Jagiellonia Białystok** : (1) Jagiellonia ⇒ (1) ≈Jagiellonia Bialystok≈
- [**Arka Gdynia**](https://en.wikipedia.org/wiki/Arka_Gdynia) : (1) Arka
- **GKS Bełchatów** ⇒ (1) ≈GKS Belchatow≈
- **Korona Kielce**
- **Lechia Gdańsk** ⇒ (1) ≈Lechia Gdansk≈
- **Górnik Łęczna** : (1) Łęczna ⇒ (2) ≈Leczna≈ · ≈Gornik Leczna≈
- **Miedź Legnica** : (1) Legnica ⇒ (1) ≈Miedz Legnica≈
- **Piast Gliwice** : (2) Piast · GKS Piast Gliwice
- **Wisła Płock** : (1) Płock ⇒ (2) ≈Plock≈ · ≈Wisla Plock≈
- **Podbeskidzie Bielsko-Biała** : (1) Podbeskidzie ⇒ (1) ≈Podbeskidzie Bielsko-Biala≈
- **Pogoń Szczecin** ⇒ (1) ≈Pogon Szczecin≈
- **Ruch Chorzów** : (1) Ruch ⇒ (1) ≈Ruch Chorzow≈
- **Sandecja Nowy Sącz** : (1) Sandecja Nowy S. ⇒ (1) ≈Sandecja Nowy Sacz≈
- [**Bruk-Bet Termalica Nieciecza**](https://en.wikipedia.org/wiki/Bruk-Bet_Termalica_Nieciecza) : (1) Termalica B-B.
- **Widzew Łódź** ⇒ (1) ≈Widzew Lodz≈
- **ŁKS Łódź** ⇒ (1) ≈LKS Lodz≈
- **Zagłębie Lubin** : (1) Zagłębie ⇒ (2) ≈Zaglebie≈ · ≈Zaglebie Lubin≈
- **Zagłębie Sosnowiec** ⇒ (1) ≈Zaglebie Sosnowiec≈
- **Zawisza Bydgoszcz** : (1) Zawisza
- **Raków Częstochowa** : (2) Raków · RKS Raków Częstochowa ⇒ (3) ≈Rakow≈ · ≈Rakow Czestochowa≈ · ≈RKS Rakow Czestochowa≈




Alphabet

- **Alphabet Specials** (8):  **ó**  **ą**  **ę**  **Ł**  **ł**  **ń**  **Ś**  **ź** 
  - **ó**×12 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ą**×4 U+0105 (261) - LATIN SMALL LETTER A WITH OGONEK ⇒ a
  - **ę**×7 U+0119 (281) - LATIN SMALL LETTER E WITH OGONEK ⇒ e
  - **Ł**×5 U+0141 (321) - LATIN CAPITAL LETTER L WITH STROKE ⇒ L
  - **ł**×13 U+0142 (322) - LATIN SMALL LETTER L WITH STROKE ⇒ l
  - **ń**×4 U+0144 (324) - LATIN SMALL LETTER N WITH ACUTE ⇒ n
  - **Ś**×3 U+015A (346) - LATIN CAPITAL LETTER S WITH ACUTE ⇒ S
  - **ź**×3 U+017A (378) - LATIN SMALL LETTER Z WITH ACUTE ⇒ z




Duplicates





By City

- **Kraków** (2): 
  - Wisła Kraków  (1) Wisła
  - KS Cracovia  (2) Cracovia · MKS Cracovia Kraków
- **Nieciecza** (2): 
  - Sandecja Nowy Sącz  (1) Sandecja Nowy S.
  - Bruk-Bet Termalica Nieciecza  (1) Termalica B-B.
- **Warszawa** (2): 
  - Legia Warszawa  (2) Legia · Legia Warsaw [en]
  - KSP Polonia Warszawa  (1) Polonia Warszawa
- **Łódź** (2): 
  - Widzew Łódź 
  - ŁKS Łódź 
- **Bełchatów** (1): GKS Bełchatów 
- **Białystok** (1): Jagiellonia Białystok  (1) Jagiellonia
- **Bielsko-Biała** (1): Podbeskidzie Bielsko-Biała  (1) Podbeskidzie
- **Bydgoszcz** (1): Zawisza Bydgoszcz  (1) Zawisza
- **Chorzów** (1): Ruch Chorzów  (1) Ruch
- **Częstochowa** (1): Raków Częstochowa  (2) Raków · RKS Raków Częstochowa
- **Gdańsk** (1): Lechia Gdańsk 
- **Gdynia** (1): Arka Gdynia  (1) Arka
- **Gliwice** (1): Piast Gliwice  (2) Piast · GKS Piast Gliwice
- **Kielce** (1): Korona Kielce 
- **Legnica** (1): Miedź Legnica  (1) Legnica
- **Lubin** (1): Zagłębie Lubin  (1) Zagłębie
- **Lublin** (1): Górnik Łęczna  (1) Łęczna
- **Poznań** (1): KKS Lech Poznań  (2) Lech · Lech Poznań
- **Płock** (1): Wisła Płock  (1) Płock
- **Sosnowiec** (1): Zagłębie Sosnowiec 
- **Szczecin** (1): Pogoń Szczecin 
- **Wrocław** (1): WKS Śląsk Wrocław  (2) Śląsk · Śląsk Wrocław
- **Zabrze** (1): Górnik Zabrze  (1) Górnik Z.




By Region

- **Warszawa†** (2):   Legia Warszawa · KSP Polonia Warszawa
- **Zabrze†** (1):   Górnik Zabrze
- **Poznań†** (1):   KKS Lech Poznań
- **Kraków†** (2):   Wisła Kraków · KS Cracovia
- **Wrocław†** (1):   WKS Śląsk Wrocław
- **Białystok†** (1):   Jagiellonia Białystok
- **Gdynia†** (1):   Arka Gdynia
- **Bełchatów†** (1):   GKS Bełchatów
- **Kielce†** (1):   Korona Kielce
- **Gdańsk†** (1):   Lechia Gdańsk
- **Lublin†** (1):   Górnik Łęczna
- **Legnica†** (1):   Miedź Legnica
- **Gliwice†** (1):   Piast Gliwice
- **Płock†** (1):   Wisła Płock
- **Bielsko-Biała†** (1):   Podbeskidzie Bielsko-Biała
- **Szczecin†** (1):   Pogoń Szczecin
- **Chorzów†** (1):   Ruch Chorzów
- **Nieciecza†** (2):   Sandecja Nowy Sącz · Bruk-Bet Termalica Nieciecza
- **Łódź†** (2):   Widzew Łódź · ŁKS Łódź
- **Lubin†** (1):   Zagłębie Lubin
- **Sosnowiec†** (1):   Zagłębie Sosnowiec
- **Bydgoszcz†** (1):   Zawisza Bydgoszcz
- **Częstochowa†** (1):   Raków Częstochowa




By Year

- **1921** (1):   Raków Częstochowa
- **1922** (1):   Bruk-Bet Termalica Nieciecza
- ? (25):   Legia Warszawa · KSP Polonia Warszawa · Górnik Zabrze · KKS Lech Poznań · Wisła Kraków · KS Cracovia · WKS Śląsk Wrocław · Jagiellonia Białystok · Arka Gdynia · GKS Bełchatów · Korona Kielce · Lechia Gdańsk · Górnik Łęczna · Miedź Legnica · Piast Gliwice · Wisła Płock · Podbeskidzie Bielsko-Biała · Pogoń Szczecin · Ruch Chorzów · Sandecja Nowy Sącz · Widzew Łódź · ŁKS Łódź · Zagłębie Lubin · Zagłębie Sosnowiec · Zawisza Bydgoszcz






By A to Z

- **A** (2): Arka · Arka Gdynia
- **B** (1): Bruk-Bet Termalica Nieciecza
- **C** (1): Cracovia
- **G** (5): Górnik Z. · GKS Bełchatów · Górnik Zabrze · Górnik Łęczna · GKS Piast Gliwice
- **J** (2): Jagiellonia · Jagiellonia Białystok
- **K** (4): KS Cracovia · Korona Kielce · KKS Lech Poznań · KSP Polonia Warszawa
- **L** (7): Lech · Legia · Legnica · Lech Poznań · Lechia Gdańsk · Legia Warszawa · Legia Warsaw [en]
- **M** (2): Miedź Legnica · MKS Cracovia Kraków
- **P** (7): Piast · Płock · Podbeskidzie · Piast Gliwice · Pogoń Szczecin · Polonia Warszawa · Podbeskidzie Bielsko-Biała
- **R** (5): Ruch · Raków · Ruch Chorzów · Raków Częstochowa · RKS Raków Częstochowa
- **S** (2): Sandecja Nowy S. · Sandecja Nowy Sącz
- **T** (1): Termalica B-B.
- **W** (5): Wisła · Widzew Łódź · Wisła Płock · Wisła Kraków · WKS Śląsk Wrocław
- **Z** (5): Zawisza · Zagłębie · Zagłębie Lubin · Zawisza Bydgoszcz · Zagłębie Sosnowiec
- **Ł** (2): Łęczna · ŁKS Łódź
- **Ś** (2): Śląsk · Śląsk Wrocław




