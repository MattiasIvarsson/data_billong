45 clubs

- [**Celtic FC**](https://en.wikipedia.org/wiki/Celtic_F.C.) : (1) Celtic
- [**Rangers FC**](https://en.wikipedia.org/wiki/Rangers_F.C.) : (1) Rangers
- [**Partick Thistle**](https://en.wikipedia.org/wiki/Partick_Thistle_F.C.) : (3) Jags · Partick · Partick Thistle FC
- **Queen's Park** : (1) Queens Park
- [**Heart of Midlothian FC**](https://en.wikipedia.org/wiki/Heart_of_Midlothian_F.C.) : (1) Hearts
- [**Hibernian FC**](https://en.wikipedia.org/wiki/Hibernian_F.C.) : (2) Hibernian · Hibernians
- **Edinburgh City**
- [**Aberdeen FC**](https://en.wikipedia.org/wiki/Aberdeen_F.C.) : (1) Aberdeen
- **Cove Rangers FC** : (2) Cove Rangers · Cove Rangers Football Club
- [**Dundee FC**](https://en.wikipedia.org/wiki/Dundee_F.C.) : (1) Dundee
- [**Dundee United**](https://en.wikipedia.org/wiki/Dundee_United_F.C.) : (3) Dundee Utd · Dundee United FC · Dundee Hibernian
- [**Hamilton Academical FC**](https://en.wikipedia.org/wiki/Hamilton_Academical_F.C.) : (2) Hamilton · Hamilton Accies
- [**Kilmarnock FC**](https://en.wikipedia.org/wiki/Kilmarnock_F.C.) : (2) Killie · Kilmarnock
- [**Motherwell FC**](https://en.wikipedia.org/wiki/Motherwell_F.C.) : (1) Motherwell
- [**Ross County FC**](https://en.wikipedia.org/wiki/Ross_County_F.C.) : (1) Ross County
- [**St Johnstone FC**](https://en.wikipedia.org/wiki/St_Johnstone_F.C.) : (3) St Johnstone · St. Johnstone · Saint Johnstone FC
- **Brechin City** : (1) Brechin
- **Dumbarton**
- **Dunfermline Athletic** : (1) Dunfermline
- **Falkirk**
- **Greenock Morton** : (1) Morton
- [**Inverness Caledonian Thistle**](https://en.wikipedia.org/wiki/Inverness_Caledonian_Thistle_F.C.) : (7) ICT · Inverness · Inverness C · Inverness CT · Caley Thistle · The Caley Jags · Inverness Caledonian Thistle FC
- [**Livingston FC**](https://en.wikipedia.org/wiki/Livingston_F.C.) : (1) Livingston
- **Queen of the South** : (1) Queen of Sth
- [**Saint Mirren FC**](https://en.wikipedia.org/wiki/St_Mirren_F.C.) : (2) St Mirren · St Mirren FC
- **Airdrieonians** : (2) Airdrie · Airdrie Utd
- **Albion Rovers** : (1) Albion Rvs
- **Alloa Athletic** : (1) Alloa
- **Arbroath**
- **Ayr United** : (1) Ayr
- **East Fife**
- **Forfar Athletic** : (1) Forfar
- **Raith Rovers** : (2) Raith · Raith Rvs
- **Stranraer**
- **Annan Athletic**
- **Clyde**
- **Cowdenbeath**
- **Elgin City** : (1) Elgin
- **Montrose**
- **Peterhead**
- **Stenhousemuir**
- **Stirling Albion** : (1) Stirling
- [**Clydebank FC**](https://en.wikipedia.org/wiki/Clydebank_F.C.) : (1) Clydebank
- [**East Stirlingshire FC**](https://en.wikipedia.org/wiki/East_Stirlingshire_F.C.) : (1) East Stirling
- [**Gretna FC**](https://en.wikipedia.org/wiki/Gretna_F.C.) : (1) Gretna




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **Queen's Park**, Glasgow (1):
  - `queenspark` (2): Queen's Park · Queens Park
- **St Johnstone FC**, Perth (1):
  - `stjohnstone` (2): St Johnstone · St. Johnstone




By City

- **Glasgow** (4): 
  - Celtic FC  (1) Celtic
  - Rangers FC  (1) Rangers
  - Partick Thistle  (3) Partick · Partick Thistle FC · Jags
  - Queen's Park  (1) Queens Park
- **Edinburgh** (3): 
  - Heart of Midlothian FC  (1) Hearts
  - Hibernian FC  (2) Hibernian · Hibernians
  - Edinburgh City 
- **Aberdeen** (2): 
  - Aberdeen FC  (1) Aberdeen
  - Cove Rangers FC  (2) Cove Rangers · Cove Rangers Football Club
- **Dundee** (2): 
  - Dundee FC  (1) Dundee
  - Dundee United  (3) Dundee Utd · Dundee United FC · Dundee Hibernian
- **Falkirk** (2): 
  - Falkirk 
  - East Stirlingshire FC  (1) East Stirling
- **Airdrie** (1): Airdrieonians  (2) Airdrie Utd · Airdrie
- **Alloa** (1): Alloa Athletic  (1) Alloa
- **Annan** (1): Annan Athletic 
- **Arbroath** (1): Arbroath 
- **Ayr** (1): Ayr United  (1) Ayr
- **Brechin** (1): Brechin City  (1) Brechin
- **Clydebank** (1): Clydebank FC  (1) Clydebank
- **Coatbridge** (1): Albion Rovers  (1) Albion Rvs
- **Cowdenbeath** (1): Cowdenbeath 
- **Cumbernauld** (1): Clyde 
- **Dingwall** (1): Ross County FC  (1) Ross County
- **Dumbarton** (1): Dumbarton 
- **Dumfries** (1): Queen of the South  (1) Queen of Sth
- **Dunfermline** (1): Dunfermline Athletic  (1) Dunfermline
- **Elgin** (1): Elgin City  (1) Elgin
- **Forfar** (1): Forfar Athletic  (1) Forfar
- **Greenock** (1): Greenock Morton  (1) Morton
- **Gretna** (1): Gretna FC  (1) Gretna
- **Hamilton** (1): Hamilton Academical FC  (2) Hamilton · Hamilton Accies
- **Inverness** (1): Inverness Caledonian Thistle  (7) Inverness · Inverness C · Inverness CT · Inverness Caledonian Thistle FC · Caley Thistle · ICT · The Caley Jags
- **Kilmarnock** (1): Kilmarnock FC  (2) Kilmarnock · Killie
- **Kirkcaldy** (1): Raith Rovers  (2) Raith Rvs · Raith
- **Livingston** (1): Livingston FC  (1) Livingston
- **Methil** (1): East Fife 
- **Montrose** (1): Montrose 
- **Motherwell** (1): Motherwell FC  (1) Motherwell
- **Paisley** (1): Saint Mirren FC  (2) St Mirren · St Mirren FC
- **Perth** (1): St Johnstone FC  (3) St Johnstone · St. Johnstone · Saint Johnstone FC
- **Peterhead** (1): Peterhead 
- **Stenhousemuir** (1): Stenhousemuir 
- **Stirling** (1): Stirling Albion  (1) Stirling
- **Stranraer** (1): Stranraer 




By Region

- **Glasgow†** (4):   Celtic FC · Rangers FC · Partick Thistle · Queen's Park
- **Edinburgh†** (3):   Heart of Midlothian FC · Hibernian FC · Edinburgh City
- **Aberdeen†** (2):   Aberdeen FC · Cove Rangers FC
- **Dundee†** (2):   Dundee FC · Dundee United
- **Hamilton†** (1):   Hamilton Academical FC
- **Kilmarnock†** (1):   Kilmarnock FC
- **Motherwell†** (1):   Motherwell FC
- **Dingwall†** (1):   Ross County FC
- **Perth†** (1):   St Johnstone FC
- **Brechin†** (1):   Brechin City
- **Dumbarton†** (1):   Dumbarton
- **Dunfermline†** (1):   Dunfermline Athletic
- **Falkirk†** (2):   Falkirk · East Stirlingshire FC
- **Greenock†** (1):   Greenock Morton
- **Inverness†** (1):   Inverness Caledonian Thistle
- **Livingston†** (1):   Livingston FC
- **Dumfries†** (1):   Queen of the South
- **Paisley†** (1):   Saint Mirren FC
- **Airdrie†** (1):   Airdrieonians
- **Coatbridge†** (1):   Albion Rovers
- **Alloa†** (1):   Alloa Athletic
- **Arbroath†** (1):   Arbroath
- **Ayr†** (1):   Ayr United
- **Methil†** (1):   East Fife
- **Forfar†** (1):   Forfar Athletic
- **Kirkcaldy†** (1):   Raith Rovers
- **Stranraer†** (1):   Stranraer
- **Annan†** (1):   Annan Athletic
- **Cumbernauld†** (1):   Clyde
- **Cowdenbeath†** (1):   Cowdenbeath
- **Elgin†** (1):   Elgin City
- **Montrose†** (1):   Montrose
- **Peterhead†** (1):   Peterhead
- **Stenhousemuir†** (1):   Stenhousemuir
- **Stirling†** (1):   Stirling Albion
- **Clydebank†** (1):   Clydebank FC
- **Gretna†** (1):   Gretna FC




By Year

- **1869** (1):   Kilmarnock FC
- **1874** (1):   Hamilton Academical FC
- **1876** (1):   Partick Thistle
- **1877** (1):   Saint Mirren FC
- **1884** (1):   St Johnstone FC
- **1886** (1):   Motherwell FC
- **1887** (1):   Celtic FC
- **1893** (1):   Dundee FC
- **1903** (1):   Aberdeen FC
- **1909** (1):   Dundee United
- **1922** (1):   Cove Rangers FC
- **1929** (1):   Ross County FC
- **1994** (1):   Inverness Caledonian Thistle
- ? (32):   Rangers FC · Queen's Park · Heart of Midlothian FC · Hibernian FC · Edinburgh City · Brechin City · Dumbarton · Dunfermline Athletic · Falkirk · Greenock Morton · Livingston FC · Queen of the South · Airdrieonians · Albion Rovers · Alloa Athletic · Arbroath · Ayr United · East Fife · Forfar Athletic · Raith Rovers · Stranraer · Annan Athletic · Clyde · Cowdenbeath · Elgin City · Montrose · Peterhead · Stenhousemuir · Stirling Albion · Clydebank FC · East Stirlingshire FC · Gretna FC






By A to Z

- **A** (13): Ayr · Alloa · Airdrie · Aberdeen · Arbroath · Albion Rvs · Ayr United · Aberdeen FC · Airdrie Utd · Airdrieonians · Albion Rovers · Alloa Athletic · Annan Athletic
- **B** (2): Brechin · Brechin City
- **C** (10): Clyde · Celtic · Celtic FC · Clydebank · Cowdenbeath · Clydebank FC · Cove Rangers · Caley Thistle · Cove Rangers FC · Cove Rangers Football Club
- **D** (9): Dundee · Dumbarton · Dundee FC · Dundee Utd · Dunfermline · Dundee United · Dundee Hibernian · Dundee United FC · Dunfermline Athletic
- **E** (6): Elgin · East Fife · Elgin City · East Stirling · Edinburgh City · East Stirlingshire FC
- **F** (3): Forfar · Falkirk · Forfar Athletic
- **G** (3): Gretna · Gretna FC · Greenock Morton
- **H** (8): Hearts · Hamilton · Hibernian · Hibernians · Hibernian FC · Hamilton Accies · Hamilton Academical FC · Heart of Midlothian FC
- **I** (6): ICT · Inverness · Inverness C · Inverness CT · Inverness Caledonian Thistle · Inverness Caledonian Thistle FC
- **J** (1): Jags
- **K** (3): Killie · Kilmarnock · Kilmarnock FC
- **L** (2): Livingston · Livingston FC
- **M** (4): Morton · Montrose · Motherwell · Motherwell FC
- **P** (4): Partick · Peterhead · Partick Thistle · Partick Thistle FC
- **Q** (4): Queens Park · Queen of Sth · Queen's Park · Queen of the South
- **R** (7): Raith · Rangers · Raith Rvs · Rangers FC · Ross County · Raith Rovers · Ross County FC
- **S** (11): Stirling · St Mirren · Stranraer · St Johnstone · St Mirren FC · St. Johnstone · Stenhousemuir · Saint Mirren FC · St Johnstone FC · Stirling Albion · Saint Johnstone FC
- **T** (1): The Caley Jags




