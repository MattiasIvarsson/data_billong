3 clubs

- **KF Drita**
- **FC Prishtina**
- **KF Trepça'89** ⇒ (1) ≈KF Trepca'89≈




Alphabet

- **Alphabet Specials** (1):  **ç** 
  - **ç**×1 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c




Duplicates





By City

- ? (3): 
  - KF Drita 
  - FC Prishtina 
  - KF Trepça'89 




By Region





By Year

- ? (3):   KF Drita · FC Prishtina · KF Trepça'89






By A to Z

- **F** (1): FC Prishtina
- **K** (2): KF Drita · KF Trepça'89




