14 clubs

- **FC Dynamo Kyiv** : (5) Dinamo Kiev · Dynamo Kiew · Dynamo Kiev · Dynamo Kyiv · FC Dynamo Kiew
- **FC Arsenal Kyiv** : (1) Arsenal Kyiv
- **FC Shakhtar Donetsk** : (4) Shakhtar Don. · Shakhtar Donetsk · Schachtar Donezk · Schachtjor Donezk
- **FC Metalurh Donetsk** : (1) Metalurh Donetsk
- **FC Olimpik Donetsk** : (1) Olimpik Donetsk
- **FC Metalist Kharkiv** : (2) Metalist · Metalist Kharkiv
- **FC Dnipro** : (3) Dnipro · Dnipro Dnipropetrovsk · FC Dnipro Dnipropetrovsk
- **FC Vorskla Poltava** : (1) Vorskla
- **FC Karpaty Lviv** : (1) Karpaty
- **SC Tavriya Simferopol** : (1) Tavriya
- **FC Zorya Luhansk** : (1) Zorya Luhansk
- **FC Mariupol** : (1) Mariupol
- **FC Olexandriya** : (1) Olexandriya
- **FC Chornomorets Odesa** : (1) Chornomorets Odesa




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Donetsk** (2): 
  - FC Shakhtar Donetsk  (4) Shakhtar Donetsk · Schachtjor Donezk · Shakhtar Don. · Schachtar Donezk
  - FC Metalurh Donetsk  (1) Metalurh Donetsk
- **Kyiv** (2): 
  - FC Dynamo Kyiv  (5) Dinamo Kiev · Dynamo Kiew · FC Dynamo Kiew · Dynamo Kiev · Dynamo Kyiv
  - FC Arsenal Kyiv  (1) Arsenal Kyiv
- **city:dnipropetrovsk** (1): FC Dnipro  (3) Dnipro · FC Dnipro Dnipropetrovsk · Dnipro Dnipropetrovsk
- **city:kharkov** (1): FC Metalist Kharkiv  (2) Metalist · Metalist Kharkiv
- ? (8): 
  - FC Olimpik Donetsk  (1) Olimpik Donetsk
  - FC Vorskla Poltava  (1) Vorskla
  - FC Karpaty Lviv  (1) Karpaty
  - SC Tavriya Simferopol  (1) Tavriya
  - FC Zorya Luhansk  (1) Zorya Luhansk
  - FC Mariupol  (1) Mariupol
  - FC Olexandriya  (1) Olexandriya
  - FC Chornomorets Odesa  (1) Chornomorets Odesa




By Region

- **Kyiv†** (2):   FC Dynamo Kyiv · FC Arsenal Kyiv
- **Donetsk†** (2):   FC Shakhtar Donetsk · FC Metalurh Donetsk
- **city:kharkov†** (1):   FC Metalist Kharkiv
- **city:dnipropetrovsk†** (1):   FC Dnipro




By Year

- ? (14):   FC Dynamo Kyiv · FC Arsenal Kyiv · FC Shakhtar Donetsk · FC Metalurh Donetsk · FC Olimpik Donetsk · FC Metalist Kharkiv · FC Dnipro · FC Vorskla Poltava · FC Karpaty Lviv · SC Tavriya Simferopol · FC Zorya Luhansk · FC Mariupol · FC Olexandriya · FC Chornomorets Odesa






By A to Z

- **A** (1): Arsenal Kyiv
- **C** (1): Chornomorets Odesa
- **D** (6): Dnipro · Dinamo Kiev · Dynamo Kiev · Dynamo Kiew · Dynamo Kyiv · Dnipro Dnipropetrovsk
- **F** (15): FC Dnipro · FC Mariupol · FC Dynamo Kiew · FC Dynamo Kyiv · FC Olexandriya · FC Arsenal Kyiv · FC Karpaty Lviv · FC Zorya Luhansk · FC Olimpik Donetsk · FC Vorskla Poltava · FC Metalist Kharkiv · FC Metalurh Donetsk · FC Shakhtar Donetsk · FC Chornomorets Odesa · FC Dnipro Dnipropetrovsk
- **K** (1): Karpaty
- **M** (4): Mariupol · Metalist · Metalist Kharkiv · Metalurh Donetsk
- **O** (2): Olexandriya · Olimpik Donetsk
- **S** (5): Shakhtar Don. · Schachtar Donezk · Shakhtar Donetsk · Schachtjor Donezk · SC Tavriya Simferopol
- **T** (1): Tavriya
- **V** (1): Vorskla
- **Z** (1): Zorya Luhansk




