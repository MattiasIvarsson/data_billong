12 clubs

- **FK Ekranas** : (1) Ekranas
- **FK Sūduva** : (1) Sūduva ⇒ (2) ≈Suduva≈ · ≈FK Suduva≈
- **FK Tauras**
- **FK Vėtra** ⇒ (1) ≈FK Vetra≈
- **FC Šiauliai** ⇒ (1) ≈FC Siauliai≈
- **VMFD Žalgiris** : (3) Žalgiris · Žalgiris Vilnius · FK Žalgiris Vilnius ⇒ (4) ≈Zalgiris≈ · ≈VMFD Zalgiris≈ · ≈Zalgiris Vilnius≈ · ≈FK Zalgiris Vilnius≈
- **FBK Kaunas**
- **FK Banga**
- **FK Riteriai** : (1) Riteriai
- **FC Stumbras**
- **FK Atlantas**
- **FK Kruoja**




Alphabet

- **Alphabet Specials** (4):  **ė**  **Š**  **ū**  **Ž** 
  - **ė**×1 U+0117 (279) - LATIN SMALL LETTER E WITH DOT ABOVE ⇒ e
  - **Š**×1 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **ū**×2 U+016B (363) - LATIN SMALL LETTER U WITH MACRON ⇒ u
  - **Ž**×4 U+017D (381) - LATIN CAPITAL LETTER Z WITH CARON ⇒ Z




Duplicates





By City

- ? (12): 
  - FK Ekranas  (1) Ekranas
  - FK Sūduva  (1) Sūduva
  - FK Tauras 
  - FK Vėtra 
  - FC Šiauliai 
  - VMFD Žalgiris  (3) Žalgiris · Žalgiris Vilnius · FK Žalgiris Vilnius
  - FBK Kaunas 
  - FK Banga 
  - FK Riteriai  (1) Riteriai
  - FC Stumbras 
  - FK Atlantas 
  - FK Kruoja 




By Region





By Year

- ? (12):   FK Ekranas · FK Sūduva · FK Tauras · FK Vėtra · FC Šiauliai · VMFD Žalgiris · FBK Kaunas · FK Banga · FK Riteriai · FC Stumbras · FK Atlantas · FK Kruoja






By A to Z

- **E** (1): Ekranas
- **F** (12): FK Banga · FK Vėtra · FK Kruoja · FK Sūduva · FK Tauras · FBK Kaunas · FK Ekranas · FC Stumbras · FC Šiauliai · FK Atlantas · FK Riteriai · FK Žalgiris Vilnius
- **R** (1): Riteriai
- **S** (1): Sūduva
- **V** (1): VMFD Žalgiris
- **Ž** (2): Žalgiris · Žalgiris Vilnius




