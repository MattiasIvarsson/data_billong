8 clubs

- **Valletta FC** : (1) Valletta
- **Sliema Wanderers FC** : (1) Sliema Wanderers
- **Birkirkara FC** : (1) Birkirkara
- **Floriana FC**
- **Hibernians FC** : (1) Hibernians
- **Marsaxlokk FC**
- **Balzan FC**
- **Gżira United FC** ⇒ (1) ≈Gzira United FC≈




Alphabet

- **Alphabet Specials** (1):  **ż** 
  - **ż**×1 U+017C (380) - LATIN SMALL LETTER Z WITH DOT ABOVE ⇒ z




Duplicates





By City

- **Sliema** (1): Sliema Wanderers FC  (1) Sliema Wanderers
- **Valletta** (1): Valletta FC  (1) Valletta
- ? (6): 
  - Birkirkara FC  (1) Birkirkara
  - Floriana FC 
  - Hibernians FC  (1) Hibernians
  - Marsaxlokk FC 
  - Balzan FC 
  - Gżira United FC 




By Region

- **Valletta†** (1):   Valletta FC
- **Sliema†** (1):   Sliema Wanderers FC




By Year

- ? (8):   Valletta FC · Sliema Wanderers FC · Birkirkara FC · Floriana FC · Hibernians FC · Marsaxlokk FC · Balzan FC · Gżira United FC






By A to Z

- **B** (3): Balzan FC · Birkirkara · Birkirkara FC
- **F** (1): Floriana FC
- **G** (1): Gżira United FC
- **H** (2): Hibernians · Hibernians FC
- **M** (1): Marsaxlokk FC
- **S** (2): Sliema Wanderers · Sliema Wanderers FC
- **V** (2): Valletta · Valletta FC




