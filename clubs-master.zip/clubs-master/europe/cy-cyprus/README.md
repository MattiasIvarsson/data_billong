8 clubs

- **AC Omonia Nicosia** : (3) Omonia · AC Omonia · Omonia Nicosia
- **APOEL Nicosia FC** : (3) APOEL · APOEL FC · APOEL Nikosia
- **Anorthosis Famagusta FC** : (2) Anorthosis · Anorthosis Famagusta
- **AEL Limassol** : (3) AEL · AEL Limassol FC · Athlitiki Enosi Lemesou
- **Apollon Limassol FC** : (1) Apollon
- **AEK Larnaca FC** : (1) AEK Larnaca
- **APOP/Kinyras Peyias FC** : (1) APOP
- **Ermis Aradippou FC** : (1) Ermis




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Nicosia** (2): 
  - AC Omonia Nicosia  (3) Omonia · Omonia Nicosia · AC Omonia
  - APOEL Nicosia FC  (3) APOEL Nikosia · APOEL · APOEL FC
- **Larnaca** (1): Anorthosis Famagusta FC  (2) Anorthosis · Anorthosis Famagusta
- **Limassol** (1): AEL Limassol  (3) AEL · AEL Limassol FC · Athlitiki Enosi Lemesou
- ? (4): 
  - Apollon Limassol FC  (1) Apollon
  - AEK Larnaca FC  (1) AEK Larnaca
  - APOP/Kinyras Peyias FC  (1) APOP
  - Ermis Aradippou FC  (1) Ermis




By Region

- **Nicosia†** (2):   AC Omonia Nicosia · APOEL Nicosia FC
- **Larnaca†** (1):   Anorthosis Famagusta FC
- **Limassol†** (1):   AEL Limassol




By Year

- ? (8):   AC Omonia Nicosia · APOEL Nicosia FC · Anorthosis Famagusta FC · AEL Limassol · Apollon Limassol FC · AEK Larnaca FC · APOP/Kinyras Peyias FC · Ermis Aradippou FC






By A to Z

- **A** (19): AEL · APOP · APOEL · Apollon · APOEL FC · AC Omonia · Anorthosis · AEK Larnaca · AEL Limassol · APOEL Nikosia · AEK Larnaca FC · AEL Limassol FC · APOEL Nicosia FC · AC Omonia Nicosia · Apollon Limassol FC · Anorthosis Famagusta · APOP/Kinyras Peyias FC · Anorthosis Famagusta FC · Athlitiki Enosi Lemesou
- **E** (2): Ermis · Ermis Aradippou FC
- **O** (2): Omonia · Omonia Nicosia




