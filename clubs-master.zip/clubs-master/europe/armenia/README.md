8 clubs

- **FC Pyunik**
- **Ulisses FC**
- **FC Mika**
- **FC Gandzasar**
- **FC Banants** : (1) Banants
- **FC Shirak**
- **FC Ararat**
- **Alashkert FC**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- ? (8): 
  - FC Pyunik 
  - Ulisses FC 
  - FC Mika 
  - FC Gandzasar 
  - FC Banants  (1) Banants
  - FC Shirak 
  - FC Ararat 
  - Alashkert FC 




By Region





By Year

- ? (8):   FC Pyunik · Ulisses FC · FC Mika · FC Gandzasar · FC Banants · FC Shirak · FC Ararat · Alashkert FC






By A to Z

- **A** (1): Alashkert FC
- **B** (1): Banants
- **F** (6): FC Mika · FC Ararat · FC Pyunik · FC Shirak · FC Banants · FC Gandzasar
- **U** (1): Ulisses FC




