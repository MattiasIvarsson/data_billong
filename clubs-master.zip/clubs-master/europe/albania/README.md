13 clubs

- [**KF Tirana**](https://en.wikipedia.org/wiki/KF_Tirana) : (2) Tirana · Klubi i Futbollit Tirana
- [**FK Partizani Tirana**](https://en.wikipedia.org/wiki/FK_Partizani_Tirana) : (2) Partizani · FK Partizani
- **FK Dinamo Tirana**
- [**KS Skënderbeu**](https://en.wikipedia.org/wiki/KF_Skënderbeu_Korçë) : (4) Skënderbeu · KF Skënderbeu · Skënderbeu Korçë · KF Skënderbeu Korçë ⇒ (5) ≈Skenderbeu≈ · ≈KS Skenderbeu≈ · ≈KF Skenderbeu≈ · ≈Skenderbeu Korce≈ · ≈KF Skenderbeu Korce≈
- [**KS Flamurtari**](https://en.wikipedia.org/wiki/Flamurtari_Vlorë) : (2) Flamurtari · Flamurtari Vlorë ⇒ (1) ≈Flamurtari Vlore≈
- **KF Vllaznia**
- **KS Besa**
- [**KS Teuta**](https://en.wikipedia.org/wiki/KF_Teuta_Durrës) : (3) Teuta · KF Teuta · KF Teuta Durrës ⇒ (1) ≈KF Teuta Durres≈
- [**KF Laçi**](https://en.wikipedia.org/wiki/KF_Laçi) : (1) Laçi ⇒ (2) ≈Laci≈ · ≈KF Laci≈
- [**FK Kukësi**](https://en.wikipedia.org/wiki/FK_Kukësi) : (2) Kukës · Kukësi ⇒ (3) ≈Kukes≈ · ≈Kukesi≈ · ≈FK Kukesi≈
- [**KS Luftëtari**](https://en.wikipedia.org/wiki/Luftëtari_Gjirokastër_FC) : (2) Luftëtari · Luftëtari Gjirokastër FC ⇒ (3) ≈Luftetari≈ · ≈KS Luftetari≈ · ≈Luftetari Gjirokaster FC≈
- [**FC Kamza**](https://en.wikipedia.org/wiki/FC_Kamza) : (1) Kamza
- [**KS Kastrioti**](https://en.wikipedia.org/wiki/KS_Kastrioti) : (1) Kastrioti




Alphabet

- **Alphabet Specials** (2):  **ç**  **ë** 
  - **ç**×4 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **ë**×16 U+00EB (235) - LATIN SMALL LETTER E WITH DIAERESIS ⇒ e




Duplicates





By City

- **Tirana** (3): 
  - KF Tirana  (2) Tirana · Klubi i Futbollit Tirana
  - FK Partizani Tirana  (2) Partizani · FK Partizani
  - FK Dinamo Tirana 
- ? (10): 
  - KS Skënderbeu  (4) Skënderbeu · KF Skënderbeu · KF Skënderbeu Korçë · Skënderbeu Korçë
  - KS Flamurtari  (2) Flamurtari Vlorë · Flamurtari
  - KF Vllaznia 
  - KS Besa 
  - KS Teuta  (3) KF Teuta · KF Teuta Durrës · Teuta
  - KF Laçi  (1) Laçi
  - FK Kukësi  (2) Kukësi · Kukës
  - KS Luftëtari  (2) Luftëtari · Luftëtari Gjirokastër FC
  - FC Kamza  (1) Kamza
  - KS Kastrioti  (1) Kastrioti




By Region

- **Tirana†** (3):   KF Tirana · FK Partizani Tirana · FK Dinamo Tirana




By Year

- ? (13):   KF Tirana · FK Partizani Tirana · FK Dinamo Tirana · KS Skënderbeu · KS Flamurtari · KF Vllaznia · KS Besa · KS Teuta · KF Laçi · FK Kukësi · KS Luftëtari · FC Kamza · KS Kastrioti






By A to Z

- **F** (7): FC Kamza · FK Kukësi · Flamurtari · FK Partizani · FK Dinamo Tirana · Flamurtari Vlorë · FK Partizani Tirana
- **K** (18): Kamza · Kukës · Kukësi · KF Laçi · KS Besa · KF Teuta · KS Teuta · KF Tirana · Kastrioti · KF Vllaznia · KS Kastrioti · KS Luftëtari · KF Skënderbeu · KS Flamurtari · KS Skënderbeu · KF Teuta Durrës · KF Skënderbeu Korçë · Klubi i Futbollit Tirana
- **L** (3): Laçi · Luftëtari · Luftëtari Gjirokastër FC
- **P** (1): Partizani
- **S** (2): Skënderbeu · Skënderbeu Korçë
- **T** (2): Teuta · Tirana




