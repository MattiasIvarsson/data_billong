10 clubs

- **FK Budućnost Podgorica** : (1) Budućnost Podgorica ⇒ (2) ≈Buducnost Podgorica≈ · ≈FK Buducnost Podgorica≈
- **FK Mogren**
- **FK Zeta**
- **FK Rudar Pljevlja** : (1) Rudar Pljevlja
- **OFK Petrovac**
- **FK Čelik Nikšić** ⇒ (1) ≈FK Celik Niksic≈
- **FK Sutjeska** : (2) Sutjeska · Sutjeska Nikšić ⇒ (1) ≈Sutjeska Niksic≈
- **OFK Titograd** : (1) Titograd
- **FK Bokelj**
- **FK Lovćen** ⇒ (1) ≈FK Lovcen≈




Alphabet

- **Alphabet Specials** (3):  **ć**  **Č**  **š** 
  - **ć**×5 U+0107 (263) - LATIN SMALL LETTER C WITH ACUTE ⇒ c
  - **Č**×1 U+010C (268) - LATIN CAPITAL LETTER C WITH CARON ⇒ C
  - **š**×2 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s




Duplicates





By City

- ? (10): 
  - FK Budućnost Podgorica  (1) Budućnost Podgorica
  - FK Mogren 
  - FK Zeta 
  - FK Rudar Pljevlja  (1) Rudar Pljevlja
  - OFK Petrovac 
  - FK Čelik Nikšić 
  - FK Sutjeska  (2) Sutjeska · Sutjeska Nikšić
  - OFK Titograd  (1) Titograd
  - FK Bokelj 
  - FK Lovćen 




By Region





By Year

- ? (10):   FK Budućnost Podgorica · FK Mogren · FK Zeta · FK Rudar Pljevlja · OFK Petrovac · FK Čelik Nikšić · FK Sutjeska · OFK Titograd · FK Bokelj · FK Lovćen






By A to Z

- **B** (1): Budućnost Podgorica
- **F** (8): FK Zeta · FK Bokelj · FK Lovćen · FK Mogren · FK Sutjeska · FK Čelik Nikšić · FK Rudar Pljevlja · FK Budućnost Podgorica
- **O** (2): OFK Petrovac · OFK Titograd
- **R** (1): Rudar Pljevlja
- **S** (2): Sutjeska · Sutjeska Nikšić
- **T** (1): Titograd




