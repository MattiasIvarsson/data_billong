10 clubs

- **GNK Dinamo Zagreb** : (2) Dinamo Zagreb · NK Dinamo Zagreb
- **NK Lokomotiva Zagreb** : (1) Lokomotiva Zagreb
- **HNK Hajduk Split** : (1) Hajduk Split
- **RNK Split**
- **NK Slaven Koprivnica** : (1) Slaven Koprivnica
- **NK Varaždin** : (1) Varaždin ⇒ (2) ≈Varazdin≈ · ≈NK Varazdin≈
- **HNK Rijeka** : (1) Rijeka
- **NK Osijek** : (1) Osijek
- **HNK Cibalia** : (1) Cibalia
- **HNK Šibenik** : (1) Šibenik ⇒ (2) ≈Sibenik≈ · ≈HNK Sibenik≈




Alphabet

- **Alphabet Specials** (2):  **Š**  **ž** 
  - **Š**×2 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **ž**×2 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Split** (2): 
  - HNK Hajduk Split  (1) Hajduk Split
  - RNK Split 
- **Zagreb** (2): 
  - GNK Dinamo Zagreb  (2) Dinamo Zagreb · NK Dinamo Zagreb
  - NK Lokomotiva Zagreb  (1) Lokomotiva Zagreb
- ? (6): 
  - NK Slaven Koprivnica  (1) Slaven Koprivnica
  - NK Varaždin  (1) Varaždin
  - HNK Rijeka  (1) Rijeka
  - NK Osijek  (1) Osijek
  - HNK Cibalia  (1) Cibalia
  - HNK Šibenik  (1) Šibenik




By Region

- **Zagreb†** (2):   GNK Dinamo Zagreb · NK Lokomotiva Zagreb
- **Split†** (2):   HNK Hajduk Split · RNK Split




By Year

- ? (10):   GNK Dinamo Zagreb · NK Lokomotiva Zagreb · HNK Hajduk Split · RNK Split · NK Slaven Koprivnica · NK Varaždin · HNK Rijeka · NK Osijek · HNK Cibalia · HNK Šibenik






By A to Z

- **C** (1): Cibalia
- **D** (1): Dinamo Zagreb
- **G** (1): GNK Dinamo Zagreb
- **H** (5): HNK Rijeka · HNK Cibalia · HNK Šibenik · Hajduk Split · HNK Hajduk Split
- **L** (1): Lokomotiva Zagreb
- **N** (5): NK Osijek · NK Varaždin · NK Dinamo Zagreb · NK Lokomotiva Zagreb · NK Slaven Koprivnica
- **O** (1): Osijek
- **R** (2): Rijeka · RNK Split
- **S** (1): Slaven Koprivnica
- **V** (1): Varaždin
- **Š** (1): Šibenik




