19 clubs

- **The New Saints FC** : (2) TNS · The New Saints
- **Bangor City FC** : (2) Bangor · Bangor City
- **Llanelli AFC**
- **Rhyl FC**
- **Cefn Druids AFC**
- **Neath FC**
- **Port Talbot Town FC**
- **Connah's Quay Nomads FC**
- **Bala Town FC**
- **Llandudno FC**
- **Newtown AFC**
- **AUK Broughton FC**
- **Aberystwyth Town FC**
- [**Swansea City FC**](https://en.wikipedia.org/wiki/Swansea_City_A.F.C.) : (3) Swansea · Swansea City · Swansea City AFC
- [**Cardiff City FC**](https://en.wikipedia.org/wiki/Cardiff_City_F.C.) : (2) Cardiff · Cardiff City
- [**Newport County AFC**](https://en.wikipedia.org/wiki/Newport_County_A.F.C.) : (1) Newport County
- **Wrexham AFC** : (1) Wrexham
- **Merthyr Town FC** : (1) Merthyr Town
- **Aberdare Athletic FC (1893-1928)** : (1) Aberdare Athletic




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Aberdare** (1): Aberdare Athletic FC (1893-1928)  (1) Aberdare Athletic
- **Cardiff** (1): Cardiff City FC  (2) Cardiff · Cardiff City
- **Merthyr Tydfil** (1): Merthyr Town FC  (1) Merthyr Town
- **Newport** (1): Newport County AFC  (1) Newport County
- **Oswestry** (1): The New Saints FC  (2) The New Saints · TNS
- **Swansea** (1): Swansea City FC  (3) Swansea · Swansea City · Swansea City AFC
- **Wrexham** (1): Wrexham AFC  (1) Wrexham
- ? (12): 
  - Bangor City FC  (2) Bangor · Bangor City
  - Llanelli AFC 
  - Rhyl FC 
  - Cefn Druids AFC 
  - Neath FC 
  - Port Talbot Town FC 
  - Connah's Quay Nomads FC 
  - Bala Town FC 
  - Llandudno FC 
  - Newtown AFC 
  - AUK Broughton FC 
  - Aberystwyth Town FC 




By Region

- **Oswestry†** (1):   The New Saints FC
- **Swansea†** (1):   Swansea City FC
- **Cardiff†** (1):   Cardiff City FC
- **Newport†** (1):   Newport County AFC
- **Wrexham†** (1):   Wrexham AFC
- **Merthyr Tydfil†** (1):   Merthyr Town FC
- **Aberdare†** (1):   Aberdare Athletic FC (1893-1928)




By Year

- **1893** (1):   Aberdare Athletic FC (1893-1928)
- **1912** (2):   Swansea City FC · Newport County AFC
- ? (16):   The New Saints FC · Bangor City FC · Llanelli AFC · Rhyl FC · Cefn Druids AFC · Neath FC · Port Talbot Town FC · Connah's Quay Nomads FC · Bala Town FC · Llandudno FC · Newtown AFC · AUK Broughton FC · Aberystwyth Town FC · Cardiff City FC · Wrexham AFC · Merthyr Town FC




Historic

- **1928** (1):   Aberdare Athletic FC (1893-1928)






By A to Z

- **A** (4): AUK Broughton FC · Aberdare Athletic · Aberystwyth Town FC · Aberdare Athletic FC (1893-1928)
- **B** (4): Bangor · Bangor City · Bala Town FC · Bangor City FC
- **C** (5): Cardiff · Cardiff City · Cardiff City FC · Cefn Druids AFC · Connah's Quay Nomads FC
- **L** (2): Llandudno FC · Llanelli AFC
- **M** (2): Merthyr Town · Merthyr Town FC
- **N** (4): Neath FC · Newtown AFC · Newport County · Newport County AFC
- **P** (1): Port Talbot Town FC
- **R** (1): Rhyl FC
- **S** (4): Swansea · Swansea City · Swansea City FC · Swansea City AFC
- **T** (3): TNS · The New Saints · The New Saints FC
- **W** (2): Wrexham · Wrexham AFC




