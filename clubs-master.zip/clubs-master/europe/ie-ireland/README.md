21 clubs

- **Shamrock Rovers FC** : (1) Shamrock Rovers
- **Bohemian F.C.** : (2) Bohemians · Bohemian FC
- **St Patrick's Athletic F.C.** : (4) St Patrick's · St. Patricks · St Patrick's Athletic · Saint Patrick's Athletic FC
- **University College Dublin A.F.C.** : (3) UCD · UC Dublin · University College Dublin AFC
- **Shelbourne F.C.** : (1) Shelbourne
- **Athlone Town A.F.C.** : (2) Athlone · Athlone Town
- **Bray Wanderers F.C.** : (2) Bray · Bray Wanderers
- **Cobh Ramblers F.C.** : (1) Cobh Ramblers
- **Cork City F.C.** : (3) Cork · Cork City · Cork City FC
- **Drogheda United F.C.** : (3) Drogheda · Drogheda United · Drogheda United FC
- **Dundalk F.C.** : (2) Dundalk · Dundalk FC
- **Finn Harps F.C.** : (1) Finn Harps
- **Galway United F.C.** : (2) Galway · Galway United
- **Limerick F.C.** : (1) Limerick
- **Longford Town F.C.** : (2) Longford · Longford Town
- **Mervue**
- **Monaghan**
- **Sligo Rovers F.C.** : (3) Sligo · Sligo Rovers · Sligo Rovers FC
- **Waterford F.C.** : (1) Waterford
- **Wexford F.C.** : (1) Wexford
- **Sporting Fingal FC**




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **Bohemian F.C.**, Dublin (1):
  - `bohemianfc` (2): Bohemian F.C. · Bohemian FC
- **St Patrick's Athletic F.C.**, Dublin (1):
  - `stpatricks` (2): St Patrick's · St. Patricks
- **University College Dublin A.F.C.**, Dublin (1):
  - `universitycollegedublinafc` (2): University College Dublin A.F.C. · University College Dublin AFC
- **Cork City F.C.**, Cork (1):
  - `corkcityfc` (2): Cork City F.C. · Cork City FC
- **Drogheda United F.C.**, Drogheda (1):
  - `droghedaunitedfc` (2): Drogheda United F.C. · Drogheda United FC
- **Dundalk F.C.**, Dundalk (1):
  - `dundalkfc` (2): Dundalk F.C. · Dundalk FC
- **Sligo Rovers F.C.**, Sligo (1):
  - `sligoroversfc` (2): Sligo Rovers F.C. · Sligo Rovers FC




By City

- **Dublin** (5): 
  - Shamrock Rovers FC  (1) Shamrock Rovers
  - Bohemian F.C.  (2) Bohemians · Bohemian FC
  - St Patrick's Athletic F.C.  (4) St Patrick's · St Patrick's Athletic · Saint Patrick's Athletic FC · St. Patricks
  - University College Dublin A.F.C.  (3) UCD · UC Dublin · University College Dublin AFC
  - Shelbourne F.C.  (1) Shelbourne
- **Athlone** (1): Athlone Town A.F.C.  (2) Athlone · Athlone Town
- **Ballybofey** (1): Finn Harps F.C.  (1) Finn Harps
- **Bray** (1): Bray Wanderers F.C.  (2) Bray · Bray Wanderers
- **Cobh** (1): Cobh Ramblers F.C.  (1) Cobh Ramblers
- **Cork** (1): Cork City F.C.  (3) Cork · Cork City · Cork City FC
- **Crossabeg** (1): Wexford F.C.  (1) Wexford
- **Drogheda** (1): Drogheda United F.C.  (3) Drogheda · Drogheda United · Drogheda United FC
- **Dundalk** (1): Dundalk F.C.  (2) Dundalk · Dundalk FC
- **Galway** (1): Galway United F.C.  (2) Galway · Galway United
- **Limerick** (1): Limerick F.C.  (1) Limerick
- **Longford** (1): Longford Town F.C.  (2) Longford · Longford Town
- **Sligo** (1): Sligo Rovers F.C.  (3) Sligo · Sligo Rovers · Sligo Rovers FC
- **Waterford** (1): Waterford F.C.  (1) Waterford
- ? (3): 
  - Mervue 
  - Monaghan 
  - Sporting Fingal FC 




By Region

- **Dublin†** (5):   Shamrock Rovers FC · Bohemian F.C. · St Patrick's Athletic F.C. · University College Dublin A.F.C. · Shelbourne F.C.
- **Athlone†** (1):   Athlone Town A.F.C.
- **Bray†** (1):   Bray Wanderers F.C.
- **Cobh†** (1):   Cobh Ramblers F.C.
- **Cork†** (1):   Cork City F.C.
- **Drogheda†** (1):   Drogheda United F.C.
- **Dundalk†** (1):   Dundalk F.C.
- **Ballybofey†** (1):   Finn Harps F.C.
- **Galway†** (1):   Galway United F.C.
- **Limerick†** (1):   Limerick F.C.
- **Longford†** (1):   Longford Town F.C.
- **Sligo†** (1):   Sligo Rovers F.C.
- **Waterford†** (1):   Waterford F.C.
- **Crossabeg†** (1):   Wexford F.C.




By Year

- ? (21):   Shamrock Rovers FC · Bohemian F.C. · St Patrick's Athletic F.C. · University College Dublin A.F.C. · Shelbourne F.C. · Athlone Town A.F.C. · Bray Wanderers F.C. · Cobh Ramblers F.C. · Cork City F.C. · Drogheda United F.C. · Dundalk F.C. · Finn Harps F.C. · Galway United F.C. · Limerick F.C. · Longford Town F.C. · Mervue · Monaghan · Sligo Rovers F.C. · Waterford F.C. · Wexford F.C. · Sporting Fingal FC






By A to Z

- **A** (3): Athlone · Athlone Town · Athlone Town A.F.C.
- **B** (6): Bray · Bohemians · Bohemian FC · Bohemian F.C. · Bray Wanderers · Bray Wanderers F.C.
- **C** (6): Cork · Cork City · Cork City FC · Cobh Ramblers · Cork City F.C. · Cobh Ramblers F.C.
- **D** (7): Dundalk · Drogheda · Dundalk FC · Dundalk F.C. · Drogheda United · Drogheda United FC · Drogheda United F.C.
- **F** (2): Finn Harps · Finn Harps F.C.
- **G** (3): Galway · Galway United · Galway United F.C.
- **L** (5): Limerick · Longford · Limerick F.C. · Longford Town · Longford Town F.C.
- **M** (2): Mervue · Monaghan
- **S** (14): Sligo · Shelbourne · Sligo Rovers · St Patrick's · St. Patricks · Shamrock Rovers · Shelbourne F.C. · Sligo Rovers FC · Sligo Rovers F.C. · Shamrock Rovers FC · Sporting Fingal FC · St Patrick's Athletic · St Patrick's Athletic F.C. · Saint Patrick's Athletic FC
- **U** (4): UCD · UC Dublin · University College Dublin AFC · University College Dublin A.F.C.
- **W** (4): Wexford · Waterford · Wexford F.C. · Waterford F.C.




