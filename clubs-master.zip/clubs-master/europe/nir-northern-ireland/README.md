10 clubs

- **Derry City F.C.** : (3) Derry · Derry City · Derry City FC
- **Linfield FC** : (1) Linfield
- **Glentoran FC** : (1) Glentoran
- **Cliftonville FC** : (1) Cliftonville
- **Crusaders FC** : (1) Crusaders
- **Portadown FC**
- **Lisburn Distillery FC**
- **Glenavon FC**
- **Coleraine FC**
- **Ballymena United FC**




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **Derry City F.C.**, Derry (1):
  - `derrycityfc` (2): Derry City F.C. · Derry City FC




By City

- **Belfast** (2): 
  - Linfield FC  (1) Linfield
  - Glentoran FC  (1) Glentoran
- **Derry** (1): Derry City F.C.  (3) Derry · Derry City · Derry City FC
- ? (7): 
  - Cliftonville FC  (1) Cliftonville
  - Crusaders FC  (1) Crusaders
  - Portadown FC 
  - Lisburn Distillery FC 
  - Glenavon FC 
  - Coleraine FC 
  - Ballymena United FC 




By Region

- **Derry†** (1):   Derry City F.C.
- **Belfast†** (2):   Linfield FC · Glentoran FC




By Year

- ? (10):   Derry City F.C. · Linfield FC · Glentoran FC · Cliftonville FC · Crusaders FC · Portadown FC · Lisburn Distillery FC · Glenavon FC · Coleraine FC · Ballymena United FC






By A to Z

- **B** (1): Ballymena United FC
- **C** (5): Crusaders · Cliftonville · Coleraine FC · Crusaders FC · Cliftonville FC
- **D** (4): Derry · Derry City · Derry City FC · Derry City F.C.
- **G** (3): Glentoran · Glenavon FC · Glentoran FC
- **L** (3): Linfield · Linfield FC · Lisburn Distillery FC
- **P** (1): Portadown FC




