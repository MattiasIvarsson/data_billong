30 clubs

- [**Ajax Amsterdam**](https://en.wikipedia.org/wiki/AFC_Ajax) : (3) Ajax · AFC Ajax · Amsterdamsche Football Club Ajax
- [**AZ Alkmaar**](https://en.wikipedia.org/wiki/AZ_Alkmaar) : (2) AZ · Alkmaar Zaanstreek
- [**Feyenoord Rotterdam**](https://en.wikipedia.org/wiki/Feyenoord) : (1) Feyenoord
- **Sparta Rotterdam** : (1) Sparta
- [**SBV Excelsior Rotterdam**](https://en.wikipedia.org/wiki/SBV_Excelsior) : (3) Excelsior · SBV Excelsior · Stichting Betaald Voetbal Excelsior
- [**ADO Den Haag**](https://en.wikipedia.org/wiki/ADO_Den_Haag) : (2) Den Haag · Alles Door Oefening Den Haag
- **FC Dordrecht** : (1) Dordrecht
- [**SC Cambuur**](https://en.wikipedia.org/wiki/SC_Cambuur) : (1) Cambuur
- [**SC Heerenveen**](https://en.wikipedia.org/wiki/SC_Heerenveen) : (2) Heerenveen · Sportclub Heerenveen
- **FC Den Bosch** : (1) Den Bosch
- [**NAC Breda**](https://en.wikipedia.org/wiki/NAC_Breda) : (2) NAC · NOAD ADVENDO Combinatie Breda
- [**PSV Eindhoven**](https://en.wikipedia.org/wiki/PSV_Eindhoven) : (2) PSV · Philips Sport Vereniging
- [**RKC Waalwijk**](https://en.wikipedia.org/wiki/RKC_Waalwijk) : (2) Waalwijk · Rooms Katholieke Combinatie Waalwijk
- [**Willem II Tilburg**](https://en.wikipedia.org/wiki/Willem_II_(football_club)) : (1) Willem II
- [**Fortuna Sittard**](https://en.wikipedia.org/wiki/Fortuna_Sittard) : (1) For Sittard
- [**Roda JC Kerkrade**](https://en.wikipedia.org/wiki/Roda_JC_Kerkrade) : (4) Roda · Roda JC · Roda Kerkrade · Sportvereniging Roda Juliana Combinatie Kerkrade
- [**VVV Venlo**](https://en.wikipedia.org/wiki/VVV-Venlo) : (3) Venlo · VVV-Venlo · Venlose Voetbal Vereniging Venlo
- **Go Ahead Eagles**
- [**Heracles Almelo**](https://en.wikipedia.org/wiki/Heracles_Almelo) : (1) Heracles
- [**FC Twente**](https://en.wikipedia.org/wiki/FC_Twente) : (2) Twente · Football Club Twente
- [**PEC Zwolle**](https://en.wikipedia.org/wiki/PEC_Zwolle) : (2) Zwolle · Prins Hendrik Ende Desespereert Nimmer Combinatie Zwolle
- [**BV De Graafschap**](https://en.wikipedia.org/wiki/De_Graafschap) : (3) Graafschap · De Graafschap · Vereniging Betaald Voetbal De Graafschap
- [**FC Groningen**](https://en.wikipedia.org/wiki/FC_Groningen) : (2) Groningen · Football Club Groningen
- **MVV Maastricht**
- [**NEC Nijmegen**](https://en.wikipedia.org/wiki/N.E.C._(football_club)) : (3) NEC · Nijmegen · Nijmegen Eendracht Combinatie
- **RBC Roosendaal** : (1) Roosendaal
- [**FC Utrecht**](https://en.wikipedia.org/wiki/FC_Utrecht) : (2) Utrecht · Football Club Utrecht
- [**Vitesse Arnhem**](https://en.wikipedia.org/wiki/SBV_Vitesse) : (3) Vitesse · SBV Vitesse · Stichting Betaald Voetbal Vitesse
- **FC Volendam** : (1) Volendam
- [**FC Emmen**](https://en.wikipedia.org/wiki/FC_Emmen) : (1) Emmen




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **VVV Venlo**, Venlo (1):
  - `vvvvenlo` (2): VVV Venlo · VVV-Venlo




By City

- **Rotterdam, Zuid-Holland** (3): 
  - Feyenoord Rotterdam  (1) Feyenoord
  - Sparta Rotterdam  (1) Sparta
  - SBV Excelsior Rotterdam  (3) Excelsior · SBV Excelsior · Stichting Betaald Voetbal Excelsior
- **'s-Hertogenbosch, Noord-Brabant** (1): FC Den Bosch  (1) Den Bosch
- **Alkmaar, Noord-Holland** (1): AZ Alkmaar  (2) AZ · Alkmaar Zaanstreek
- **Almelo, Overijssel** (1): Heracles Almelo  (1) Heracles
- **Amsterdam, Noord-Holland** (1): Ajax Amsterdam  (3) Ajax · AFC Ajax · Amsterdamsche Football Club Ajax
- **Arnhem** (1): Vitesse Arnhem  (3) Vitesse · SBV Vitesse · Stichting Betaald Voetbal Vitesse
- **Breda, Noord-Brabant** (1): NAC Breda  (2) NOAD ADVENDO Combinatie Breda · NAC
- **Den Haag, Zuid-Holland** (1): ADO Den Haag  (2) Den Haag · Alles Door Oefening Den Haag
- **Deventer, Overijssel** (1): Go Ahead Eagles 
- **Doetinchem** (1): BV De Graafschap  (3) Graafschap · De Graafschap · Vereniging Betaald Voetbal De Graafschap
- **Dordrecht, Zuid-Holland** (1): FC Dordrecht  (1) Dordrecht
- **Eindhoven, Noord-Brabant** (1): PSV Eindhoven  (2) Philips Sport Vereniging · PSV
- **Enschede, Overijssel** (1): FC Twente  (2) Twente · Football Club Twente
- **Groningen** (1): FC Groningen  (2) Groningen · Football Club Groningen
- **Heerenveen, Friesland** (1): SC Heerenveen  (2) Heerenveen · Sportclub Heerenveen
- **Kerkrade, Limburg** (1): Roda JC Kerkrade  (4) Roda · Roda JC · Roda Kerkrade · Sportvereniging Roda Juliana Combinatie Kerkrade
- **Leeuwarden, Friesland** (1): SC Cambuur  (1) Cambuur
- **Maastricht** (1): MVV Maastricht 
- **Nijmegen** (1): NEC Nijmegen  (3) Nijmegen · Nijmegen Eendracht Combinatie · NEC
- **Roosendaal** (1): RBC Roosendaal  (1) Roosendaal
- **Sittard, Limburg** (1): Fortuna Sittard  (1) For Sittard
- **Tilburg, Noord-Brabant** (1): Willem II Tilburg  (1) Willem II
- **Utrecht** (1): FC Utrecht  (2) Utrecht · Football Club Utrecht
- **Venlo, Limburg** (1): VVV Venlo  (3) VVV-Venlo · Venlo · Venlose Voetbal Vereniging Venlo
- **Volendam** (1): FC Volendam  (1) Volendam
- **Waalwijk, Noord-Brabant** (1): RKC Waalwijk  (2) Waalwijk · Rooms Katholieke Combinatie Waalwijk
- **Zwolle, Overijssel** (1): PEC Zwolle  (2) Zwolle · Prins Hendrik Ende Desespereert Nimmer Combinatie Zwolle
- ? (1): FC Emmen  (1) Emmen




By Region

- **Noord-Holland** (2):   Ajax Amsterdam · AZ Alkmaar
- **Zuid-Holland** (5):   Feyenoord Rotterdam · Sparta Rotterdam · SBV Excelsior Rotterdam · ADO Den Haag · FC Dordrecht
- **Friesland** (2):   SC Cambuur · SC Heerenveen
- **Noord-Brabant** (5):   FC Den Bosch · NAC Breda · PSV Eindhoven · RKC Waalwijk · Willem II Tilburg
- **Limburg** (3):   Fortuna Sittard · Roda JC Kerkrade · VVV Venlo
- **Overijssel** (4):   Go Ahead Eagles · Heracles Almelo · FC Twente · PEC Zwolle
- **Doetinchem†** (1):   BV De Graafschap
- **Groningen†** (1):   FC Groningen
- **Maastricht†** (1):   MVV Maastricht
- **Nijmegen†** (1):   NEC Nijmegen
- **Roosendaal†** (1):   RBC Roosendaal
- **Utrecht†** (1):   FC Utrecht
- **Arnhem†** (1):   Vitesse Arnhem
- **Volendam†** (1):   FC Volendam




By Year

- **1892** (1):   Vitesse Arnhem
- **1896** (1):   Willem II Tilburg
- **1900** (2):   Ajax Amsterdam · NEC Nijmegen
- **1902** (1):   SBV Excelsior Rotterdam
- **1903** (2):   VVV Venlo · Heracles Almelo
- **1905** (1):   ADO Den Haag
- **1908** (1):   Feyenoord Rotterdam
- **1910** (1):   PEC Zwolle
- **1912** (1):   NAC Breda
- **1913** (1):   PSV Eindhoven
- **1920** (1):   SC Heerenveen
- **1940** (1):   RKC Waalwijk
- **1954** (1):   BV De Graafschap
- **1962** (1):   Roda JC Kerkrade
- **1964** (1):   SC Cambuur
- **1965** (1):   FC Twente
- **1967** (1):   AZ Alkmaar
- **1970** (1):   FC Utrecht
- **1971** (1):   FC Groningen
- ? (9):   Sparta Rotterdam · FC Dordrecht · FC Den Bosch · Fortuna Sittard · Go Ahead Eagles · MVV Maastricht · RBC Roosendaal · FC Volendam · FC Emmen






By A to Z

- **A** (9): AZ · Ajax · AFC Ajax · AZ Alkmaar · ADO Den Haag · Ajax Amsterdam · Alkmaar Zaanstreek · Alles Door Oefening Den Haag · Amsterdamsche Football Club Ajax
- **B** (1): BV De Graafschap
- **C** (1): Cambuur
- **D** (4): Den Haag · Den Bosch · Dordrecht · De Graafschap
- **E** (2): Emmen · Excelsior
- **F** (14): FC Emmen · FC Twente · Feyenoord · FC Utrecht · FC Volendam · For Sittard · FC Den Bosch · FC Dordrecht · FC Groningen · Fortuna Sittard · Feyenoord Rotterdam · Football Club Twente · Football Club Utrecht · Football Club Groningen
- **G** (3): Groningen · Graafschap · Go Ahead Eagles
- **H** (3): Heracles · Heerenveen · Heracles Almelo
- **M** (1): MVV Maastricht
- **N** (7): NAC · NEC · Nijmegen · NAC Breda · NEC Nijmegen · NOAD ADVENDO Combinatie Breda · Nijmegen Eendracht Combinatie
- **P** (5): PSV · PEC Zwolle · PSV Eindhoven · Philips Sport Vereniging · Prins Hendrik Ende Desespereert Nimmer Combinatie Zwolle
- **R** (8): Roda · Roda JC · Roosendaal · RKC Waalwijk · Roda Kerkrade · RBC Roosendaal · Roda JC Kerkrade · Rooms Katholieke Combinatie Waalwijk
- **S** (11): Sparta · SC Cambuur · SBV Vitesse · SBV Excelsior · SC Heerenveen · Sparta Rotterdam · Sportclub Heerenveen · SBV Excelsior Rotterdam · Stichting Betaald Voetbal Vitesse · Stichting Betaald Voetbal Excelsior · Sportvereniging Roda Juliana Combinatie Kerkrade
- **T** (1): Twente
- **U** (1): Utrecht
- **V** (8): Venlo · Vitesse · Volendam · VVV Venlo · VVV-Venlo · Vitesse Arnhem · Venlose Voetbal Vereniging Venlo · Vereniging Betaald Voetbal De Graafschap
- **W** (3): Waalwijk · Willem II · Willem II Tilburg
- **Z** (1): Zwolle




