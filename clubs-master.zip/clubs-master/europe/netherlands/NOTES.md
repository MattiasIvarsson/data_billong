# Notes

## Links

### Eredivisie

Official -> [`eredivisie.nl`](http://eredivisie.nl)

- 18 Teams
- CL/GR, CL/3.QR, 2 EL/4.QR, EL/3.QR, EL/2.QR -- UEFA Ranking #8


#### Wikipedia

- [Eredivisie](http://en.wikipedia.org/wiki/Eredivisie)

