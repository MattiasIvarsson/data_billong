13 clubs

- **Red Star Belgrade** : (3) Crvena Zvezda · Crvena zvezda · FK Crvena zvezda
- **FK Partizan Belgrade** : (3) Partizan · FK Partizan · Partizan Belgrade
- **OFK Beograd**
- **FK Rad Belgrade** : (2) Rad · FK Rad
- **FK Vojvodina** : (1) Vojvodina
- **FK Spartak Zlatibor voda**
- **FK Sloboda Užice** : (1) Sloboda Užice ⇒ (2) ≈Sloboda Uzice≈ · ≈FK Sloboda Uzice≈
- **FK Jagodina** : (1) Jagodina
- **FK Borac Čačak** ⇒ (1) ≈FK Borac Cacak≈
- **FK Spartak Subotica** : (2) Spartak Subotica · FC Spartak Subotica
- **FK Radnicki Niš** : (1) Radnicki Niš ⇒ (2) ≈Radnicki Nis≈ · ≈FK Radnicki Nis≈
- **FK Mladost Lučani** : (1) Mladost Lučani ⇒ (2) ≈Mladost Lucani≈ · ≈FK Mladost Lucani≈
- **FK Čukarički** : (1) Čukarički ⇒ (2) ≈Cukaricki≈ · ≈FK Cukaricki≈




Alphabet

- **Alphabet Specials** (4):  **Č**  **č**  **š**  **ž** 
  - **Č**×3 U+010C (268) - LATIN CAPITAL LETTER C WITH CARON ⇒ C
  - **č**×5 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **š**×2 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s
  - **ž**×2 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates

- **Red Star Belgrade**, Belgrade (1):
  - `crvenazvezda` (2): Crvena Zvezda · Crvena zvezda




By City

- **Belgrade** (4): 
  - Red Star Belgrade  (3) Crvena Zvezda · Crvena zvezda · FK Crvena zvezda
  - FK Partizan Belgrade  (3) Partizan · FK Partizan · Partizan Belgrade
  - OFK Beograd 
  - FK Rad Belgrade  (2) FK Rad · Rad
- ? (9): 
  - FK Vojvodina  (1) Vojvodina
  - FK Spartak Zlatibor voda 
  - FK Sloboda Užice  (1) Sloboda Užice
  - FK Jagodina  (1) Jagodina
  - FK Borac Čačak 
  - FK Spartak Subotica  (2) FC Spartak Subotica · Spartak Subotica
  - FK Radnicki Niš  (1) Radnicki Niš
  - FK Mladost Lučani  (1) Mladost Lučani
  - FK Čukarički  (1) Čukarički




By Region

- **Belgrade†** (4):   Red Star Belgrade · FK Partizan Belgrade · OFK Beograd · FK Rad Belgrade




By Year

- ? (13):   Red Star Belgrade · FK Partizan Belgrade · OFK Beograd · FK Rad Belgrade · FK Vojvodina · FK Spartak Zlatibor voda · FK Sloboda Užice · FK Jagodina · FK Borac Čačak · FK Spartak Subotica · FK Radnicki Niš · FK Mladost Lučani · FK Čukarički






By A to Z

- **C** (2): Crvena Zvezda · Crvena zvezda
- **F** (15): FK Rad · FK Jagodina · FK Partizan · FK Vojvodina · FK Čukarički · FK Borac Čačak · FK Rad Belgrade · FK Radnicki Niš · FK Crvena zvezda · FK Sloboda Užice · FK Mladost Lučani · FC Spartak Subotica · FK Spartak Subotica · FK Partizan Belgrade · FK Spartak Zlatibor voda
- **J** (1): Jagodina
- **M** (1): Mladost Lučani
- **O** (1): OFK Beograd
- **P** (2): Partizan · Partizan Belgrade
- **R** (3): Rad · Radnicki Niš · Red Star Belgrade
- **S** (2): Sloboda Užice · Spartak Subotica
- **V** (1): Vojvodina
- **Č** (1): Čukarički




