11 clubs

- **FC BATE Borisov** : (4) BATE · BATE Borisov · Bate Borisov · BATE Borissow
- **FC Gomel** : (1) Gomel
- **FC Dinamo Minsk** : (1) Dinamo Minsk
- **FC Partizan Minsk** : (1) Partizan Minsk
- **FC Minsk** : (1) Minsk
- **FC Dnepr Mogilev** : (1) Dnepr
- **FC Shakhtyor Soligorsk** : (1) Shakhtyor
- **FC Naftan Novopolotsk** : (1) Naftan
- **FC Torpedo Zhodino** : (1) Torpedo Zhodino
- **FC Dinamo Brest** : (1) Dinamo Brest
- **FC Neman Grodno** : (1) Neman




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **FC BATE Borisov**, Barysaw (1):
  - `bateborisov` (2): BATE Borisov · Bate Borisov




By City

- **Barysaw** (1): FC BATE Borisov  (4) BATE · BATE Borisov · BATE Borissow · Bate Borisov
- ? (10): 
  - FC Gomel  (1) Gomel
  - FC Dinamo Minsk  (1) Dinamo Minsk
  - FC Partizan Minsk  (1) Partizan Minsk
  - FC Minsk  (1) Minsk
  - FC Dnepr Mogilev  (1) Dnepr
  - FC Shakhtyor Soligorsk  (1) Shakhtyor
  - FC Naftan Novopolotsk  (1) Naftan
  - FC Torpedo Zhodino  (1) Torpedo Zhodino
  - FC Dinamo Brest  (1) Dinamo Brest
  - FC Neman Grodno  (1) Neman




By Region

- **Barysaw†** (1):   FC BATE Borisov




By Year

- ? (11):   FC BATE Borisov · FC Gomel · FC Dinamo Minsk · FC Partizan Minsk · FC Minsk · FC Dnepr Mogilev · FC Shakhtyor Soligorsk · FC Naftan Novopolotsk · FC Torpedo Zhodino · FC Dinamo Brest · FC Neman Grodno






By A to Z

- **B** (4): BATE · BATE Borisov · Bate Borisov · BATE Borissow
- **D** (3): Dnepr · Dinamo Brest · Dinamo Minsk
- **F** (11): FC Gomel · FC Minsk · FC BATE Borisov · FC Dinamo Brest · FC Dinamo Minsk · FC Neman Grodno · FC Dnepr Mogilev · FC Partizan Minsk · FC Torpedo Zhodino · FC Naftan Novopolotsk · FC Shakhtyor Soligorsk
- **G** (1): Gomel
- **M** (1): Minsk
- **N** (2): Neman · Naftan
- **P** (1): Partizan Minsk
- **S** (1): Shakhtyor
- **T** (1): Torpedo Zhodino




