18 clubs

- [**AC Sparta Praha**](https://en.wikipedia.org/wiki/AC_Sparta_Prague) : (4) Sparta Praha · Sparta Prague · AC Sparta Prague [en] · Athletic Club Sparta Praha
- [**FK Dukla Praha**](https://en.wikipedia.org/wiki/FK_Dukla_Prague) : (2) Dukla · FK Dukla Prague [en]
- [**SK Slavia Praha**](https://en.wikipedia.org/wiki/SK_Slavia_Prague) : (4) Slavia Praha · Slavia Prague [en] · SK Slavia Prague [en] · Sportovní klub Slavia Praha ⇒ (1) ≈Sportovni klub Slavia Praha≈
- [**Bohemians Praha 1905**](https://en.wikipedia.org/wiki/Bohemians_1905) : (1) Bohemians 1905
- [**FK Mladá Boleslav**](https://en.wikipedia.org/wiki/FK_Mladá_Boleslav) : (2) Mladá Boleslav · Fotbalový klub Mladá Boleslav ⇒ (3) ≈Mlada Boleslav≈ · ≈FK Mlada Boleslav≈ · ≈Fotbalovy klub Mlada Boleslav≈
- [**1. FK Příbram**](https://en.wikipedia.org/wiki/1._FK_Příbram) : (1) Příbram ⇒ (2) ≈Pribram≈ · ≈1. FK Pribram≈
- [**Viktoria Plzeň**](https://en.wikipedia.org/wiki/FC_Viktoria_Plzeň) : (3) Plzeň · FC Viktoria Plzeň · Football Club Viktoria Plzeň ⇒ (4) ≈Plzen≈ · ≈Viktoria Plzen≈ · ≈FC Viktoria Plzen≈ · ≈Football Club Viktoria Plzen≈
- [**FC Slovan Liberec**](https://en.wikipedia.org/wiki/FC_Slovan_Liberec) : (2) Liberec · Football Club Slovan Liberec
- [**FK Jablonec**](https://en.wikipedia.org/wiki/FK_Jablonec) : (1) Jablonec
- [**FC Baník Ostrava**](https://en.wikipedia.org/wiki/FC_Baník_Ostrava) : (1) Baník ⇒ (2) ≈Banik≈ · ≈FC Banik Ostrava≈
- [**SK Sigma Olomouc**](https://en.wikipedia.org/wiki/SK_Sigma_Olomouc) : (1) Sigma
- [**FK Teplice**](https://en.wikipedia.org/wiki/FK_Teplice) : (1) Teplice
- [**1. FC Slovácko**](https://en.wikipedia.org/wiki/1._FC_Slovácko) : (1) Slovácko ⇒ (2) ≈Slovacko≈ · ≈1. FC Slovacko≈
- [**FC Zlín**](https://en.wikipedia.org/wiki/FC_Fastav_Zlín) : (3) Zlín · Fastav Zlín · FC Fastav Zlín ⇒ (4) ≈Zlin≈ · ≈FC Zlin≈ · ≈Fastav Zlin≈ · ≈FC Fastav Zlin≈
- [**FC Vysočina Jihlava**](https://en.wikipedia.org/wiki/FC_Vysočina_Jihlava) : (1) Jihlava ⇒ (1) ≈FC Vysocina Jihlava≈
- [**FC Zbrojovka Brno**](https://en.wikipedia.org/wiki/FC_Zbrojovka_Brno) : (1) Brno
- [**MFK Karviná**](https://en.wikipedia.org/wiki/MFK_Karviná) : (1) Karviná ⇒ (2) ≈Karvina≈ · ≈MFK Karvina≈
- [**SFC Opava**](https://en.wikipedia.org/wiki/SFC_Opava) : (1) Opava




Alphabet

- **Alphabet Specials** (6):  **á**  **í**  **ý**  **č**  **ň**  **ř** 
  - **á**×7 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **í**×9 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ý**×1 U+00FD (253) - LATIN SMALL LETTER Y WITH ACUTE ⇒ y
  - **č**×1 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **ň**×4 U+0148 (328) - LATIN SMALL LETTER N WITH CARON ⇒ n
  - **ř**×2 U+0159 (345) - LATIN SMALL LETTER R WITH CARON ⇒ r




Duplicates





By City

- **Praha** (4): 
  - AC Sparta Praha  (4) Sparta Praha · Sparta Prague · Athletic Club Sparta Praha · AC Sparta Prague [en]
  - FK Dukla Praha  (2) Dukla · FK Dukla Prague [en]
  - SK Slavia Praha  (4) Slavia Praha · Sportovní klub Slavia Praha · SK Slavia Prague [en] · Slavia Prague [en]
  - Bohemians Praha 1905  (1) Bohemians 1905
- **Brno** (1): FC Zbrojovka Brno  (1) Brno
- **Jablonec nad Nisou** (1): FK Jablonec  (1) Jablonec
- **Jihlava** (1): FC Vysočina Jihlava  (1) Jihlava
- **Liberec** (1): FC Slovan Liberec  (2) Liberec · Football Club Slovan Liberec
- **Mladá Boleslav** (1): FK Mladá Boleslav  (2) Mladá Boleslav · Fotbalový klub Mladá Boleslav
- **Olomouc** (1): SK Sigma Olomouc  (1) Sigma
- **Ostrava** (1): FC Baník Ostrava  (1) Baník
- **Plzeň** (1): Viktoria Plzeň  (3) Plzeň · FC Viktoria Plzeň · Football Club Viktoria Plzeň
- **Příbram** (1): 1. FK Příbram  (1) Příbram
- **Teplice** (1): FK Teplice  (1) Teplice
- **Uherské Hradiště** (1): 1. FC Slovácko  (1) Slovácko
- **Zlín** (1): FC Zlín  (3) Zlín · FC Fastav Zlín · Fastav Zlín
- ? (2): 
  - MFK Karviná  (1) Karviná
  - SFC Opava  (1) Opava




By Region

- **Praha†** (4):   AC Sparta Praha · FK Dukla Praha · SK Slavia Praha · Bohemians Praha 1905
- **Mladá Boleslav†** (1):   FK Mladá Boleslav
- **Příbram†** (1):   1. FK Příbram
- **Plzeň†** (1):   Viktoria Plzeň
- **Liberec†** (1):   FC Slovan Liberec
- **Jablonec nad Nisou†** (1):   FK Jablonec
- **Ostrava†** (1):   FC Baník Ostrava
- **Olomouc†** (1):   SK Sigma Olomouc
- **Teplice†** (1):   FK Teplice
- **Uherské Hradiště†** (1):   1. FC Slovácko
- **Zlín†** (1):   FC Zlín
- **Jihlava†** (1):   FC Vysočina Jihlava
- **Brno†** (1):   FC Zbrojovka Brno




By Year

- **1892** (1):   SK Slavia Praha
- **1893** (1):   AC Sparta Praha
- **1902** (1):   FK Mladá Boleslav
- **1905** (1):   Bohemians Praha 1905
- **1911** (1):   Viktoria Plzeň
- **1913** (1):   FC Zbrojovka Brno
- **1919** (2):   SK Sigma Olomouc · FC Zlín
- **1922** (1):   FC Baník Ostrava
- **1927** (1):   1. FC Slovácko
- **1928** (1):   1. FK Příbram
- **1945** (2):   FK Jablonec · FK Teplice
- **1948** (1):   FC Vysočina Jihlava
- **1958** (2):   FK Dukla Praha · FC Slovan Liberec
- ? (2):   MFK Karviná · SFC Opava






By A to Z

- **1** (2): 1. FK Příbram · 1. FC Slovácko
- **A** (3): AC Sparta Praha · AC Sparta Prague [en] · Athletic Club Sparta Praha
- **B** (4): Brno · Baník · Bohemians 1905 · Bohemians Praha 1905
- **D** (1): Dukla
- **F** (16): FC Zlín · FK Teplice · FK Jablonec · Fastav Zlín · FC Fastav Zlín · FK Dukla Praha · FC Baník Ostrava · FC Slovan Liberec · FC Viktoria Plzeň · FC Zbrojovka Brno · FK Mladá Boleslav · FC Vysočina Jihlava · FK Dukla Prague [en] · Football Club Slovan Liberec · Football Club Viktoria Plzeň · Fotbalový klub Mladá Boleslav
- **J** (2): Jihlava · Jablonec
- **K** (1): Karviná
- **L** (1): Liberec
- **M** (2): MFK Karviná · Mladá Boleslav
- **O** (1): Opava
- **P** (2): Plzeň · Příbram
- **S** (11): Sigma · Slovácko · SFC Opava · Slavia Praha · Sparta Praha · Sparta Prague · SK Slavia Praha · SK Sigma Olomouc · Slavia Prague [en] · SK Slavia Prague [en] · Sportovní klub Slavia Praha
- **T** (1): Teplice
- **V** (1): Viktoria Plzeň
- **Z** (1): Zlín




