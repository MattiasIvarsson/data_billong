12 clubs

- **FK Metalurg Skopje**
- **FK Makedonija Skopje**
- **FK Rabotnički** : (4) Rabotnički · Rabotnicki · FK Rabotnicki · Rabotnički Skopje ⇒ (3) ≈Rabotnicki≈ · ≈FK Rabotnicki≈ · ≈Rabotnicki Skopje≈
- **FK Renova** : (1) KF Renova
- **FK Shkëndija 79** : (2) Shkëndija · KF Shkëndija ⇒ (3) ≈Shkendija≈ · ≈KF Shkendija≈ · ≈FK Shkendija 79≈
- **FK Vardar** : (1) Vardar
- **FK Teteks**
- **FK Milano**
- **FK Pelister**
- **FC Shkupi 1927**
- **FK Sileks**
- **FK Turnovo**




Alphabet

- **Alphabet Specials** (2):  **ë**  **č** 
  - **ë**×3 U+00EB (235) - LATIN SMALL LETTER E WITH DIAERESIS ⇒ e
  - **č**×3 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c




Duplicates

- **FK Rabotnički**,  (2):
  - `rabotnicki` (2): **Rabotnicki** · **Rabotnicki**
  - `fkrabotnicki` (2): **FK Rabotnicki** · **FK Rabotnicki**




By City

- ? (12): 
  - FK Metalurg Skopje 
  - FK Makedonija Skopje 
  - FK Rabotnički  (4) Rabotnički · Rabotnicki · Rabotnički Skopje · FK Rabotnicki
  - FK Renova  (1) KF Renova
  - FK Shkëndija 79  (2) KF Shkëndija · Shkëndija
  - FK Vardar  (1) Vardar
  - FK Teteks 
  - FK Milano 
  - FK Pelister 
  - FC Shkupi 1927 
  - FK Sileks 
  - FK Turnovo 




By Region





By Year

- ? (12):   FK Metalurg Skopje · FK Makedonija Skopje · FK Rabotnički · FK Renova · FK Shkëndija 79 · FK Vardar · FK Teteks · FK Milano · FK Pelister · FC Shkupi 1927 · FK Sileks · FK Turnovo






By A to Z

- **F** (13): FK Milano · FK Renova · FK Sileks · FK Teteks · FK Vardar · FK Turnovo · FK Pelister · FK Rabotnicki · FK Rabotnički · FC Shkupi 1927 · FK Shkëndija 79 · FK Metalurg Skopje · FK Makedonija Skopje
- **K** (2): KF Renova · KF Shkëndija
- **R** (3): Rabotnicki · Rabotnički · Rabotnički Skopje
- **S** (1): Shkëndija
- **V** (1): Vardar




