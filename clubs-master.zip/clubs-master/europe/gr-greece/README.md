46 clubs

- **AEK Athens FC** : (2) AEK · AEK Athens
- **Panathinaikos FC** : (1) Panathinaikos
- **Apollon Smyrnis FC** : (1) Apollon
- **Atromitos FC** : (1) Atromitos
- **Panionios GSS** : (1) Panionios
- **APO Akratitos** : (1) Akratitos
- **Athinaikos AS FC** : (1) Athinaikos
- **Chalkidona FC** : (1) Chalkidona
- **Egaleo FC** : (1) Egaleo
- **Ethnikos Asteras FC** : (2) Eth Asteras · Ethnikos Asteras
- **Kallithea FC** : (2) Kalithea · Kallithea
- **Thrasyvoulos FC** : (1) Thrasyvoulos
- **Panelefsiniakos FC** : (1) Eleysina
- **Proodeftiki FC** : (2) Proodeftiki · Proodeytiki
- **Ionikos FC** : (1) Ionikos
- **Olympiacos Piraeus FC** : (5) Olympiakos · Olympiacos · Olympiakos P. · Olympiacos FC · Olympiakos Piräus ⇒ (2) ≈Olympiakos Piraus≈ · ≈Olympiakos Piraeus≈
- **Ethnikos Piraeus FC** : (2) Ethnikos · Ethnikos Piraeus
- **PAOK FC** : (1) PAOK
- **Aris Thessaloniki FC** : (1) Aris
- **Iraklis 1908 Thessaloniki FC** : (1) Iraklis
- **Apollon Pontou FC** : (1) Kalamaria
- **Asteras Tripolis FC** : (1) Asteras Tripolis
- **Xanthi FC** : (1) Xanthi
- **Panetolikos GFS** : (1) Panetolikos
- **PAS Giannina FC** : (2) Giannina · Yiannina
- **Levadiakos FC** : (2) Levadiakos · Levadeiakos
- **AE Larissa FC** : (3) Larisa · Larissa · Larissa FC
- **PAS Lamia 1964** : (1) Lamia
- **Kerkyra FC** : (1) Kerkyra
- **Platanias FC** : (1) Platanias
- **Doxa Dramas FC** : (2) Doxa · Doxa Dramas
- **Edessaikos FC** : (1) Edessaikos
- **Ergotelis FC** : (1) Ergotelis
- **OFI Crete FC** : (2) OFI · OFI Crete
- **Kalamata FC** : (1) Kalamata
- **AEL Kalloni FC** : (1) Kallonis
- **Kastoria FC** : (1) Kastoria
- **Kavala FC** : (1) Kavala
- **Niki Volou FC** : (1) Niki Volos
- **Olympiacos Volou 1937 FC** : (3) Olympiacos Volou · Olympiakos Volou · Olympiacos Volou FC
- **Panachaiki FC** : (1) Panahaiki
- **Paniliakos FC** : (1) Paniliakos
- **Panserraikos FC** : (1) Panserraikos
- **Panthrakikos FC** : (1) Panthrakikos
- **Trikala FC** : (1) Trikala
- **Veria FC** : (2) Veria · Veroia




Alphabet

- **Alphabet Specials** (1):  **ä** 
  - **ä**×1 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae




Duplicates





By City

- **Athens** (10): 
  - AEK Athens FC  (2) AEK · AEK Athens
  - Panathinaikos FC  (1) Panathinaikos
  - Apollon Smyrnis FC  (1) Apollon
  - Atromitos FC  (1) Atromitos
  - Panionios GSS  (1) Panionios
  - APO Akratitos  (1) Akratitos
  - Athinaikos AS FC  (1) Athinaikos
  - Chalkidona FC  (1) Chalkidona
  - Egaleo FC  (1) Egaleo
  - Ethnikos Asteras FC  (2) Ethnikos Asteras · Eth Asteras
- **Thessaloniki, Central Macedonia** (3): 
  - PAOK FC  (1) PAOK
  - Aris Thessaloniki FC  (1) Aris
  - Iraklis 1908 Thessaloniki FC  (1) Iraklis
- **Heraklion, Crete** (2): 
  - Ergotelis FC  (1) Ergotelis
  - OFI Crete FC  (2) OFI · OFI Crete
- **Nikaia, Attica** (2): 
  - Proodeftiki FC  (2) Proodeftiki · Proodeytiki
  - Ionikos FC  (1) Ionikos
- **Piraeus, Attica** (2): 
  - Olympiacos Piraeus FC  (5) Olympiakos · Olympiacos · Olympiakos Piräus · Olympiakos P. · Olympiacos FC
  - Ethnikos Piraeus FC  (2) Ethnikos Piraeus · Ethnikos
- **Volos, Thessaly** (2): 
  - Niki Volou FC  (1) Niki Volos
  - Olympiacos Volou 1937 FC  (3) Olympiacos Volou · Olympiacos Volou FC · Olympiakos Volou
- **Agrinio, West Greece** (1): Panetolikos GFS  (1) Panetolikos
- **Chania, Crete** (1): Platanias FC  (1) Platanias
- **Corfu, Ionian Islands** (1): Kerkyra FC  (1) Kerkyra
- **Drama, Macedonia** (1): Doxa Dramas FC  (2) Doxa · Doxa Dramas
- **Edessa, Macedonia** (1): Edessaikos FC  (1) Edessaikos
- **Elefsina, Attica** (1): Panelefsiniakos FC  (1) Eleysina
- **Fyli** (1): Thrasyvoulos FC  (1) Thrasyvoulos
- **Ioannina, Epirus** (1): PAS Giannina FC  (2) Giannina · Yiannina
- **Kalamaria, Central Macedonia** (1): Apollon Pontou FC  (1) Kalamaria
- **Kalamata, Peloponnese** (1): Kalamata FC  (1) Kalamata
- **Kallithea** (1): Kallithea FC  (2) Kalithea · Kallithea
- **Kalloni, Aegean Islands** (1): AEL Kalloni FC  (1) Kallonis
- **Kastoria, Macedonia** (1): Kastoria FC  (1) Kastoria
- **Kavala, Macedonia** (1): Kavala FC  (1) Kavala
- **Komotini, Thrace** (1): Panthrakikos FC  (1) Panthrakikos
- **Lamia, Central Greece** (1): PAS Lamia 1964  (1) Lamia
- **Larissa, Thessaly** (1): AE Larissa FC  (3) Larissa · Larissa FC · Larisa
- **Livadeia, Central Greece** (1): Levadiakos FC  (2) Levadeiakos · Levadiakos
- **Patras, Peloponnese** (1): Panachaiki FC  (1) Panahaiki
- **Pyrgos, Peloponnese** (1): Paniliakos FC  (1) Paniliakos
- **Serres, Macedonia** (1): Panserraikos FC  (1) Panserraikos
- **Trikala, Thessaly** (1): Trikala FC  (1) Trikala
- **Tripoli, Peloponnese** (1): Asteras Tripolis FC  (1) Asteras Tripolis
- **Veria, Macedonia** (1): Veria FC  (2) Veria · Veroia
- **Xanthi, Thrace** (1): Xanthi FC  (1) Xanthi




By Region

- **Athens†** (10):   AEK Athens FC · Panathinaikos FC · Apollon Smyrnis FC · Atromitos FC · Panionios GSS · APO Akratitos · Athinaikos AS FC · Chalkidona FC · Egaleo FC · Ethnikos Asteras FC
- **Kallithea†** (1):   Kallithea FC
- **Fyli†** (1):   Thrasyvoulos FC
- **Attica** (5):   Panelefsiniakos FC · Proodeftiki FC · Ionikos FC · Olympiacos Piraeus FC · Ethnikos Piraeus FC
- **Central Macedonia** (4):   PAOK FC · Aris Thessaloniki FC · Iraklis 1908 Thessaloniki FC · Apollon Pontou FC
- **Peloponnese** (4):   Asteras Tripolis FC · Kalamata FC · Panachaiki FC · Paniliakos FC
- **Thrace** (2):   Xanthi FC · Panthrakikos FC
- **West Greece** (1):   Panetolikos GFS
- **Epirus** (1):   PAS Giannina FC
- **Central Greece** (2):   Levadiakos FC · PAS Lamia 1964
- **Thessaly** (4):   AE Larissa FC · Niki Volou FC · Olympiacos Volou 1937 FC · Trikala FC
- **Ionian Islands** (1):   Kerkyra FC
- **Crete** (3):   Platanias FC · Ergotelis FC · OFI Crete FC
- **Macedonia** (6):   Doxa Dramas FC · Edessaikos FC · Kastoria FC · Kavala FC · Panserraikos FC · Veria FC
- **Aegean Islands** (1):   AEL Kalloni FC




By Year

- ? (46):   AEK Athens FC · Panathinaikos FC · Apollon Smyrnis FC · Atromitos FC · Panionios GSS · APO Akratitos · Athinaikos AS FC · Chalkidona FC · Egaleo FC · Ethnikos Asteras FC · Kallithea FC · Thrasyvoulos FC · Panelefsiniakos FC · Proodeftiki FC · Ionikos FC · Olympiacos Piraeus FC · Ethnikos Piraeus FC · PAOK FC · Aris Thessaloniki FC · Iraklis 1908 Thessaloniki FC · Apollon Pontou FC · Asteras Tripolis FC · Xanthi FC · Panetolikos GFS · PAS Giannina FC · Levadiakos FC · AE Larissa FC · PAS Lamia 1964 · Kerkyra FC · Platanias FC · Doxa Dramas FC · Edessaikos FC · Ergotelis FC · OFI Crete FC · Kalamata FC · AEL Kalloni FC · Kastoria FC · Kavala FC · Niki Volou FC · Olympiacos Volou 1937 FC · Panachaiki FC · Paniliakos FC · Panserraikos FC · Panthrakikos FC · Trikala FC · Veria FC






By A to Z

- **A** (18): AEK · Aris · Apollon · Akratitos · Atromitos · AEK Athens · Athinaikos · Atromitos FC · AE Larissa FC · AEK Athens FC · APO Akratitos · AEL Kalloni FC · Asteras Tripolis · Athinaikos AS FC · Apollon Pontou FC · Apollon Smyrnis FC · Asteras Tripolis FC · Aris Thessaloniki FC
- **C** (2): Chalkidona · Chalkidona FC
- **D** (3): Doxa · Doxa Dramas · Doxa Dramas FC
- **E** (13): Egaleo · Eleysina · Ethnikos · Egaleo FC · Ergotelis · Edessaikos · Eth Asteras · Ergotelis FC · Edessaikos FC · Ethnikos Asteras · Ethnikos Piraeus · Ethnikos Asteras FC · Ethnikos Piraeus FC
- **G** (1): Giannina
- **I** (4): Ionikos · Iraklis · Ionikos FC · Iraklis 1908 Thessaloniki FC
- **K** (13): Kavala · Kerkyra · Kalamata · Kalithea · Kallonis · Kastoria · Kalamaria · Kallithea · Kavala FC · Kerkyra FC · Kalamata FC · Kastoria FC · Kallithea FC
- **L** (7): Lamia · Larisa · Larissa · Larissa FC · Levadiakos · Levadeiakos · Levadiakos FC
- **N** (2): Niki Volos · Niki Volou FC
- **O** (13): OFI · OFI Crete · Olympiacos · Olympiakos · OFI Crete FC · Olympiacos FC · Olympiakos P. · Olympiacos Volou · Olympiakos Volou · Olympiakos Piräus · Olympiacos Volou FC · Olympiacos Piraeus FC · Olympiacos Volou 1937 FC
- **P** (24): PAOK · PAOK FC · Panahaiki · Panionios · Platanias · Paniliakos · Panetolikos · Proodeftiki · Proodeytiki · Panserraikos · Panthrakikos · Platanias FC · Panachaiki FC · Panathinaikos · Paniliakos FC · Panionios GSS · PAS Lamia 1964 · Proodeftiki FC · PAS Giannina FC · Panetolikos GFS · Panserraikos FC · Panthrakikos FC · Panathinaikos FC · Panelefsiniakos FC
- **T** (4): Trikala · Trikala FC · Thrasyvoulos · Thrasyvoulos FC
- **V** (3): Veria · Veroia · Veria FC
- **X** (2): Xanthi · Xanthi FC
- **Y** (1): Yiannina




