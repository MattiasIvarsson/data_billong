11 clubs

- **FK Ventspils** : (1) Ventspils
- **SK Liepājas Metalurgs** ⇒ (1) ≈SK Liepajas Metalurgs≈
- **Skonto FC** : (1) Skonto
- **FC Daugava Daugavpils**
- **FK Jelgava**
- **FC Dinaburg**
- **JFK Olimps/RFS**
- **FK Spartaks Jūrmala** : (1) Spartaks Jūrmala ⇒ (2) ≈Spartaks Jurmala≈ · ≈FK Spartaks Jurmala≈
- **FK Liepāja** ⇒ (1) ≈FK Liepaja≈
- **Riga FC**
- **FC Daugava Rīga** ⇒ (1) ≈FC Daugava Riga≈




Alphabet

- **Alphabet Specials** (3):  **ā**  **ī**  **ū** 
  - **ā**×2 U+0101 (257) - LATIN SMALL LETTER A WITH MACRON ⇒ a
  - **ī**×1 U+012B (299) - LATIN SMALL LETTER I WITH MACRON ⇒ i
  - **ū**×2 U+016B (363) - LATIN SMALL LETTER U WITH MACRON ⇒ u




Duplicates





By City

- ? (11): 
  - FK Ventspils  (1) Ventspils
  - SK Liepājas Metalurgs 
  - Skonto FC  (1) Skonto
  - FC Daugava Daugavpils 
  - FK Jelgava 
  - FC Dinaburg 
  - JFK Olimps/RFS 
  - FK Spartaks Jūrmala  (1) Spartaks Jūrmala
  - FK Liepāja 
  - Riga FC 
  - FC Daugava Rīga 




By Region





By Year

- ? (11):   FK Ventspils · SK Liepājas Metalurgs · Skonto FC · FC Daugava Daugavpils · FK Jelgava · FC Dinaburg · JFK Olimps/RFS · FK Spartaks Jūrmala · FK Liepāja · Riga FC · FC Daugava Rīga






By A to Z

- **F** (7): FK Jelgava · FK Liepāja · FC Dinaburg · FK Ventspils · FC Daugava Rīga · FK Spartaks Jūrmala · FC Daugava Daugavpils
- **J** (1): JFK Olimps/RFS
- **R** (1): Riga FC
- **S** (4): Skonto · Skonto FC · Spartaks Jūrmala · SK Liepājas Metalurgs
- **V** (1): Ventspils




