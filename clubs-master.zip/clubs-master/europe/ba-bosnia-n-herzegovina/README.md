10 clubs

- **FK Sarajevo**
- **FK Slavija Sarajevo** : (1) Slavija
- **FK Olimpic Sarajevo** : (1) Olimpic Sarajevo
- **FK Željezničar** : (1) Željezničar ⇒ (2) ≈Zeljeznicar≈ · ≈FK Zeljeznicar≈
- **HŠK Zrinjski** : (2) Zrinjski · Zrinjski Mostar ⇒ (1) ≈HSK Zrinjski≈
- **NK Široki Brijeg** : (1) Široki Brijeg ⇒ (2) ≈Siroki Brijeg≈ · ≈NK Siroki Brijeg≈
- **FK Borac Banja Luka** : (1) Borac
- **FK Modriča** ⇒ (1) ≈FK Modrica≈
- **FK Sloboda Tuzla** : (1) Sloboda
- **FK Radnik Bijeljina** : (1) Radnik Bijeljina




Alphabet

- **Alphabet Specials** (3):  **č**  **Š**  **Ž** 
  - **č**×3 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **Š**×3 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **Ž**×2 U+017D (381) - LATIN CAPITAL LETTER Z WITH CARON ⇒ Z




Duplicates





By City

- ? (10): 
  - FK Sarajevo 
  - FK Slavija Sarajevo  (1) Slavija
  - FK Olimpic Sarajevo  (1) Olimpic Sarajevo
  - FK Željezničar  (1) Željezničar
  - HŠK Zrinjski  (2) Zrinjski · Zrinjski Mostar
  - NK Široki Brijeg  (1) Široki Brijeg
  - FK Borac Banja Luka  (1) Borac
  - FK Modriča 
  - FK Sloboda Tuzla  (1) Sloboda
  - FK Radnik Bijeljina  (1) Radnik Bijeljina




By Region





By Year

- ? (10):   FK Sarajevo · FK Slavija Sarajevo · FK Olimpic Sarajevo · FK Željezničar · HŠK Zrinjski · NK Široki Brijeg · FK Borac Banja Luka · FK Modriča · FK Sloboda Tuzla · FK Radnik Bijeljina






By A to Z

- **B** (1): Borac
- **F** (8): FK Modriča · FK Sarajevo · FK Željezničar · FK Sloboda Tuzla · FK Borac Banja Luka · FK Olimpic Sarajevo · FK Radnik Bijeljina · FK Slavija Sarajevo
- **H** (1): HŠK Zrinjski
- **N** (1): NK Široki Brijeg
- **O** (1): Olimpic Sarajevo
- **R** (1): Radnik Bijeljina
- **S** (2): Slavija · Sloboda
- **Z** (2): Zrinjski · Zrinjski Mostar
- **Š** (1): Široki Brijeg
- **Ž** (1): Željezničar




