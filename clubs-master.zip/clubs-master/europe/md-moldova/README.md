11 clubs

- **FC Sheriff Tiraspol** : (5) Sheriff · Tiraspol · FC Sheriff · FC Tiraspol · Sheriff Tiraspol
- **FC Dacia Chisinau** : (1) Dacia
- **FC Zimbru Chisinau** : (1) Zimbru
- **FC Iskra-Stal** : (1) Iskra-Stal
- **FC Milsami Orhei** : (1) Milsami
- **FC Olimpia Balti**
- **FC Zaria Balti** : (2) Zaria · Zaria Balti
- **FC Nistru Otaci**
- **CS Petrocub** : (1) Petrocub
- **FC Saxan** : (1) Saxan
- **FC Veris** : (1) Veris




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Tiraspol** (1): FC Sheriff Tiraspol  (5) Sheriff · FC Sheriff · Sheriff Tiraspol · FC Tiraspol · Tiraspol
- ? (10): 
  - FC Dacia Chisinau  (1) Dacia
  - FC Zimbru Chisinau  (1) Zimbru
  - FC Iskra-Stal  (1) Iskra-Stal
  - FC Milsami Orhei  (1) Milsami
  - FC Olimpia Balti 
  - FC Zaria Balti  (2) Zaria · Zaria Balti
  - FC Nistru Otaci 
  - CS Petrocub  (1) Petrocub
  - FC Saxan  (1) Saxan
  - FC Veris  (1) Veris




By Region

- **Tiraspol†** (1):   FC Sheriff Tiraspol




By Year

- ? (11):   FC Sheriff Tiraspol · FC Dacia Chisinau · FC Zimbru Chisinau · FC Iskra-Stal · FC Milsami Orhei · FC Olimpia Balti · FC Zaria Balti · FC Nistru Otaci · CS Petrocub · FC Saxan · FC Veris






By A to Z

- **C** (1): CS Petrocub
- **D** (1): Dacia
- **F** (12): FC Saxan · FC Veris · FC Sheriff · FC Tiraspol · FC Iskra-Stal · FC Zaria Balti · FC Nistru Otaci · FC Milsami Orhei · FC Olimpia Balti · FC Dacia Chisinau · FC Zimbru Chisinau · FC Sheriff Tiraspol
- **I** (1): Iskra-Stal
- **M** (1): Milsami
- **P** (1): Petrocub
- **S** (3): Saxan · Sheriff · Sheriff Tiraspol
- **T** (1): Tiraspol
- **V** (1): Veris
- **Z** (3): Zaria · Zimbru · Zaria Balti




