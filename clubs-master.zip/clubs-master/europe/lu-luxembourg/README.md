8 clubs

- **Jeunesse d'Esch** : (2) Jeunesse Esch · AS Jeunesse Esch
- **F91 Dudelange** : (1) Dudelange
- **FC Differdange 03** : (1) Differdange
- **CS Grevenmacher**
- **UN Käerjéng 97** ⇒ (2) ≈UN Kaerjeng 97≈ · ≈UN Kaeerjéng 97≈
- **CS Fola Esch** : (1) Fola
- **Racing FC Union Lëtzebuerg** ⇒ (1) ≈Racing FC Union Letzebuerg≈
- **FC Progrès Niederkorn** ⇒ (1) ≈FC Progres Niederkorn≈




Alphabet

- **Alphabet Specials** (4):  **ä**  **è**  **é**  **ë** 
  - **ä**×1 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **è**×1 U+00E8 (232) - LATIN SMALL LETTER E WITH GRAVE ⇒ e
  - **é**×1 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ë**×1 U+00EB (235) - LATIN SMALL LETTER E WITH DIAERESIS ⇒ e




Duplicates





By City

- **Dudelange** (1): F91 Dudelange  (1) Dudelange
- **Esch-sur-Alzette** (1): Jeunesse d'Esch  (2) Jeunesse Esch · AS Jeunesse Esch
- ? (6): 
  - FC Differdange 03  (1) Differdange
  - CS Grevenmacher 
  - UN Käerjéng 97 
  - CS Fola Esch  (1) Fola
  - Racing FC Union Lëtzebuerg 
  - FC Progrès Niederkorn 




By Region

- **Esch-sur-Alzette†** (1):   Jeunesse d'Esch
- **Dudelange†** (1):   F91 Dudelange




By Year

- ? (8):   Jeunesse d'Esch · F91 Dudelange · FC Differdange 03 · CS Grevenmacher · UN Käerjéng 97 · CS Fola Esch · Racing FC Union Lëtzebuerg · FC Progrès Niederkorn






By A to Z

- **A** (1): AS Jeunesse Esch
- **C** (2): CS Fola Esch · CS Grevenmacher
- **D** (2): Dudelange · Differdange
- **F** (4): Fola · F91 Dudelange · FC Differdange 03 · FC Progrès Niederkorn
- **J** (2): Jeunesse Esch · Jeunesse d'Esch
- **R** (1): Racing FC Union Lëtzebuerg
- **U** (1): UN Käerjéng 97




