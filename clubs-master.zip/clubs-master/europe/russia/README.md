42 clubs

- [**Lokomotiv Moskva**](https://en.wikipedia.org/wiki/FC_Lokomotiv_Moscow) : (5) Lokomotiv · FC Lokomotiv · FC Lokomotiv Moskva · Lokomotiv Moscow [en] · FC Lokomotiv Moscow [en]
- [**PFC CSKA Moskva**](https://en.wikipedia.org/wiki/PFC_CSKA_Moscow) : (6) CSKA · PFK CSCA · CSKA Moskva · CSKA Moscow [en] · PFC CSKA Moscow [en] · PFK CSKA Moscow [en]
- [**Dynamo Moskva**](https://en.wikipedia.org/wiki/FC_Dynamo_Moscow) : (7) Dynamo · Dinamo · Dinamo Moskva · FC Dinamo Moskva · Dynamo Moscow [en] · Dinamo Moscow [en] · FC Dynamo Moscow [en]
- [**FC Spartak Moskva**](https://en.wikipedia.org/wiki/FC_Spartak_Moscow) : (6) Spartak · FC Spartak · Spartak Moskva · Spartak Moscow [en] · Spartak Moskau [de] · FC Spartak Moscow [en]
- [**FC Moskva**](https://en.wikipedia.org/wiki/FC_Moscow) : (2) Moskva · FC Moscow [en]
- [**Torpedo Moskva**](https://en.wikipedia.org/wiki/FC_Torpedo_Moscow) : (4) Torpedo · T. Moscow [en] · Torpedo Moscow [en] · FC Torpedo Moscow [en]
- [**Zenit St. Petersburg**](https://en.wikipedia.org/wiki/FC_Zenit_Saint_Petersburg) : (7) Zenit · FC Zenit · Zenit Petersb. · Zenit Petersburg · FC Zenit St Petersburg · Zenit Saint Petersburg · FC Zenit Saint Petersburg
- **PFC Sochi** : (2) Sochi · Professional Football Club Sochi
- [**FC Rubin Kazan**](https://en.wikipedia.org/wiki/FC_Rubin_Kazan) : (3) Rubin · FC Rubin · Rubin Kazan
- [**FC Amkar Perm**](https://en.wikipedia.org/wiki/FC_Amkar_Perm) : (2) Amkar · Amkar Perm
- [**FC Anzhi Makhachkala**](https://en.wikipedia.org/wiki/FC_Anzhi_Makhachkala) : (4) Anji · Anzhi · Anzhi Makhachkala · FK Anzi Makhackala
- [**FC Sibir Novosibirsk**](https://en.wikipedia.org/wiki/FC_Sibir_Novosibirsk) : (3) Sibir · Sibir' · FC Sibir
- [**FC Alania Vladikavkaz**](https://en.wikipedia.org/wiki/FC_Alania_Vladikavkaz) : (2) Alania · Alania Vladikavkaz
- [**PFC Krylya Sovetov Samara**](https://en.wikipedia.org/wiki/PFC_Krylia_Sovetov_Samara) : (6) Krylya Sovetov · Krylia Sovetov · Kryl'ia Sovetov · Krylia Sovetov Samara · FK Krylya Sovetov Samara · PFC Krylia Sovetov Samara
- [**Arsenal Tula**](https://en.wikipedia.org/wiki/FC_Arsenal_Tula) : (2) Arsenal · FC Arsenal Tula
- [**Chernomorets Novorosisk**](https://en.wikipedia.org/wiki/FC_Chernomorets_Novorossiysk) : (2) Chernomorets · FC Chernomorets Novorossiysk
- **FC Khimki** : (1) Khimki
- [**FC Krasnodar**](https://en.wikipedia.org/wiki/FC_Krasnodar) : (2) Krasnodar · Krasnodar Krasnodar
- [**FC Kuban**](https://en.wikipedia.org/wiki/FC_Kuban_Krasnodar) : (4) Kuban · Kuban' · Kuban Krasnodar · FC Kuban Krasnodar
- **Luch Energia Vladivostok** : (1) Luch
- **FC Mordovia** : (3) Mordovia · M. Saransk · Mordovia Saransk
- **Spartak Nalchik** : (1) Nalchik
- **Nizhnii Novgorod** : (1) Nizhny Novgorod
- [**FC Rostov**](https://en.wikipedia.org/wiki/FC_Rostov) : (3) Rostov · FK Rostov · Rostov Rostov-on-Don
- **Rotor**
- **Saturn**
- **Shinnik**
- **SKA-Energiia** : (2) SKA Energia · SKA Khabarovsk
- **Sokol**
- [**Terek Grozny**](https://en.wikipedia.org/wiki/FC_Terek_Grozny) : (2) Terek · FC Terek Grozny
- [**Akhmat Grozny**](https://en.wikipedia.org/wiki/FC_Akhmat_Grozny) : (1) FC Akhmat Grozny
- [**Tom Tomsk**](https://en.wikipedia.org/wiki/FC_Tom_Tomsk) : (4) Tom · Tom' · Tomsk · FC Tom Tomsk
- **Tosno**
- [**FC Ufa**](https://en.wikipedia.org/wiki/FC_Ufa) : (2) Ufa · Ufa Ufa
- [**Ural Yekaterinburg**](https://en.wikipedia.org/wiki/FC_Ural_Yekaterinburg) : (3) Ural · FC Ural Yekaterinburg · Football Club Ural Sverdlovsk Oblast
- **Uralan**
- **Volga Nizhnii Novgorod** : (2) Volga · Volga N. Novgorod
- **FC Tambov** : (1) Tambov
- [**FC Orenburg**](https://en.wikipedia.org/wiki/FC_Orenburg) : (1) Orenburg
- **Volgar-Astrakhan**
- **Vladikavkaz**
- [**Yenisey**](https://en.wikipedia.org/wiki/FC_Yenisey_Krasnoyarsk) : (1) FC Yenisey Krasnoyarsk




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **FC Sibir Novosibirsk**, Novosibirsk (1):
  - `sibir` (2): Sibir' · Sibir
- **PFC Krylya Sovetov Samara**, Samara (1):
  - `kryliasovetov` (2): Krylia Sovetov · Kryl'ia Sovetov
- **FC Kuban**, Krasnodar (1):
  - `kuban` (2): Kuban · Kuban'
- **Tom Tomsk**, Tomsk (1):
  - `tom` (2): Tom · Tom'




By City

- **Moskva** (6): 
  - Lokomotiv Moskva  (5) Lokomotiv · FC Lokomotiv · FC Lokomotiv Moskva · Lokomotiv Moscow [en] · FC Lokomotiv Moscow [en]
  - PFC CSKA Moskva  (6) CSKA · PFK CSCA · CSKA Moskva · CSKA Moscow [en] · PFC CSKA Moscow [en] · PFK CSKA Moscow [en]
  - Dynamo Moskva  (7) Dynamo · Dinamo · Dinamo Moskva · FC Dinamo Moskva · Dynamo Moscow [en] · Dinamo Moscow [en] · FC Dynamo Moscow [en]
  - FC Spartak Moskva  (6) Spartak · FC Spartak · Spartak Moskva · Spartak Moscow [en] · FC Spartak Moscow [en] · Spartak Moskau [de]
  - FC Moskva  (2) Moskva · FC Moscow [en]
  - Torpedo Moskva  (4) Torpedo · T. Moscow [en] · Torpedo Moscow [en] · FC Torpedo Moscow [en]
- **Grozny** (2): 
  - Terek Grozny  (2) Terek · FC Terek Grozny
  - Akhmat Grozny  (1) FC Akhmat Grozny
- **Krasnodar** (2): 
  - FC Krasnodar  (2) Krasnodar · Krasnodar Krasnodar
  - FC Kuban  (4) Kuban · Kuban' · Kuban Krasnodar · FC Kuban Krasnodar
- **Nizhny Novgorod** (2): 
  - Nizhnii Novgorod  (1) Nizhny Novgorod
  - Volga Nizhnii Novgorod  (2) Volga · Volga N. Novgorod
- **Astrakhan** (1): Volgar-Astrakhan 
- **Elista** (1): Uralan 
- **Kazan** (1): FC Rubin Kazan  (3) Rubin · FC Rubin · Rubin Kazan
- **Khabarovsk** (1): SKA-Energiia  (2) SKA Energia · SKA Khabarovsk
- **Khimki** (1): FC Khimki  (1) Khimki
- **Krasnoyarsk** (1): Yenisey  (1) FC Yenisey Krasnoyarsk
- **Makhachkala** (1): FC Anzhi Makhachkala  (4) Anzhi · Anji · Anzhi Makhachkala · FK Anzi Makhackala
- **Nalchik** (1): Spartak Nalchik  (1) Nalchik
- **Novorosisk** (1): Chernomorets Novorosisk  (2) Chernomorets · FC Chernomorets Novorossiysk
- **Novosibirsk** (1): FC Sibir Novosibirsk  (3) Sibir' · Sibir · FC Sibir
- **Orenburg** (1): FC Orenburg  (1) Orenburg
- **Perm** (1): FC Amkar Perm  (2) Amkar · Amkar Perm
- **Ramenskoe** (1): Saturn 
- **Rostov-on-Don** (1): FC Rostov  (3) Rostov · Rostov Rostov-on-Don · FK Rostov
- **Samara** (1): PFC Krylya Sovetov Samara  (6) Krylya Sovetov · FK Krylya Sovetov Samara · Krylia Sovetov · Kryl'ia Sovetov · Krylia Sovetov Samara · PFC Krylia Sovetov Samara
- **Saransk** (1): FC Mordovia  (3) Mordovia · Mordovia Saransk · M. Saransk
- **Saratov** (1): Sokol 
- **Sochi** (1): PFC Sochi  (2) Sochi · Professional Football Club Sochi
- **St. Petersburg** (1): Zenit St. Petersburg  (7) Zenit · Zenit Petersb. · Zenit Petersburg · Zenit Saint Petersburg · FC Zenit · FC Zenit St Petersburg · FC Zenit Saint Petersburg
- **Tambov** (1): FC Tambov  (1) Tambov
- **Tomsk** (1): Tom Tomsk  (4) Tom · Tom' · Tomsk · FC Tom Tomsk
- **Tosno** (1): Tosno 
- **Tula** (1): Arsenal Tula  (2) Arsenal · FC Arsenal Tula
- **Ufa** (1): FC Ufa  (2) Ufa · Ufa Ufa
- **Vladikavkaz** (1): Vladikavkaz 
- **Vladikovkaz** (1): FC Alania Vladikavkaz  (2) Alania · Alania Vladikavkaz
- **Vladivostok** (1): Luch Energia Vladivostok  (1) Luch
- **Volgograd** (1): Rotor 
- **Yaroslavl** (1): Shinnik 
- **Yekaterinburg** (1): Ural Yekaterinburg  (3) Ural · FC Ural Yekaterinburg · Football Club Ural Sverdlovsk Oblast




By Region

- **Moskva†** (6):   Lokomotiv Moskva · PFC CSKA Moskva · Dynamo Moskva · FC Spartak Moskva · FC Moskva · Torpedo Moskva
- **St. Petersburg†** (1):   Zenit St. Petersburg
- **Sochi†** (1):   PFC Sochi
- **Kazan†** (1):   FC Rubin Kazan
- **Perm†** (1):   FC Amkar Perm
- **Makhachkala†** (1):   FC Anzhi Makhachkala
- **Novosibirsk†** (1):   FC Sibir Novosibirsk
- **Vladikovkaz†** (1):   FC Alania Vladikavkaz
- **Samara†** (1):   PFC Krylya Sovetov Samara
- **Tula†** (1):   Arsenal Tula
- **Novorosisk†** (1):   Chernomorets Novorosisk
- **Khimki†** (1):   FC Khimki
- **Krasnodar†** (2):   FC Krasnodar · FC Kuban
- **Vladivostok†** (1):   Luch Energia Vladivostok
- **Saransk†** (1):   FC Mordovia
- **Nalchik†** (1):   Spartak Nalchik
- **Nizhny Novgorod†** (2):   Nizhnii Novgorod · Volga Nizhnii Novgorod
- **Rostov-on-Don†** (1):   FC Rostov
- **Volgograd†** (1):   Rotor
- **Ramenskoe†** (1):   Saturn
- **Yaroslavl†** (1):   Shinnik
- **Khabarovsk†** (1):   SKA-Energiia
- **Saratov†** (1):   Sokol
- **Grozny†** (2):   Terek Grozny · Akhmat Grozny
- **Tomsk†** (1):   Tom Tomsk
- **Tosno†** (1):   Tosno
- **Ufa†** (1):   FC Ufa
- **Yekaterinburg†** (1):   Ural Yekaterinburg
- **Elista†** (1):   Uralan
- **Tambov†** (1):   FC Tambov
- **Orenburg†** (1):   FC Orenburg
- **Astrakhan†** (1):   Volgar-Astrakhan
- **Vladikavkaz†** (1):   Vladikavkaz
- **Krasnoyarsk†** (1):   Yenisey




By Year

- **1911** (1):   PFC CSKA Moskva
- **1922** (1):   FC Spartak Moskva
- **1923** (2):   Lokomotiv Moskva · Dynamo Moskva
- **1925** (1):   Zenit St. Petersburg
- **1958** (1):   FC Rubin Kazan
- **1991** (1):   FC Anzhi Makhachkala
- **1994** (1):   FC Amkar Perm
- **2013** (1):   FC Tambov
- **2018** (1):   PFC Sochi
- ? (32):   FC Moskva · Torpedo Moskva · FC Sibir Novosibirsk · FC Alania Vladikavkaz · PFC Krylya Sovetov Samara · Arsenal Tula · Chernomorets Novorosisk · FC Khimki · FC Krasnodar · FC Kuban · Luch Energia Vladivostok · FC Mordovia · Spartak Nalchik · Nizhnii Novgorod · FC Rostov · Rotor · Saturn · Shinnik · SKA-Energiia · Sokol · Terek Grozny · Akhmat Grozny · Tom Tomsk · Tosno · FC Ufa · Ural Yekaterinburg · Uralan · Volga Nizhnii Novgorod · FC Orenburg · Volgar-Astrakhan · Vladikavkaz · Yenisey






By A to Z

- **A** (10): Anji · Amkar · Anzhi · Alania · Arsenal · Amkar Perm · Arsenal Tula · Akhmat Grozny · Anzhi Makhachkala · Alania Vladikavkaz
- **C** (5): CSKA · CSKA Moskva · Chernomorets · CSKA Moscow [en] · Chernomorets Novorosisk
- **D** (6): Dinamo · Dynamo · Dinamo Moskva · Dynamo Moskva · Dinamo Moscow [en] · Dynamo Moscow [en]
- **F** (41): FC Ufa · FC Kuban · FC Rubin · FC Sibir · FC Zenit · FC Khimki · FC Moskva · FC Rostov · FC Tambov · FK Rostov · FC Spartak · FC Mordovia · FC Orenburg · FC Krasnodar · FC Lokomotiv · FC Tom Tomsk · FC Amkar Perm · FC Moscow [en] · FC Rubin Kazan · FC Arsenal Tula · FC Terek Grozny · FC Akhmat Grozny · FC Dinamo Moskva · FC Spartak Moskva · FC Kuban Krasnodar · FK Anzi Makhackala · FC Lokomotiv Moskva · FC Anzhi Makhachkala · FC Sibir Novosibirsk · FC Alania Vladikavkaz · FC Dynamo Moscow [en] · FC Ural Yekaterinburg · FC Spartak Moscow [en] · FC Torpedo Moscow [en] · FC Yenisey Krasnoyarsk · FC Zenit St Petersburg · FC Lokomotiv Moscow [en] · FK Krylya Sovetov Samara · FC Zenit Saint Petersburg · FC Chernomorets Novorossiysk · Football Club Ural Sverdlovsk Oblast
- **K** (10): Kuban · Khimki · Kuban' · Krasnodar · Krylia Sovetov · Krylya Sovetov · Kryl'ia Sovetov · Kuban Krasnodar · Krasnodar Krasnodar · Krylia Sovetov Samara
- **L** (5): Luch · Lokomotiv · Lokomotiv Moskva · Lokomotiv Moscow [en] · Luch Energia Vladivostok
- **M** (4): Moskva · Mordovia · M. Saransk · Mordovia Saransk
- **N** (3): Nalchik · Nizhny Novgorod · Nizhnii Novgorod
- **O** (1): Orenburg
- **P** (8): PFK CSCA · PFC Sochi · PFC CSKA Moskva · PFC CSKA Moscow [en] · PFK CSKA Moscow [en] · PFC Krylia Sovetov Samara · PFC Krylya Sovetov Samara · Professional Football Club Sochi
- **R** (5): Rotor · Rubin · Rostov · Rubin Kazan · Rostov Rostov-on-Don
- **S** (14): Sibir · Sochi · Sokol · Saturn · Sibir' · Shinnik · Spartak · SKA Energia · SKA-Energiia · SKA Khabarovsk · Spartak Moskva · Spartak Nalchik · Spartak Moscow [en] · Spartak Moskau [de]
- **T** (12): Tom · Tom' · Terek · Tomsk · Tosno · Tambov · Torpedo · Tom Tomsk · Terek Grozny · T. Moscow [en] · Torpedo Moskva · Torpedo Moscow [en]
- **U** (5): Ufa · Ural · Uralan · Ufa Ufa · Ural Yekaterinburg
- **V** (5): Volga · Vladikavkaz · Volgar-Astrakhan · Volga N. Novgorod · Volga Nizhnii Novgorod
- **Y** (1): Yenisey
- **Z** (5): Zenit · Zenit Petersb. · Zenit Petersburg · Zenit St. Petersburg · Zenit Saint Petersburg




