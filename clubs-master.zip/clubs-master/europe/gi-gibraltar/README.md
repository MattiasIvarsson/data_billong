8 clubs

- **Lincoln FC** : (2) Lincoln Red Imps · Lincoln Red Imps FC
- **Manchester 62 FC**
- **Lynx FC**
- **College Europa FC** : (1) Europa FC
- **Glacis United FC**
- **Lions Gibraltar FC**
- **St Joseph's FRAC** : (1) St Joseph's FC
- **Gibraltar Phoenix FC**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- ? (8): 
  - Lincoln FC  (2) Lincoln Red Imps FC · Lincoln Red Imps
  - Manchester 62 FC 
  - Lynx FC 
  - College Europa FC  (1) Europa FC
  - Glacis United FC 
  - Lions Gibraltar FC 
  - St Joseph's FRAC  (1) St Joseph's FC
  - Gibraltar Phoenix FC 




By Region





By Year

- ? (8):   Lincoln FC · Manchester 62 FC · Lynx FC · College Europa FC · Glacis United FC · Lions Gibraltar FC · St Joseph's FRAC · Gibraltar Phoenix FC






By A to Z

- **C** (1): College Europa FC
- **E** (1): Europa FC
- **G** (2): Glacis United FC · Gibraltar Phoenix FC
- **L** (5): Lynx FC · Lincoln FC · Lincoln Red Imps · Lions Gibraltar FC · Lincoln Red Imps FC
- **M** (1): Manchester 62 FC
- **S** (2): St Joseph's FC · St Joseph's FRAC




