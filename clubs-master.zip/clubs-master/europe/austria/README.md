18 clubs

- [**FK Austria Wien**](https://en.wikipedia.org/wiki/FK_Austria_Wien) : (2) Austria Wien · Austria Vienna [en]
- [**SK Rapid Wien**](https://en.wikipedia.org/wiki/SK_Rapid_Wien) : (2) Rapid Wien · Rapid Vienna [en]
- **Wiener Sport-Club**
- [**SV Mattersburg**](https://en.wikipedia.org/wiki/SV_Mattersburg) : (1) Mattersburg
- [**FC Admira Wacker Mödling**](https://en.wikipedia.org/wiki/FC_Admira_Wacker_Mödling) : (2) Admira · Admira Wien ⇒ (2) ≈FC Admira Wacker Modling≈ · ≈FC Admira Wacker Moedling≈
- **SC Wiener Neustadt** : (1) Neustadt
- [**SKN St. Pölten**](https://en.wikipedia.org/wiki/SKN_St._Pölten) : (1) St. Pölten ⇒ (4) ≈St. Polten≈ · ≈St. Poelten≈ · ≈SKN St. Polten≈ · ≈SKN St. Poelten≈
- [**LASK Linz**](https://en.wikipedia.org/wiki/LASK_Linz) : (2) LASK · Linzer ASK
- **FC Stahl Linz** : (1) SK VOEST Linz
- **SV Ried** : (1) Ried
- [**SK Sturm Graz**](https://en.wikipedia.org/wiki/SK_Sturm_Graz) : (2) Sturm · Sturm Graz
- [**TSV Hartberg**](https://en.wikipedia.org/wiki/TSV_Hartberg) : (1) Hartberg
- [**Wolfsberger AC**](https://en.wikipedia.org/wiki/Wolfsberger_AC) : (2) Wolfsberg · AC Wolfsberger
- [**FC RB Salzburg**](https://en.wikipedia.org/wiki/FC_Red_Bull_Salzburg) : (3) Salzburg · FC Salzburg · FC Red Bull Salzburg
- **SV Grödig** : (1) Grödig ⇒ (4) ≈Grodig≈ · ≈Groedig≈ · ≈SV Grodig≈ · ≈SV Groedig≈
- [**FC Wacker Innsbruck**](https://en.wikipedia.org/wiki/FC_Wacker_Innsbruck_(2002)) : (2) FC Tirol · Wacker Innsbruck
- [**WSG Tirol**](https://en.wikipedia.org/wiki/WSG_Wattens) : (4) Tirol · WSG Wattens · WSG Swarovski Tirol · Wattener Sportgemeinschaft Tirol
- [**SCR Altach**](https://en.wikipedia.org/wiki/SC_Rheindorf_Altach) : (2) Altach · SC Rheindorf Altach




Alphabet

- **Alphabet Specials** (1):  **ö** 
  - **ö**×5 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe




Duplicates





By City

- **Wien, Wien** (3): 
  - FK Austria Wien  (2) Austria Wien · Austria Vienna [en]
  - SK Rapid Wien  (2) Rapid Wien · Rapid Vienna [en]
  - Wiener Sport-Club 
- **Linz, Oberösterreich** (2): 
  - LASK Linz  (2) LASK · Linzer ASK
  - FC Stahl Linz  (1) SK VOEST Linz
- **Altach, Vorarlberg** (1): SCR Altach  (2) Altach · SC Rheindorf Altach
- **Graz, Steiermark** (1): SK Sturm Graz  (2) Sturm · Sturm Graz
- **Grödig, Salzburg** (1): SV Grödig  (1) Grödig
- **Hartberg, Steiermark** (1): TSV Hartberg  (1) Hartberg
- **Innsbruck, Tirol** (1): FC Wacker Innsbruck  (2) Wacker Innsbruck · FC Tirol
- **Maria Enzersdorf, Niederösterreich** (1): FC Admira Wacker Mödling  (2) Admira · Admira Wien
- **Mattersburg, Burgenland** (1): SV Mattersburg  (1) Mattersburg
- **Ried i. Innkreis, Oberösterreich** (1): SV Ried  (1) Ried
- **Salzburg, Salzburg** (1): FC RB Salzburg  (3) Salzburg · FC Salzburg · FC Red Bull Salzburg
- **St. Pölten, Niederösterreich** (1): SKN St. Pölten  (1) St. Pölten
- **Wattens, Tirol** (1): WSG Tirol  (4) Tirol · WSG Swarovski Tirol · Wattener Sportgemeinschaft Tirol · WSG Wattens
- **Wolfsberg, Kärnten** (1): Wolfsberger AC  (2) Wolfsberg · AC Wolfsberger
- **Wr. Neustadt, Niederösterreich** (1): SC Wiener Neustadt  (1) Neustadt




By Region

- **Wien** (3):   FK Austria Wien · SK Rapid Wien · Wiener Sport-Club
- **Burgenland** (1):   SV Mattersburg
- **Niederösterreich** (3):   FC Admira Wacker Mödling · SC Wiener Neustadt · SKN St. Pölten
- **Oberösterreich** (3):   LASK Linz · FC Stahl Linz · SV Ried
- **Steiermark** (2):   SK Sturm Graz · TSV Hartberg
- **Kärnten** (1):   Wolfsberger AC
- **Salzburg** (2):   FC RB Salzburg · SV Grödig
- **Tirol** (2):   FC Wacker Innsbruck · WSG Tirol
- **Vorarlberg** (1):   SCR Altach




By Year

- **1930** (1):   WSG Tirol
- ? (17):   FK Austria Wien · SK Rapid Wien · Wiener Sport-Club · SV Mattersburg · FC Admira Wacker Mödling · SC Wiener Neustadt · SKN St. Pölten · LASK Linz · FC Stahl Linz · SV Ried · SK Sturm Graz · TSV Hartberg · Wolfsberger AC · FC RB Salzburg · SV Grödig · FC Wacker Innsbruck · SCR Altach






By A to Z

- **A** (6): Admira · Altach · Admira Wien · Austria Wien · AC Wolfsberger · Austria Vienna [en]
- **F** (8): FC Tirol · FC Salzburg · FC Stahl Linz · FC RB Salzburg · FK Austria Wien · FC Wacker Innsbruck · FC Red Bull Salzburg · FC Admira Wacker Mödling
- **G** (1): Grödig
- **H** (1): Hartberg
- **L** (3): LASK · LASK Linz · Linzer ASK
- **M** (1): Mattersburg
- **N** (1): Neustadt
- **R** (3): Ried · Rapid Wien · Rapid Vienna [en]
- **S** (14): Sturm · SV Ried · Salzburg · SV Grödig · SCR Altach · St. Pölten · Sturm Graz · SK Rapid Wien · SK Sturm Graz · SK VOEST Linz · SKN St. Pölten · SV Mattersburg · SC Wiener Neustadt · SC Rheindorf Altach
- **T** (2): Tirol · TSV Hartberg
- **W** (8): WSG Tirol · Wolfsberg · WSG Wattens · Wolfsberger AC · Wacker Innsbruck · Wiener Sport-Club · WSG Swarovski Tirol · Wattener Sportgemeinschaft Tirol




