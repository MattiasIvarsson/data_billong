5 clubs

- **UE Sant Julià** : (1) Sant Julià ⇒ (2) ≈Sant Julia≈ · ≈UE Sant Julia≈
- **FC Santa Coloma**
- **UE Santa Coloma**
- **FC Lusitans**
- **UE Engordany**




Alphabet

- **Alphabet Specials** (1):  **à** 
  - **à**×2 U+00E0 (224) - LATIN SMALL LETTER A WITH GRAVE ⇒ a




Duplicates





By City

- ? (5): 
  - UE Sant Julià  (1) Sant Julià
  - FC Santa Coloma 
  - UE Santa Coloma 
  - FC Lusitans 
  - UE Engordany 




By Region





By Year

- ? (5):   UE Sant Julià · FC Santa Coloma · UE Santa Coloma · FC Lusitans · UE Engordany






By A to Z

- **F** (2): FC Lusitans · FC Santa Coloma
- **S** (1): Sant Julià
- **U** (3): UE Engordany · UE Sant Julià · UE Santa Coloma




