12 clubs

- **KR Reykjavík** : (2) KR Reykjavik · Knattspyrnufélag Reykjavíkur ⇒ (2) ≈KR Reykjavik≈ · ≈Knattspyrnufelag Reykjavikur≈
- **Fram Reykjavík** : (1) Fram ⇒ (1) ≈Fram Reykjavik≈
- **Valur Reykjavík** : (1) Valur ⇒ (1) ≈Valur Reykjavik≈
- **Víkingur Reykjavík** ⇒ (1) ≈Vikingur Reykjavik≈
- **ÍA Akranes** : (2) IA Akranes · Íþróttabandalag Akraness ⇒ (2) ≈IA Akranes≈ · ≈Iprottabandalag Akraness≈
- **FH Hafnarfjördur** : (1) FH ⇒ (2) ≈FH Hafnarfjordur≈ · ≈FH Hafnarfjoerdur≈
- **Breidablik**
- **Thór Akureyri** ⇒ (1) ≈Thor Akureyri≈
- **ÍBV Vestmannaeyjar** : (1) ÍBV ⇒ (2) ≈IBV≈ · ≈IBV Vestmannaeyjar≈
- **Fylkir**
- **Keflavík** ⇒ (1) ≈Keflavik≈
- **Stjarnan**




Alphabet

- **Alphabet Specials** (6):  **Í**  **é**  **í**  **ó**  **ö**  **þ** 
  - **Í**×4 U+00CD (205) - LATIN CAPITAL LETTER I WITH ACUTE ⇒ I
  - **é**×1 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×7 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×2 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ö**×1 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **þ**×1 U+00FE (254) - LATIN SMALL LETTER THORN ⇒ p




Duplicates

- **KR Reykjavík**, Reykjavík (1):
  - `krreykjavik` (2): **KR Reykjavik** · **KR Reykjavik**
- **ÍA Akranes**, Akranes (1):
  - `iaakranes` (2): **IA Akranes** · **IA Akranes**




By City

- **Akranes** (1): ÍA Akranes  (2) IA Akranes · Íþróttabandalag Akraness
- **Reykjavík** (1): KR Reykjavík  (2) KR Reykjavik · Knattspyrnufélag Reykjavíkur
- ? (10): 
  - Fram Reykjavík  (1) Fram
  - Valur Reykjavík  (1) Valur
  - Víkingur Reykjavík 
  - FH Hafnarfjördur  (1) FH
  - Breidablik 
  - Thór Akureyri 
  - ÍBV Vestmannaeyjar  (1) ÍBV
  - Fylkir 
  - Keflavík 
  - Stjarnan 




By Region

- **Reykjavík†** (1):   KR Reykjavík
- **Akranes†** (1):   ÍA Akranes




By Year

- ? (12):   KR Reykjavík · Fram Reykjavík · Valur Reykjavík · Víkingur Reykjavík · ÍA Akranes · FH Hafnarfjördur · Breidablik · Thór Akureyri · ÍBV Vestmannaeyjar · Fylkir · Keflavík · Stjarnan






By A to Z

- **B** (1): Breidablik
- **F** (5): FH · Fram · Fylkir · Fram Reykjavík · FH Hafnarfjördur
- **I** (1): IA Akranes
- **K** (4): Keflavík · KR Reykjavik · KR Reykjavík · Knattspyrnufélag Reykjavíkur
- **S** (1): Stjarnan
- **T** (1): Thór Akureyri
- **V** (3): Valur · Valur Reykjavík · Víkingur Reykjavík
- **Í** (4): ÍBV · ÍA Akranes · ÍBV Vestmannaeyjar · Íþróttabandalag Akraness




