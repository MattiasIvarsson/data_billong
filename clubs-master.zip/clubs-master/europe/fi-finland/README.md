22 clubs

- **HJK Helsinki** : (2) HJK · Helsingin Jalkapalloklubi
- **HIFK Helsinki** : (3) HIFK · HIFK Fotboll · IFK Helsingfors
- **FC Haka Valkeakoski** : (2) Haka Valkeakoski · Valkeakosken Haka
- **FC Inter Turku** : (2) FC Inter · Inter Turku
- **TPS Turku** : (1) TPS
- **FC Honka Espoo** : (2) Honka · FC Honka
- **KuPS Kuopio** : (1) KuPS
- **Myllykosken Pallo -47** : (3) MyPa · MYPA · Myllykosken Pallo-47
- **FC Lahti** : (1) Lahti
- **JJK Jyväskylä** : (2) JJK · JJK Jyvaskyla ⇒ (2) ≈JJK Jyvaskyla≈ · ≈JJK Jyvaeskylae≈
- **Tampere United**
- **FC Ilves** : (2) Ilves · Ilves Tampere
- **IFK Mariehamn** : (1) Mariehamn
- **KPV Kokkola** : (2) KPV · Kokkolan Palloveikot
- **Rovaniemen Palloseura** : (3) RoPS · Rovaniemi · RoPS Rovaniemi
- **SJK Seinäjoki** : (2) SJK · Seinäjoen Jalkapallokerho ⇒ (4) ≈SJK Seinajoki≈ · ≈SJK Seinaejoki≈ · ≈Seinajoen Jalkapallokerho≈ · ≈Seinaejoen Jalkapallokerho≈
- **Vaasan Palloseura** : (2) VPS · VPS Vaasa
- **FC Haka** : (1) Haka
- **FF Jaro** : (2) Jaro · Fotbollsföreningen Jaro Jalkapalloseura ⇒ (2) ≈Fotbollsforeningen Jaro Jalkapalloseura≈ · ≈Fotbollsfoereningen Jaro Jalkapalloseura≈
- **KTP Kotka** : (2) KTP · Kotkan Työväen Palloilijat ⇒ (2) ≈Kotkan Tyovaen Palloilijat≈ · ≈Kotkan Tyoevaeen Palloilijat≈
- **PK-35 Vantaa** : (2) PK-35 · Pallokerho-35
- **Palloseura Kemi Kings** : (3) PS Kemi · Kemi City FC · Kemi City Football Club




Alphabet

- **Alphabet Specials** (2):  **ä**  **ö** 
  - **ä**×5 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **ö**×2 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe




Duplicates

- **Myllykosken Pallo -47**, Myllykoski (2):
  - `myllykoskenpallo47` (2): Myllykosken Pallo -47 · Myllykosken Pallo-47
  - `mypa` (2): MYPA · MyPa
- **JJK Jyväskylä**, Jyväskylä (1):
  - `jjkjyvaskyla` (2): **JJK Jyvaskyla** · **JJK Jyvaskyla**




By City

- **Helsinki** (2): 
  - HJK Helsinki  (2) Helsingin Jalkapalloklubi · HJK
  - HIFK Helsinki  (3) HIFK Fotboll · IFK Helsingfors · HIFK
- **Tampere** (2): 
  - Tampere United 
  - FC Ilves  (2) Ilves · Ilves Tampere
- **Turku** (2): 
  - FC Inter Turku  (2) FC Inter · Inter Turku
  - TPS Turku  (1) TPS
- **Valkeakoski** (2): 
  - FC Haka Valkeakoski  (2) Haka Valkeakoski · Valkeakosken Haka
  - FC Haka  (1) Haka
- **Espoo** (1): FC Honka Espoo  (2) FC Honka · Honka
- **Jakobstad** (1): FF Jaro  (2) Jaro · Fotbollsföreningen Jaro Jalkapalloseura
- **Jyväskylä** (1): JJK Jyväskylä  (2) JJK Jyvaskyla · JJK
- **Kemi** (1): Palloseura Kemi Kings  (3) PS Kemi · Kemi City FC · Kemi City Football Club
- **Kokkola** (1): KPV Kokkola  (2) KPV · Kokkolan Palloveikot
- **Kotka** (1): KTP Kotka  (2) KTP · Kotkan Työväen Palloilijat
- **Kuopio** (1): KuPS Kuopio  (1) KuPS
- **Lahti** (1): FC Lahti  (1) Lahti
- **Mariehamn** (1): IFK Mariehamn  (1) Mariehamn
- **Myllykoski** (1): Myllykosken Pallo -47  (3) Myllykosken Pallo-47 · MYPA · MyPa
- **Rovaniemi** (1): Rovaniemen Palloseura  (3) RoPS · Rovaniemi · RoPS Rovaniemi
- **Seinäjoki** (1): SJK Seinäjoki  (2) SJK · Seinäjoen Jalkapallokerho
- **Vaasa** (1): Vaasan Palloseura  (2) VPS · VPS Vaasa
- **Vantaa** (1): PK-35 Vantaa  (2) PK-35 · Pallokerho-35




By Region

- **Helsinki†** (2):   HJK Helsinki · HIFK Helsinki
- **Valkeakoski†** (2):   FC Haka Valkeakoski · FC Haka
- **Turku†** (2):   FC Inter Turku · TPS Turku
- **Espoo†** (1):   FC Honka Espoo
- **Kuopio†** (1):   KuPS Kuopio
- **Myllykoski†** (1):   Myllykosken Pallo -47
- **Lahti†** (1):   FC Lahti
- **Jyväskylä†** (1):   JJK Jyväskylä
- **Tampere†** (2):   Tampere United · FC Ilves
- **Mariehamn†** (1):   IFK Mariehamn
- **Kokkola†** (1):   KPV Kokkola
- **Rovaniemi†** (1):   Rovaniemen Palloseura
- **Seinäjoki†** (1):   SJK Seinäjoki
- **Vaasa†** (1):   Vaasan Palloseura
- **Jakobstad†** (1):   FF Jaro
- **Kotka†** (1):   KTP Kotka
- **Vantaa†** (1):   PK-35 Vantaa
- **Kemi†** (1):   Palloseura Kemi Kings




By Year

- ? (22):   HJK Helsinki · HIFK Helsinki · FC Haka Valkeakoski · FC Inter Turku · TPS Turku · FC Honka Espoo · KuPS Kuopio · Myllykosken Pallo -47 · FC Lahti · JJK Jyväskylä · Tampere United · FC Ilves · IFK Mariehamn · KPV Kokkola · Rovaniemen Palloseura · SJK Seinäjoki · Vaasan Palloseura · FC Haka · FF Jaro · KTP Kotka · PK-35 Vantaa · Palloseura Kemi Kings






By A to Z

- **F** (10): FC Haka · FF Jaro · FC Honka · FC Ilves · FC Inter · FC Lahti · FC Honka Espoo · FC Inter Turku · FC Haka Valkeakoski · Fotbollsföreningen Jaro Jalkapalloseura
- **H** (9): HJK · HIFK · Haka · Honka · HIFK Fotboll · HJK Helsinki · HIFK Helsinki · Haka Valkeakoski · Helsingin Jalkapalloklubi
- **I** (5): Ilves · Inter Turku · IFK Mariehamn · Ilves Tampere · IFK Helsingfors
- **J** (4): JJK · Jaro · JJK Jyvaskyla · JJK Jyväskylä
- **K** (10): KPV · KTP · KuPS · KTP Kotka · KPV Kokkola · KuPS Kuopio · Kemi City FC · Kokkolan Palloveikot · Kemi City Football Club · Kotkan Työväen Palloilijat
- **L** (1): Lahti
- **M** (5): MYPA · MyPa · Mariehamn · Myllykosken Pallo-47 · Myllykosken Pallo -47
- **P** (5): PK-35 · PS Kemi · PK-35 Vantaa · Pallokerho-35 · Palloseura Kemi Kings
- **R** (4): RoPS · Rovaniemi · RoPS Rovaniemi · Rovaniemen Palloseura
- **S** (3): SJK · SJK Seinäjoki · Seinäjoen Jalkapallokerho
- **T** (3): TPS · TPS Turku · Tampere United
- **V** (4): VPS · VPS Vaasa · Vaasan Palloseura · Valkeakosken Haka




