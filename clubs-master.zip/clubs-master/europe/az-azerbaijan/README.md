11 clubs

- **Bakı FK** ⇒ (1) ≈Baki FK≈
- **İnter Bakı PİK** ⇒ (1) ≈Inter Baki PIK≈
- **Neftçi PFK** ⇒ (1) ≈Neftci PFK≈
- **Qarabağ FK** : (1) Qarabağ ⇒ (2) ≈Qarabag≈ · ≈Qarabag FK≈
- **Xäzär Länkäran FK** ⇒ (2) ≈Xazar Lankaran FK≈ · ≈Xaezaer Laenkaeran FK≈
- **Olimpik-Şüvälan PFK** ⇒ (2) ≈Olimpik-Suvalan PFK≈ · ≈Olimpik-Şuevaelan PFK≈
- **Simurq PFK**
- **Gabala SC**
- **Keşla FK** ⇒ (1) ≈Kesla FK≈
- **Zirä FK** ⇒ (2) ≈Zira FK≈ · ≈Zirae FK≈
- **Käpäz PFK** ⇒ (2) ≈Kapaz PFK≈ · ≈Kaepaez PFK≈




Alphabet

- **Alphabet Specials** (8):  **ä**  **ç**  **ü**  **ğ**  **İ**  **ı**  **Ş**  **ş** 
  - **ä**×8 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **ç**×1 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **ü**×1 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue
  - **ğ**×2 U+011F (287) - LATIN SMALL LETTER G WITH BREVE ⇒ g
  - **İ**×2 U+0130 (304) - LATIN CAPITAL LETTER I WITH DOT ABOVE ⇒ I
  - **ı**×2 U+0131 (305) - LATIN SMALL LETTER DOTLESS I ⇒ i
  - **Ş**×1 U+015E (350) - LATIN CAPITAL LETTER S WITH CEDILLA ⇒ S
  - **ş**×1 U+015F (351) - LATIN SMALL LETTER S WITH CEDILLA ⇒ s




Duplicates





By City

- ? (11): 
  - Bakı FK 
  - İnter Bakı PİK 
  - Neftçi PFK 
  - Qarabağ FK  (1) Qarabağ
  - Xäzär Länkäran FK 
  - Olimpik-Şüvälan PFK 
  - Simurq PFK 
  - Gabala SC 
  - Keşla FK 
  - Zirä FK 
  - Käpäz PFK 




By Region





By Year

- ? (11):   Bakı FK · İnter Bakı PİK · Neftçi PFK · Qarabağ FK · Xäzär Länkäran FK · Olimpik-Şüvälan PFK · Simurq PFK · Gabala SC · Keşla FK · Zirä FK · Käpäz PFK






By A to Z

- **B** (1): Bakı FK
- **G** (1): Gabala SC
- **K** (2): Keşla FK · Käpäz PFK
- **N** (1): Neftçi PFK
- **O** (1): Olimpik-Şüvälan PFK
- **Q** (2): Qarabağ · Qarabağ FK
- **S** (1): Simurq PFK
- **X** (1): Xäzär Länkäran FK
- **Z** (1): Zirä FK
- **İ** (1): İnter Bakı PİK




