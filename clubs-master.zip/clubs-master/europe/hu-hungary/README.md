14 clubs

- **Ferencvárosi TC** : (2) Ferencváros · Ferencvaros ⇒ (2) ≈Ferencvaros≈ · ≈Ferencvarosi TC≈
- **Budapest Honvéd FC** : (1) Honvéd ⇒ (2) ≈Honved≈ · ≈Budapest Honved FC≈
- **MTK Budapest** : (1) MTK
- **Videoton FC**
- **Debreceni VSC** : (1) Debrecen
- **Győri ETO FC** : (1) Győr ⇒ (2) ≈Gyor≈ · ≈Gyori ETO FC≈
- **Paksi SE** : (1) Paks
- **Kecskeméti TE** : (1) Kecskemét ⇒ (2) ≈Kecskemet≈ · ≈Kecskemeti TE≈
- **Újpest FC** : (1) Újpest ⇒ (2) ≈Ujpest≈ · ≈Ujpest FC≈
- **Szombathelyi Haladás** : (1) Haladás ⇒ (2) ≈Haladas≈ · ≈Szombathelyi Haladas≈
- **Zalaegerszegi TE** : (1) Zalaegerszeg
- **Fehérvár FC** : (1) Fehérvár ⇒ (2) ≈Fehervar≈ · ≈Fehervar FC≈
- **Vasas FC** : (1) Vasas
- **Diósgyőri VTK** : (1) Diósgyőr ⇒ (2) ≈Diosgyor≈ · ≈Diosgyori VTK≈




Alphabet

- **Alphabet Specials** (5):  **Ú**  **á**  **é**  **ó**  **ő** 
  - **Ú**×2 U+00DA (218) - LATIN CAPITAL LETTER U WITH ACUTE ⇒ U
  - **á**×6 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×6 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ó**×2 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ő**×4 U+0151 (337) - LATIN SMALL LETTER O WITH DOUBLE ACUTE ⇒ o




Duplicates

- **Ferencvárosi TC**, Budapest (1):
  - `ferencvaros` (2): **Ferencvaros** · **Ferencvaros**




By City

- **Budapest** (1): Ferencvárosi TC  (2) Ferencváros · Ferencvaros
- ? (13): 
  - Budapest Honvéd FC  (1) Honvéd
  - MTK Budapest  (1) MTK
  - Videoton FC 
  - Debreceni VSC  (1) Debrecen
  - Győri ETO FC  (1) Győr
  - Paksi SE  (1) Paks
  - Kecskeméti TE  (1) Kecskemét
  - Újpest FC  (1) Újpest
  - Szombathelyi Haladás  (1) Haladás
  - Zalaegerszegi TE  (1) Zalaegerszeg
  - Fehérvár FC  (1) Fehérvár
  - Vasas FC  (1) Vasas
  - Diósgyőri VTK  (1) Diósgyőr




By Region

- **Budapest†** (1):   Ferencvárosi TC




By Year

- ? (14):   Ferencvárosi TC · Budapest Honvéd FC · MTK Budapest · Videoton FC · Debreceni VSC · Győri ETO FC · Paksi SE · Kecskeméti TE · Újpest FC · Szombathelyi Haladás · Zalaegerszegi TE · Fehérvár FC · Vasas FC · Diósgyőri VTK






By A to Z

- **B** (1): Budapest Honvéd FC
- **D** (4): Debrecen · Diósgyőr · Debreceni VSC · Diósgyőri VTK
- **F** (5): Fehérvár · Fehérvár FC · Ferencvaros · Ferencváros · Ferencvárosi TC
- **G** (2): Győr · Győri ETO FC
- **H** (2): Honvéd · Haladás
- **K** (2): Kecskemét · Kecskeméti TE
- **M** (2): MTK · MTK Budapest
- **P** (2): Paks · Paksi SE
- **S** (1): Szombathelyi Haladás
- **V** (3): Vasas · Vasas FC · Videoton FC
- **Z** (2): Zalaegerszeg · Zalaegerszegi TE
- **Ú** (2): Újpest · Újpest FC




