8 clubs

- **SP Tre Fiori**
- **SP Tre Penne**
- **AC Juvenes-Dogana** : (1) AC Juvenes/Dogana
- **SP La Fiorita** : (1) La Fiorita
- **AC Libertas**
- **SC Faetano**
- **SS Murata**
- **SS Folgore**




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **AC Juvenes-Dogana**,  (1):
  - `acjuvenesdogana` (2): AC Juvenes-Dogana · AC Juvenes/Dogana




By City

- ? (8): 
  - SP Tre Fiori 
  - SP Tre Penne 
  - AC Juvenes-Dogana  (1) AC Juvenes/Dogana
  - SP La Fiorita  (1) La Fiorita
  - AC Libertas 
  - SC Faetano 
  - SS Murata 
  - SS Folgore 




By Region





By Year

- ? (8):   SP Tre Fiori · SP Tre Penne · AC Juvenes-Dogana · SP La Fiorita · AC Libertas · SC Faetano · SS Murata · SS Folgore






By A to Z

- **A** (3): AC Libertas · AC Juvenes-Dogana · AC Juvenes/Dogana
- **L** (1): La Fiorita
- **S** (6): SS Murata · SC Faetano · SS Folgore · SP Tre Fiori · SP Tre Penne · SP La Fiorita




