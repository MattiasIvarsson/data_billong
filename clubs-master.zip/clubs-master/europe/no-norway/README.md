26 clubs

- **Vålerenga Fotball** : (2) Valerenga · Vålerenga ⇒ (2) ≈Valerenga≈ · ≈Valerenga Fotball≈
- **Rosenborg BK** : (2) Rosenborg · Rosenborg Ballklub
- **Ranheim** : (1) Ranheim Fotball
- **Molde FK** : (1) Molde
- **Tromsø IL** : (3) Tromso · Tromsø · Tromsø Idrettslag ⇒ (3) ≈Tromso≈ · ≈Tromso IL≈ · ≈Tromso Idrettslag≈
- **Aalesunds FK** : (2) Aalesund · Aalesunds Fotballklubb
- **SK Brann** : (1) Brann
- **Strømsgodset IF** : (3) Stromsgodset · Strømsgodset · Strømsgodset Toppfotball ⇒ (3) ≈Stromsgodset≈ · ≈Stromsgodset IF≈ · ≈Stromsgodset Toppfotball≈
- **Fredrikstad FK** : (2) Fredrikstad · Fredrikstad Fotballklubb
- **Lillestrøm SK** : (2) Lillestrom · Lillestrøm ⇒ (2) ≈Lillestrom≈ · ≈Lillestrom SK≈
- **Viking FK** : (3) Viking · Viking Stavanger · Viking Fotballklubb
- **Odds BK** : (2) Odd · Odds Ballklubb
- **Sandefjord** : (1) Sandefjord Fotball
- **Sandnes Ulf** : (1) Sandnes
- **Sarpsborg 08** : (3) Sarpsborg · Sarpsborg 08 FF · Sarpsborg 08 Fotballforening
- **Sogndal** : (1) Sogndal Fotball
- **Stabæk** : (2) Stabaek · Stabæk Fotball ⇒ (2) ≈Stabaek≈ · ≈Stabaek Fotball≈
- **IK Start** : (2) Start · Idrettsklubben Start
- **Kristiansund BK** : (2) Kristiansund · Kristiansund Ballklubb
- **Mjøndalen IF** : (2) Mjondalen · Mjøndalen ⇒ (2) ≈Mjondalen≈ · ≈Mjondalen IF≈
- **Bodø/Glimt** : (3) Bodo/Glimt · FK Bodø/Glimt · Fotballklubben Bodø/Glimt ⇒ (3) ≈Bodo/Glimt≈ · ≈FK Bodo/Glimt≈ · ≈Fotballklubben Bodo/Glimt≈
- **FK Haugesund** : (2) Haugesund · Fotballklubben Haugesund
- **Hønefoss BK** : (3) Honefoss · Hønefoss · Hønefoss Ballklubb ⇒ (3) ≈Honefoss≈ · ≈Honefoss BK≈ · ≈Honefoss Ballklubb≈
- **FK Jerv** : (1) Jerv
- **Ullensaker/Kisa IL** : (1) Ull/Kisa
- **IL Hødd** : (2) Hødd · Idrettslaget Hødd ⇒ (3) ≈Hodd≈ · ≈IL Hodd≈ · ≈Idrettslaget Hodd≈




Alphabet

- **Alphabet Specials** (3):  **å**  **æ**  **ø** 
  - **å**×2 U+00E5 (229) - LATIN SMALL LETTER A WITH RING ABOVE ⇒ a
  - **æ**×2 U+00E6 (230) - LATIN SMALL LETTER AE ⇒ ae
  - **ø**×19 U+00F8 (248) - LATIN SMALL LETTER O WITH STROKE ⇒ o




Duplicates

- **Vålerenga Fotball**, Oslo (1):
  - `valerenga` (2): **Valerenga** · **Valerenga**
- **Tromsø IL**, Tromsø (1):
  - `tromso` (2): **Tromso** · **Tromso**
- **Strømsgodset IF**, Drammen (1):
  - `stromsgodset` (2): **Stromsgodset** · **Stromsgodset**
- **Lillestrøm SK**, Lillestrøm (1):
  - `lillestrom` (2): **Lillestrom** · **Lillestrom**
- **Stabæk**, Bærum (1):
  - `stabaek` (2): **Stabaek** · **Stabaek**
- **Mjøndalen IF**, Mjøndalen (1):
  - `mjondalen` (2): **Mjondalen** · **Mjondalen**
- **Bodø/Glimt**, Bodø (1):
  - `bodoglimt` (2): **Bodo/Glimt** · **Bodo/Glimt**
- **Hønefoss BK**, Hønefoss (1):
  - `honefoss` (2): **Honefoss** · **Honefoss**




By City

- **Trondheim** (2): 
  - Rosenborg BK  (2) Rosenborg · Rosenborg Ballklub
  - Ranheim  (1) Ranheim Fotball
- **Bergen** (1): SK Brann  (1) Brann
- **Bodø** (1): Bodø/Glimt  (3) Bodo/Glimt · FK Bodø/Glimt · Fotballklubben Bodø/Glimt
- **Bærum** (1): Stabæk  (2) Stabaek · Stabæk Fotball
- **Drammen** (1): Strømsgodset IF  (3) Stromsgodset · Strømsgodset · Strømsgodset Toppfotball
- **Fredrikstad** (1): Fredrikstad FK  (2) Fredrikstad · Fredrikstad Fotballklubb
- **Grimstad** (1): FK Jerv  (1) Jerv
- **Haugesund** (1): FK Haugesund  (2) Haugesund · Fotballklubben Haugesund
- **Hønefoss** (1): Hønefoss BK  (3) Honefoss · Hønefoss · Hønefoss Ballklubb
- **Kristiansand** (1): IK Start  (2) Start · Idrettsklubben Start
- **Kristiansund** (1): Kristiansund BK  (2) Kristiansund · Kristiansund Ballklubb
- **Lillestrøm** (1): Lillestrøm SK  (2) Lillestrom · Lillestrøm
- **Mjøndalen** (1): Mjøndalen IF  (2) Mjondalen · Mjøndalen
- **Molde** (1): Molde FK  (1) Molde
- **Oslo** (1): Vålerenga Fotball  (2) Valerenga · Vålerenga
- **Sandefjord** (1): Sandefjord  (1) Sandefjord Fotball
- **Sandnes** (1): Sandnes Ulf  (1) Sandnes
- **Sarpsborg** (1): Sarpsborg 08  (3) Sarpsborg · Sarpsborg 08 FF · Sarpsborg 08 Fotballforening
- **Skien** (1): Odds BK  (2) Odd · Odds Ballklubb
- **Sogndal** (1): Sogndal  (1) Sogndal Fotball
- **Stavanger** (1): Viking FK  (3) Viking · Viking Fotballklubb · Viking Stavanger
- **Tromsø** (1): Tromsø IL  (3) Tromso · Tromsø · Tromsø Idrettslag
- **Ullensaker** (1): Ullensaker/Kisa IL  (1) Ull/Kisa
- **Ulsteinvik** (1): IL Hødd  (2) Hødd · Idrettslaget Hødd
- **Ålesund** (1): Aalesunds FK  (2) Aalesund · Aalesunds Fotballklubb




By Region

- **Oslo†** (1):   Vålerenga Fotball
- **Trondheim†** (2):   Rosenborg BK · Ranheim
- **Molde†** (1):   Molde FK
- **Tromsø†** (1):   Tromsø IL
- **Ålesund†** (1):   Aalesunds FK
- **Bergen†** (1):   SK Brann
- **Drammen†** (1):   Strømsgodset IF
- **Fredrikstad†** (1):   Fredrikstad FK
- **Lillestrøm†** (1):   Lillestrøm SK
- **Stavanger†** (1):   Viking FK
- **Skien†** (1):   Odds BK
- **Sandefjord†** (1):   Sandefjord
- **Sandnes†** (1):   Sandnes Ulf
- **Sarpsborg†** (1):   Sarpsborg 08
- **Sogndal†** (1):   Sogndal
- **Bærum†** (1):   Stabæk
- **Kristiansand†** (1):   IK Start
- **Kristiansund†** (1):   Kristiansund BK
- **Mjøndalen†** (1):   Mjøndalen IF
- **Bodø†** (1):   Bodø/Glimt
- **Haugesund†** (1):   FK Haugesund
- **Hønefoss†** (1):   Hønefoss BK
- **Grimstad†** (1):   FK Jerv
- **Ullensaker†** (1):   Ullensaker/Kisa IL
- **Ulsteinvik†** (1):   IL Hødd




By Year

- ? (26):   Vålerenga Fotball · Rosenborg BK · Ranheim · Molde FK · Tromsø IL · Aalesunds FK · SK Brann · Strømsgodset IF · Fredrikstad FK · Lillestrøm SK · Viking FK · Odds BK · Sandefjord · Sandnes Ulf · Sarpsborg 08 · Sogndal · Stabæk · IK Start · Kristiansund BK · Mjøndalen IF · Bodø/Glimt · FK Haugesund · Hønefoss BK · FK Jerv · Ullensaker/Kisa IL · IL Hødd






By A to Z

- **A** (3): Aalesund · Aalesunds FK · Aalesunds Fotballklubb
- **B** (3): Brann · Bodo/Glimt · Bodø/Glimt
- **F** (8): FK Jerv · Fredrikstad · FK Haugesund · FK Bodø/Glimt · Fredrikstad FK · Fotballklubben Haugesund · Fredrikstad Fotballklubb · Fotballklubben Bodø/Glimt
- **H** (6): Hødd · Honefoss · Hønefoss · Haugesund · Hønefoss BK · Hønefoss Ballklubb
- **I** (4): IL Hødd · IK Start · Idrettslaget Hødd · Idrettsklubben Start
- **J** (1): Jerv
- **K** (3): Kristiansund · Kristiansund BK · Kristiansund Ballklubb
- **L** (3): Lillestrom · Lillestrøm · Lillestrøm SK
- **M** (5): Molde · Molde FK · Mjondalen · Mjøndalen · Mjøndalen IF
- **O** (3): Odd · Odds BK · Odds Ballklubb
- **R** (5): Ranheim · Rosenborg · Rosenborg BK · Ranheim Fotball · Rosenborg Ballklub
- **S** (19): Start · Stabæk · Sandnes · Sogndal · Stabaek · SK Brann · Sarpsborg · Sandefjord · Sandnes Ulf · Sarpsborg 08 · Stromsgodset · Strømsgodset · Stabæk Fotball · Sarpsborg 08 FF · Sogndal Fotball · Strømsgodset IF · Sandefjord Fotball · Strømsgodset Toppfotball · Sarpsborg 08 Fotballforening
- **T** (4): Tromso · Tromsø · Tromsø IL · Tromsø Idrettslag
- **U** (2): Ull/Kisa · Ullensaker/Kisa IL
- **V** (7): Viking · Valerenga · Viking FK · Vålerenga · Viking Stavanger · Vålerenga Fotball · Viking Fotballklubb




