9 clubs

- **NK Olimpija Ljubljana** : (1) Olimpija Ljubljana
- **NK IB Ljubljana** : (1) IB Ljubljana
- **NK Maribor** : (1) Maribor
- **ND Mura 05** : (1) Mura
- **FC Koper** : (1) Koper
- **ND Gorica** : (1) Gorica
- **NK Domžale** : (1) Domžale ⇒ (2) ≈Domzale≈ · ≈NK Domzale≈
- **NK Rudar Velenje** : (1) Rudar Velenje
- **NK Celje** : (1) Celje




Alphabet

- **Alphabet Specials** (1):  **ž** 
  - **ž**×2 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Maribor** (1): NK Maribor  (1) Maribor
- ? (8): 
  - NK Olimpija Ljubljana  (1) Olimpija Ljubljana
  - NK IB Ljubljana  (1) IB Ljubljana
  - ND Mura 05  (1) Mura
  - FC Koper  (1) Koper
  - ND Gorica  (1) Gorica
  - NK Domžale  (1) Domžale
  - NK Rudar Velenje  (1) Rudar Velenje
  - NK Celje  (1) Celje




By Region

- **Maribor†** (1):   NK Maribor




By Year

- ? (9):   NK Olimpija Ljubljana · NK IB Ljubljana · NK Maribor · ND Mura 05 · FC Koper · ND Gorica · NK Domžale · NK Rudar Velenje · NK Celje






By A to Z

- **C** (1): Celje
- **D** (1): Domžale
- **F** (1): FC Koper
- **G** (1): Gorica
- **I** (1): IB Ljubljana
- **K** (1): Koper
- **M** (2): Mura · Maribor
- **N** (8): NK Celje · ND Gorica · ND Mura 05 · NK Domžale · NK Maribor · NK IB Ljubljana · NK Rudar Velenje · NK Olimpija Ljubljana
- **O** (1): Olimpija Ljubljana
- **R** (1): Rudar Velenje




