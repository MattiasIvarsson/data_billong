43 clubs

- [**SL Benfica**](https://en.wikipedia.org/wiki/S.L._Benfica) : (4) Benfica · Benfica Lis. · Benfica Lisboa · Benfica Lissabon
- [**Sporting CP**](https://en.wikipedia.org/wiki/Sporting_CP) : (3) Sp Lisbon · Sporting Lisboa · Sporting Clube de Portugal
- [**Os Belenenses**](https://en.wikipedia.org/wiki/Belenenses_SAD) : (2) Belenenses · Belenenses SAD
- [**FC Porto**](https://en.wikipedia.org/wiki/FC_Porto) : (1) Porto
- [**Boavista FC**](https://en.wikipedia.org/wiki/Boavista_F.C.) : (1) Boavista
- [**CD Aves**](https://en.wikipedia.org/wiki/C.D._Aves) : (1) Aves
- [**GD Chaves**](https://en.wikipedia.org/wiki/G.D._Chaves) : (1) Chaves
- **Estoril Praia** : (1) Estoril
- [**CD Feirense**](https://en.wikipedia.org/wiki/C.D._Feirense) : (1) Feirense
- [**Vitória de Guimarães**](https://en.wikipedia.org/wiki/Vitória_S.C.) : (2) Guimaraes · Vitória SC ⇒ (2) ≈Vitoria SC≈ · ≈Vitoria de Guimaraes≈
- [**Vitória de Setúbal**](https://en.wikipedia.org/wiki/Vitória_F.C.) : (2) Setubal · Vitória FC ⇒ (2) ≈Vitoria FC≈ · ≈Vitoria de Setubal≈
- [**CS Marítimo**](https://en.wikipedia.org/wiki/C.S._Marítimo) : (2) Maritimo · Marítimo ⇒ (2) ≈Maritimo≈ · ≈CS Maritimo≈
- [**Moreirense FC**](https://en.wikipedia.org/wiki/Moreirense_F.C.) : (1) Moreirense
- **FC Paços de Ferreira** : (2) Pacos Ferreira · Paços Ferreira ⇒ (2) ≈Pacos Ferreira≈ · ≈FC Pacos de Ferreira≈
- [**Portimonense SC**](https://en.wikipedia.org/wiki/Portimonense_S.C.) : (1) Portimonense
- [**Rio Ave FC**](https://en.wikipedia.org/wiki/Rio_Ave_F.C.) : (1) Rio Ave
- [**SC Braga**](https://en.wikipedia.org/wiki/S.C._Braga) : (3) Braga · Sp Braga · Sporting Braga
- [**CD Tondela**](https://en.wikipedia.org/wiki/C.D._Tondela) : (1) Tondela
- **Académica de Coimbra** : (4) Académica · Academica · A. Académica de Coimbra · Associação Académica de Coimbra ⇒ (4) ≈Academica≈ · ≈Academica de Coimbra≈ · ≈A. Academica de Coimbra≈ · ≈Associacao Academica de Coimbra≈
- **FC Arouca** : (1) Arouca
- [**CD Nacional Madeira**](https://en.wikipedia.org/wiki/C.D._Nacional) : (4) Nacional · CD Nacional · Nacional da Madeira · Clube Desportivo Nacional
- **FC Penafiel** : (1) Penafiel
- **SC Beira-Mar** : (1) Beira Mar
- **Desportivo de Chaves** : (1) Desp. Chaves
- **CF Estrela da Amadora** : (1) Est Amadora
- **SC Farense** : (1) Farense
- **Gil Vicente FC** : (1) Gil Vicente
- **União de Leiria** : (2) Leiria · União Desportiva de Leiria ⇒ (2) ≈Uniao de Leiria≈ · ≈Uniao Desportiva de Leiria≈
- **União da Madeira** : (2) Madeira · Uniao Madeira ⇒ (1) ≈Uniao da Madeira≈
- **SC Salgueiros** : (1) Salgueiros
- **FC Tirsense** : (1) Tirsense
- **SC Campomaiorense** : (2) Campomaior · Campomaiorense
- **FC Felgueiras** : (1) Felgueiras
- **Leça FC** : (1) Leca ⇒ (1) ≈Leca FC≈
- **FC Alverca** : (1) Alverca
- **Sporting de Espinho** : (2) Espinho · Sporting Clube de Espinho
- **Leixões SC** : (1) Leixoes ⇒ (1) ≈Leixoes SC≈
- **Naval 1º de Maio** : (2) Naval · Associação Naval 1º de Maio ⇒ (1) ≈Associacao Naval 1º de Maio≈
- **SC Olhanense** : (1) Olhanense
- [**CD Santa Clara**](https://en.wikipedia.org/wiki/C.D._Santa_Clara) : (1) Santa Clara
- **CD Trofense** : (2) Trofense · Clube Desportivo Trofense
- **Varzim SC** : (1) Varzim
- **FC Famalicão** : (2) Famalicão · Futebol Clube de Famalicão ⇒ (3) ≈Famalicao≈ · ≈FC Famalicao≈ · ≈Futebol Clube de Famalicao≈




Alphabet

- **Alphabet Specials** (7):  **ã**  **ç**  **é**  **í**  **ó**  **õ**  **ú** 
  - **ã**×9 U+00E3 (227) - LATIN SMALL LETTER A WITH TILDE ⇒ a
  - **ç**×5 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **é**×4 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×2 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×4 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **õ**×1 U+00F5 (245) - LATIN SMALL LETTER O WITH TILDE ⇒ o
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates

- **CS Marítimo**, Funchal (1):
  - `maritimo` (2): **Maritimo** · **Maritimo**
- **FC Paços de Ferreira**, Paços de Ferreira (1):
  - `pacosferreira` (2): **Pacos Ferreira** · **Pacos Ferreira**
- **Académica de Coimbra**, Coimbra (1):
  - `academica` (2): **Academica** · **Academica**




By City

- **Funchal** (3): 
  - CS Marítimo  (2) Maritimo · Marítimo
  - CD Nacional Madeira  (4) Nacional · CD Nacional · Nacional da Madeira · Clube Desportivo Nacional
  - União da Madeira  (2) Madeira · Uniao Madeira
- **Lisboa** (3): 
  - SL Benfica  (4) Benfica · Benfica Lisboa · Benfica Lissabon · Benfica Lis.
  - Sporting CP  (3) Sp Lisbon · Sporting Lisboa · Sporting Clube de Portugal
  - Os Belenenses  (2) Belenenses · Belenenses SAD
- **Chaves** (2): 
  - GD Chaves  (1) Chaves
  - Desportivo de Chaves  (1) Desp. Chaves
- **Porto** (2): 
  - FC Porto  (1) Porto
  - Boavista FC  (1) Boavista
- **Alverca do Ribatejo** (1): FC Alverca  (1) Alverca
- **Amadora** (1): CF Estrela da Amadora  (1) Est Amadora
- **Arouca** (1): FC Arouca  (1) Arouca
- **Aveiro** (1): SC Beira-Mar  (1) Beira Mar
- **Aves** (1): CD Aves  (1) Aves
- **Barcelos** (1): Gil Vicente FC  (1) Gil Vicente
- **Braga** (1): SC Braga  (3) Braga · Sp Braga · Sporting Braga
- **Campo Maior** (1): SC Campomaiorense  (2) Campomaior · Campomaiorense
- **Coimbra** (1): Académica de Coimbra  (4) Académica · Academica · A. Académica de Coimbra · Associação Académica de Coimbra
- **Espinho** (1): Sporting de Espinho  (2) Espinho · Sporting Clube de Espinho
- **Estoril** (1): Estoril Praia  (1) Estoril
- **Faro** (1): SC Farense  (1) Farense
- **Felgueiras** (1): FC Felgueiras  (1) Felgueiras
- **Figueira da Foz** (1): Naval 1º de Maio  (2) Naval · Associação Naval 1º de Maio
- **Guimarães** (1): Vitória de Guimarães  (2) Guimaraes · Vitória SC
- **Leiria** (1): União de Leiria  (2) Leiria · União Desportiva de Leiria
- **Leça da Palmeira** (1): Leça FC  (1) Leca
- **Matosinhos** (1): Leixões SC  (1) Leixoes
- **Moreira de Cónegos** (1): Moreirense FC  (1) Moreirense
- **Olhão** (1): SC Olhanense  (1) Olhanense
- **Paranhos** (1): SC Salgueiros  (1) Salgueiros
- **Paços de Ferreira** (1): FC Paços de Ferreira  (2) Pacos Ferreira · Paços Ferreira
- **Penafiel** (1): FC Penafiel  (1) Penafiel
- **Ponta Delgada** (1): CD Santa Clara  (1) Santa Clara
- **Portimão** (1): Portimonense SC  (1) Portimonense
- **Póvoa de Varzim** (1): Varzim SC  (1) Varzim
- **Santa Maria da Feira** (1): CD Feirense  (1) Feirense
- **Santo Tirso** (1): FC Tirsense  (1) Tirsense
- **Setúbal** (1): Vitória de Setúbal  (2) Setubal · Vitória FC
- **Tondela** (1): CD Tondela  (1) Tondela
- **Tulipa** (1): CD Trofense  (2) Trofense · Clube Desportivo Trofense
- **Vila Nova de Famalicão** (1): FC Famalicão  (2) Famalicão · Futebol Clube de Famalicão
- **Vila do Conde** (1): Rio Ave FC  (1) Rio Ave




By Region

- **Lisboa†** (3):   SL Benfica · Sporting CP · Os Belenenses
- **Porto†** (2):   FC Porto · Boavista FC
- **Aves†** (1):   CD Aves
- **Chaves†** (2):   GD Chaves · Desportivo de Chaves
- **Estoril†** (1):   Estoril Praia
- **Santa Maria da Feira†** (1):   CD Feirense
- **Guimarães†** (1):   Vitória de Guimarães
- **Setúbal†** (1):   Vitória de Setúbal
- **Funchal†** (3):   CS Marítimo · CD Nacional Madeira · União da Madeira
- **Moreira de Cónegos†** (1):   Moreirense FC
- **Paços de Ferreira†** (1):   FC Paços de Ferreira
- **Portimão†** (1):   Portimonense SC
- **Vila do Conde†** (1):   Rio Ave FC
- **Braga†** (1):   SC Braga
- **Tondela†** (1):   CD Tondela
- **Coimbra†** (1):   Académica de Coimbra
- **Arouca†** (1):   FC Arouca
- **Penafiel†** (1):   FC Penafiel
- **Aveiro†** (1):   SC Beira-Mar
- **Amadora†** (1):   CF Estrela da Amadora
- **Faro†** (1):   SC Farense
- **Barcelos†** (1):   Gil Vicente FC
- **Leiria†** (1):   União de Leiria
- **Paranhos†** (1):   SC Salgueiros
- **Santo Tirso†** (1):   FC Tirsense
- **Campo Maior†** (1):   SC Campomaiorense
- **Felgueiras†** (1):   FC Felgueiras
- **Leça da Palmeira†** (1):   Leça FC
- **Alverca do Ribatejo†** (1):   FC Alverca
- **Espinho†** (1):   Sporting de Espinho
- **Matosinhos†** (1):   Leixões SC
- **Figueira da Foz†** (1):   Naval 1º de Maio
- **Olhão†** (1):   SC Olhanense
- **Ponta Delgada†** (1):   CD Santa Clara
- **Tulipa†** (1):   CD Trofense
- **Póvoa de Varzim†** (1):   Varzim SC
- **Vila Nova de Famalicão†** (1):   FC Famalicão




By Year

- **1931** (1):   FC Famalicão
- ? (42):   SL Benfica · Sporting CP · Os Belenenses · FC Porto · Boavista FC · CD Aves · GD Chaves · Estoril Praia · CD Feirense · Vitória de Guimarães · Vitória de Setúbal · CS Marítimo · Moreirense FC · FC Paços de Ferreira · Portimonense SC · Rio Ave FC · SC Braga · CD Tondela · Académica de Coimbra · FC Arouca · CD Nacional Madeira · FC Penafiel · SC Beira-Mar · Desportivo de Chaves · CF Estrela da Amadora · SC Farense · Gil Vicente FC · União de Leiria · União da Madeira · SC Salgueiros · FC Tirsense · SC Campomaiorense · FC Felgueiras · Leça FC · FC Alverca · Sporting de Espinho · Leixões SC · Naval 1º de Maio · SC Olhanense · CD Santa Clara · CD Trofense · Varzim SC






By A to Z

- **A** (9): Aves · Arouca · Alverca · Academica · Académica · Académica de Coimbra · A. Académica de Coimbra · Associação Naval 1º de Maio · Associação Académica de Coimbra
- **B** (10): Braga · Benfica · Boavista · Beira Mar · Belenenses · Boavista FC · Benfica Lis. · Belenenses SAD · Benfica Lisboa · Benfica Lissabon
- **C** (14): Chaves · CD Aves · CD Tondela · Campomaior · CD Feirense · CD Nacional · CD Trofense · CS Marítimo · CD Santa Clara · Campomaiorense · CD Nacional Madeira · CF Estrela da Amadora · Clube Desportivo Nacional · Clube Desportivo Trofense
- **D** (2): Desp. Chaves · Desportivo de Chaves
- **E** (4): Espinho · Estoril · Est Amadora · Estoril Praia
- **F** (13): Farense · FC Porto · Feirense · FC Arouca · Famalicão · FC Alverca · Felgueiras · FC Penafiel · FC Tirsense · FC Famalicão · FC Felgueiras · FC Paços de Ferreira · Futebol Clube de Famalicão
- **G** (4): GD Chaves · Guimaraes · Gil Vicente · Gil Vicente FC
- **L** (5): Leca · Leiria · Leixoes · Leça FC · Leixões SC
- **M** (5): Madeira · Maritimo · Marítimo · Moreirense · Moreirense FC
- **N** (4): Naval · Nacional · Naval 1º de Maio · Nacional da Madeira
- **O** (2): Olhanense · Os Belenenses
- **P** (6): Porto · Penafiel · Portimonense · Pacos Ferreira · Paços Ferreira · Portimonense SC
- **R** (2): Rio Ave · Rio Ave FC
- **S** (18): Setubal · SC Braga · Sp Braga · Sp Lisbon · SC Farense · SL Benfica · Salgueiros · Santa Clara · Sporting CP · SC Beira-Mar · SC Olhanense · SC Salgueiros · Sporting Braga · Sporting Lisboa · SC Campomaiorense · Sporting de Espinho · Sporting Clube de Espinho · Sporting Clube de Portugal
- **T** (3): Tondela · Tirsense · Trofense
- **U** (4): Uniao Madeira · União de Leiria · União da Madeira · União Desportiva de Leiria
- **V** (6): Varzim · Varzim SC · Vitória FC · Vitória SC · Vitória de Setúbal · Vitória de Guimarães




