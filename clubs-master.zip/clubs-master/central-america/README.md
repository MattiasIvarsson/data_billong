6 datafiles, 23 clubs

**central-america/costa-rica/cr.clubs.txt** _(3)_:  LD Alajuelense · CS Herediano · CS Cartaginés

**central-america/guatemala/gt.clubs.txt** _(4)_:  CSD Municipal · Club Xelajú MC · Comunicaciones FC · Heredia Jaguares de Peten

**central-america/hn-honduras/clubs.txt** _(5)_:  CD Olimpia · CD Marathón · Real CD España · CD Motagua · CD Victoria

**central-america/ni-nicaragua/clubs.txt** _(1)_:  Real Estelí

**central-america/pa-panama/clubs.txt** _(5)_:  Chorrillo FC · Tauro FC · Club Deportivo Árabe Unido · San Francisco FC · Sporting San Miguelito

**central-america/sv-el-salvador/clubs.txt** _(5)_:  I. Metapán · Club Deportivo Águila · Club Deportivo FAS · Alianza FC · Luis Ángel Firpo

