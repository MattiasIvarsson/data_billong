5 clubs

- **I. Metapán** : (3) Metapán · Isidro Metapán · Asociación Deportiva Isidro Metapán ⇒ (4) ≈Metapan≈ · ≈I. Metapan≈ · ≈Isidro Metapan≈ · ≈Asociacion Deportiva Isidro Metapan≈
- **Club Deportivo Águila** : (1) Águila ⇒ (2) ≈Aguila≈ · ≈Club Deportivo Aguila≈
- **Club Deportivo FAS** : (2) CD FAS · Futbolistas Asociados Santanecos
- **Alianza FC** : (2) Alianza · Alianza Fútbol Club ⇒ (1) ≈Alianza Futbol Club≈
- **Luis Ángel Firpo** : (2) L.A. Firpo · CD Luis Ángel Firpo ⇒ (2) ≈Luis Angel Firpo≈ · ≈CD Luis Angel Firpo≈




Alphabet

- **Alphabet Specials** (4):  **Á**  **á**  **ó**  **ú** 
  - **Á**×4 U+00C1 (193) - LATIN CAPITAL LETTER A WITH ACUTE ⇒ A
  - **á**×4 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **city:sansalvador** (2): 
  - Club Deportivo Águila  (1) Águila
  - Alianza FC  (2) Alianza · Alianza Fútbol Club
- **city:metapan** (1): I. Metapán  (3) Metapán · Isidro Metapán · Asociación Deportiva Isidro Metapán
- **city:santaana** (1): Club Deportivo FAS  (2) CD FAS · Futbolistas Asociados Santanecos
- ? (1): Luis Ángel Firpo  (2) L.A. Firpo · CD Luis Ángel Firpo




By Region

- **city:metapan†** (1):   I. Metapán
- **city:sansalvador†** (2):   Club Deportivo Águila · Alianza FC
- **city:santaana†** (1):   Club Deportivo FAS




By Year

- ? (5):   I. Metapán · Club Deportivo Águila · Club Deportivo FAS · Alianza FC · Luis Ángel Firpo






By A to Z

- **A** (4): Alianza · Alianza FC · Alianza Fútbol Club · Asociación Deportiva Isidro Metapán
- **C** (4): CD FAS · Club Deportivo FAS · CD Luis Ángel Firpo · Club Deportivo Águila
- **F** (1): Futbolistas Asociados Santanecos
- **I** (2): I. Metapán · Isidro Metapán
- **L** (2): L.A. Firpo · Luis Ángel Firpo
- **M** (1): Metapán
- **Á** (1): Águila




