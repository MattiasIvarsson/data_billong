3 clubs

- **LD Alajuelense** : (1) Alajuelense
- **CS Herediano** : (1) Herediano
- **CS Cartaginés** : (1) Cartaginés ⇒ (2) ≈Cartagines≈ · ≈CS Cartagines≈




Alphabet

- **Alphabet Specials** (1):  **é** 
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e




Duplicates





By City

- **city:alajuela** (1): LD Alajuelense  (1) Alajuelense
- **city:heredia** (1): CS Herediano  (1) Herediano
- ? (1): CS Cartaginés  (1) Cartaginés




By Region

- **city:alajuela†** (1):   LD Alajuelense
- **city:heredia†** (1):   CS Herediano




By Year

- ? (3):   LD Alajuelense · CS Herediano · CS Cartaginés






By A to Z

- **A** (1): Alajuelense
- **C** (3): Cartaginés · CS Herediano · CS Cartaginés
- **H** (1): Herediano
- **L** (1): LD Alajuelense




