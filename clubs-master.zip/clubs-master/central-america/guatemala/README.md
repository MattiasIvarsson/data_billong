4 clubs

- **CSD Municipal** : (1) Municipal
- **Club Xelajú MC** : (1) Xelajú ⇒ (2) ≈Xelaju≈ · ≈Club Xelaju MC≈
- **Comunicaciones FC** : (2) CSD Comuni. · Comunicaciones
- **Heredia Jaguares de Peten** : (1) Heredia




Alphabet

- **Alphabet Specials** (1):  **ú** 
  - **ú**×2 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **city:guatemala** (2): 
  - CSD Municipal  (1) Municipal
  - Comunicaciones FC  (2) Comunicaciones · CSD Comuni.
- **city:quetzaltenango** (1): Club Xelajú MC  (1) Xelajú
- ? (1): Heredia Jaguares de Peten  (1) Heredia




By Region

- **city:guatemala†** (2):   CSD Municipal · Comunicaciones FC
- **city:quetzaltenango†** (1):   Club Xelajú MC




By Year

- ? (4):   CSD Municipal · Club Xelajú MC · Comunicaciones FC · Heredia Jaguares de Peten






By A to Z

- **C** (5): CSD Comuni. · CSD Municipal · Club Xelajú MC · Comunicaciones · Comunicaciones FC
- **H** (2): Heredia · Heredia Jaguares de Peten
- **M** (1): Municipal
- **X** (1): Xelajú




