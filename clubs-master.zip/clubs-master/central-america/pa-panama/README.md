5 clubs

- **Chorrillo FC** : (1) Chorrillo
- **Tauro FC** : (1) Tauro
- **Club Deportivo Árabe Unido** : (2) Árabe U. · Árabe Unido ⇒ (3) ≈Arabe U.≈ · ≈Arabe Unido≈ · ≈Club Deportivo Arabe Unido≈
- **San Francisco FC** : (2) San Francisco · San Francisco Fútbol Club de La Chorrera ⇒ (1) ≈San Francisco Futbol Club de La Chorrera≈
- **Sporting San Miguelito** : (1) Sporting SM




Alphabet

- **Alphabet Specials** (2):  **Á**  **ú** 
  - **Á**×3 U+00C1 (193) - LATIN CAPITAL LETTER A WITH ACUTE ⇒ A
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **city:panama** (2): 
  - Chorrillo FC  (1) Chorrillo
  - Tauro FC  (1) Tauro
- **city:colon** (1): Club Deportivo Árabe Unido  (2) Árabe Unido · Árabe U.
- **city:lachorrera** (1): San Francisco FC  (2) San Francisco · San Francisco Fútbol Club de La Chorrera
- ? (1): Sporting San Miguelito  (1) Sporting SM




By Region

- **city:panama†** (2):   Chorrillo FC · Tauro FC
- **city:colon†** (1):   Club Deportivo Árabe Unido
- **city:lachorrera†** (1):   San Francisco FC




By Year

- ? (5):   Chorrillo FC · Tauro FC · Club Deportivo Árabe Unido · San Francisco FC · Sporting San Miguelito






By A to Z

- **C** (3): Chorrillo · Chorrillo FC · Club Deportivo Árabe Unido
- **S** (5): Sporting SM · San Francisco · San Francisco FC · Sporting San Miguelito · San Francisco Fútbol Club de La Chorrera
- **T** (2): Tauro · Tauro FC
- **Á** (2): Árabe U. · Árabe Unido




