24 clubs

- [**Club América**](https://en.wikipedia.org/wiki/Club_América) ⇒ (1) ≈Club America≈
- [**Cruz Azul**](https://en.wikipedia.org/wiki/Cruz_Azul)
- [**Pumas UNAM**](https://en.wikipedia.org/wiki/Club_Universidad_Nacional) : (2) U.N.A.M. Pumas · Club Universidad Nacional
- [**CD Guadalajara Chivas**](https://en.wikipedia.org/wiki/C.D._Guadalajara) : (2) CD Guadalajara · Guadalajara Chivas
- [**Club Atlas**](https://en.wikipedia.org/wiki/Club_Atlas) : (1) Atlas
- **Leones Negros U. de G.** : (1) Leones Negros
- [**CF Monterrey**](https://en.wikipedia.org/wiki/C.F._Monterrey) : (1) Monterrey
- [**Tigres UANL**](https://en.wikipedia.org/wiki/Tigres_UANL) : (1) U.A.N.L. Tigres
- [**Lobos BUAP**](https://en.wikipedia.org/wiki/Lobos_BUAP)
- [**Club Puebla**](https://en.wikipedia.org/wiki/Puebla_F.C.) : (2) Puebla · Puebla FC
- [**Atlético San Luis**](https://en.wikipedia.org/wiki/Atlético_San_Luis) : (1) Atl. San Luis ⇒ (1) ≈Atletico San Luis≈
- **Atlante FC** : (1) Atlante
- **Jaguares Chiapas** : (1) Chiapas
- [**Club León**](https://en.wikipedia.org/wiki/Club_León) ⇒ (1) ≈Club Leon≈
- [**Club Tijuana**](https://en.wikipedia.org/wiki/Club_Tijuana)
- **Dorados Sinaloa** : (1) Dorados de Sinaloa
- [**Monarcas Morelia**](https://en.wikipedia.org/wiki/Monarcas_Morelia) : (1) Monarcas
- [**Club Necaxa**](https://en.wikipedia.org/wiki/Club_Necaxa) : (1) Necaxa
- [**CF Pachuca**](https://en.wikipedia.org/wiki/C.F._Pachuca) : (1) Pachuca
- [**Querétaro FC**](https://en.wikipedia.org/wiki/Querétaro_FC) : (1) Querétaro ⇒ (2) ≈Queretaro≈ · ≈Queretaro FC≈
- [**Santos Laguna**](https://en.wikipedia.org/wiki/Santos_Laguna)
- [**Deportivo Toluca FC**](https://en.wikipedia.org/wiki/Club_Toluca) : (2) Toluca · Club Toluca
- [**Tiburones Rojos Veracruz**](https://en.wikipedia.org/wiki/Tiburones_Rojos_de_Veracruz) : (2) Veracruz · Tiburones Rojos de Veracruz
- [**FC Juárez**](https://en.wikipedia.org/wiki/FC_Juárez) : (2) Juárez · Fútbol Club Juárez ⇒ (3) ≈Juarez≈ · ≈FC Juarez≈ · ≈Futbol Club Juarez≈




Alphabet

- **Alphabet Specials** (4):  **á**  **é**  **ó**  **ú** 
  - **á**×3 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×4 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Ciudad de México, Ciudad de México** (3): 
  - Club América 
  - Cruz Azul 
  - Pumas UNAM  (2) U.N.A.M. Pumas · Club Universidad Nacional
- **Guadalajara, Jalisco** (3): 
  - CD Guadalajara Chivas  (2) Guadalajara Chivas · CD Guadalajara
  - Club Atlas  (1) Atlas
  - Leones Negros U. de G.  (1) Leones Negros
- **Monterrey, Nuevo León** (2): 
  - CF Monterrey  (1) Monterrey
  - Tigres UANL  (1) U.A.N.L. Tigres
- **Puebla, Puebla** (2): 
  - Lobos BUAP 
  - Club Puebla  (2) Puebla · Puebla FC
- **Aguascalientes, Aguascalientes** (1): Club Necaxa  (1) Necaxa
- **Cancún, Quintana Roo** (1): Atlante FC  (1) Atlante
- **Culiacán, Sinaloa** (1): Dorados Sinaloa  (1) Dorados de Sinaloa
- **Juárez, Chihuahua** (1): FC Juárez  (2) Juárez · Fútbol Club Juárez
- **León, Guanajuato** (1): Club León 
- **Morelia, Michoacán** (1): Monarcas Morelia  (1) Monarcas
- **Pachuca, Hidalgo** (1): CF Pachuca  (1) Pachuca
- **Querétaro, Querétaro** (1): Querétaro FC  (1) Querétaro
- **San Luis Potosí, San Luis Potosí** (1): Atlético San Luis  (1) Atl. San Luis
- **Tijuana, Baja California** (1): Club Tijuana 
- **Toluca, México** (1): Deportivo Toluca FC  (2) Toluca · Club Toluca
- **Torreón, Coahuila** (1): Santos Laguna 
- **Tuxtla Gutiérrez, Chiapas** (1): Jaguares Chiapas  (1) Chiapas
- **Veracruz, Veracruz** (1): Tiburones Rojos Veracruz  (2) Veracruz · Tiburones Rojos de Veracruz




By Region

- **Ciudad de México** (3):   Club América · Cruz Azul · Pumas UNAM
- **Jalisco** (3):   CD Guadalajara Chivas · Club Atlas · Leones Negros U. de G.
- **Nuevo León** (2):   CF Monterrey · Tigres UANL
- **Puebla** (2):   Lobos BUAP · Club Puebla
- **San Luis Potosí** (1):   Atlético San Luis
- **Quintana Roo** (1):   Atlante FC
- **Chiapas** (1):   Jaguares Chiapas
- **Guanajuato** (1):   Club León
- **Baja California** (1):   Club Tijuana
- **Sinaloa** (1):   Dorados Sinaloa
- **Michoacán** (1):   Monarcas Morelia
- **Aguascalientes** (1):   Club Necaxa
- **Hidalgo** (1):   CF Pachuca
- **Querétaro** (1):   Querétaro FC
- **Coahuila** (1):   Santos Laguna
- **México** (1):   Deportivo Toluca FC
- **Veracruz** (1):   Tiburones Rojos Veracruz
- **Chihuahua** (1):   FC Juárez




By Year

- **2015** (1):   FC Juárez
- ? (23):   Club América · Cruz Azul · Pumas UNAM · CD Guadalajara Chivas · Club Atlas · Leones Negros U. de G. · CF Monterrey · Tigres UANL · Lobos BUAP · Club Puebla · Atlético San Luis · Atlante FC · Jaguares Chiapas · Club León · Club Tijuana · Dorados Sinaloa · Monarcas Morelia · Club Necaxa · CF Pachuca · Querétaro FC · Santos Laguna · Deportivo Toluca FC · Tiburones Rojos Veracruz






By A to Z

- **A** (5): Atlas · Atlante · Atlante FC · Atl. San Luis · Atlético San Luis
- **C** (14): Chiapas · Club León · Cruz Azul · CF Pachuca · Club Atlas · Club Necaxa · Club Puebla · Club Toluca · CF Monterrey · Club América · Club Tijuana · CD Guadalajara · CD Guadalajara Chivas · Club Universidad Nacional
- **D** (3): Dorados Sinaloa · Dorados de Sinaloa · Deportivo Toluca FC
- **F** (2): FC Juárez · Fútbol Club Juárez
- **G** (1): Guadalajara Chivas
- **J** (2): Juárez · Jaguares Chiapas
- **L** (3): Lobos BUAP · Leones Negros · Leones Negros U. de G.
- **M** (3): Monarcas · Monterrey · Monarcas Morelia
- **N** (1): Necaxa
- **P** (4): Puebla · Pachuca · Puebla FC · Pumas UNAM
- **Q** (2): Querétaro · Querétaro FC
- **S** (1): Santos Laguna
- **T** (4): Toluca · Tigres UANL · Tiburones Rojos Veracruz · Tiburones Rojos de Veracruz
- **U** (2): U.N.A.M. Pumas · U.A.N.L. Tigres
- **V** (1): Veracruz




