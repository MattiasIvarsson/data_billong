26 clubs

- [**Atlanta United FC**](https://en.wikipedia.org/wiki/Atlanta_United_FC) : (1) Atlanta United
- [**Chicago Fire**](https://en.wikipedia.org/wiki/Chicago_Fire_Soccer_Club) : (2) Chicago · Chicago Fire Soccer Club
- [**Columbus Crew SC**](https://en.wikipedia.org/wiki/Columbus_Crew_SC) : (2) Columbus · Columbus Crew
- [**D.C. United**](https://en.wikipedia.org/wiki/D.C._United) : (2) DC United · Washington D.C. United
- [**New England Revolution**](https://en.wikipedia.org/wiki/New_England_Revolution) : (2) New England · N.E. Revolution
- [**New York City FC**](https://en.wikipedia.org/wiki/New_York_City_FC) : (1) New York City
- [**New York Red Bulls**](https://en.wikipedia.org/wiki/New_York_Red_Bulls) : (3) Metrostars · NY Red Bulls · New York Metrostars
- [**Orlando City SC**](https://en.wikipedia.org/wiki/Orlando_City_SC) : (2) Orlando · Orlando City
- [**Philadelphia Union**](https://en.wikipedia.org/wiki/Philadelphia_Union) : (1) Philadelphia
- [**Colorado Rapids**](https://en.wikipedia.org/wiki/Colorado_Rapids) : (1) Colorado
- [**FC Dallas**](https://en.wikipedia.org/wiki/FC_Dallas) : (1) Dallas
- [**Houston Dynamo**](https://en.wikipedia.org/wiki/Houston_Dynamo) : (2) Houston · H. Dynamo
- [**LA Galaxy**](https://en.wikipedia.org/wiki/LA_Galaxy) : (1) Los Angeles Galaxy
- [**Los Angeles FC**](https://en.wikipedia.org/wiki/Los_Angeles_FC)
- [**San Jose Earthquakes**](https://en.wikipedia.org/wiki/San_Jose_Earthquakes) : (3) San Jose · Earthquakes · SJ Earthquakes
- [**Seattle Sounders FC**](https://en.wikipedia.org/wiki/Seattle_Sounders_FC) : (1) Seattle Sounders
- [**Portland Timbers**](https://en.wikipedia.org/wiki/Portland_Timbers) : (1) Portland
- [**Minnesota United FC**](https://en.wikipedia.org/wiki/Minnesota_United_FC) : (1) Minnesota United
- [**Real Salt Lake**](https://en.wikipedia.org/wiki/Real_Salt_Lake) : (1) Real Salt Lake City
- [**Sporting Kansas City**](https://en.wikipedia.org/wiki/Sporting_Kansas_City) : (2) Sporting KC · Kansas City Wizards
- [**FC Cincinnati**](https://en.wikipedia.org/wiki/FC_Cincinnati) : (1) Cincinnati
- [**Tampa Bay Mutiny (1996-2001)**](https://en.wikipedia.org/wiki/Tampa_Bay_Mutiny)
- [**Miami Fusion (1998-2001)**](https://en.wikipedia.org/wiki/Miami_Fusion)
- [**CD Chivas USA (2005-2014)**](https://en.wikipedia.org/wiki/Chivas_USA) : (2) Chivas USA · Club Deportivo Chivas US
- **Miami**
- **Nashville**




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **D.C. United**, Washington (1):
  - `dcunited` (2): D.C. United · DC United




By City

- **Carson, California** (2): 
  - LA Galaxy  (1) Los Angeles Galaxy
  - CD Chivas USA (2005-2014)  (2) Chivas USA · Club Deportivo Chivas US
- **Atlanta, Georgia** (1): Atlanta United FC  (1) Atlanta United
- **Bridgeview, Illinois** (1): Chicago Fire  (2) Chicago · Chicago Fire Soccer Club
- **Chester, Pennsylvania** (1): Philadelphia Union  (1) Philadelphia
- **Cincinnati, Ohio** (1): FC Cincinnati  (1) Cincinnati
- **Columbus, Ohio** (1): Columbus Crew SC  (2) Columbus · Columbus Crew
- **Commerce City, Colorado** (1): Colorado Rapids  (1) Colorado
- **Fort Lauderdale, Florida** (1): Miami Fusion (1998-2001) 
- **Foxborough, Massachusetts** (1): New England Revolution  (2) New England · N.E. Revolution
- **Frisco, Texas** (1): FC Dallas  (1) Dallas
- **Harrison, New Jersey** (1): New York Red Bulls  (3) NY Red Bulls · New York Metrostars · Metrostars
- **Houston, Texas** (1): Houston Dynamo  (2) Houston · H. Dynamo
- **Kansas City, Kansas** (1): Sporting Kansas City  (2) Sporting KC · Kansas City Wizards
- **Los Angeles, California** (1): Los Angeles FC 
- **Miami, Florida** (1): Miami 
- **Minneapolis, Minnesota** (1): Minnesota United FC  (1) Minnesota United
- **Nashville, Tennessee** (1): Nashville 
- **New York City, New York** (1): New York City FC  (1) New York City
- **Orlando, Florida** (1): Orlando City SC  (2) Orlando · Orlando City
- **Portland, Oregon** (1): Portland Timbers  (1) Portland
- **San Jose, California** (1): San Jose Earthquakes  (3) San Jose · SJ Earthquakes · Earthquakes
- **Sandy, Utah** (1): Real Salt Lake  (1) Real Salt Lake City
- **Seattle, Washington** (1): Seattle Sounders FC  (1) Seattle Sounders
- **Tampa, Florida** (1): Tampa Bay Mutiny (1996-2001) 
- **Washington, D.C.** (1): D.C. United  (2) DC United · Washington D.C. United




By Region

- **Georgia** (1):   Atlanta United FC
- **Illinois** (1):   Chicago Fire
- **Ohio** (2):   Columbus Crew SC · FC Cincinnati
- **D.C.** (1):   D.C. United
- **Massachusetts** (1):   New England Revolution
- **New York** (1):   New York City FC
- **New Jersey** (1):   New York Red Bulls
- **Florida** (4):   Orlando City SC · Tampa Bay Mutiny (1996-2001) · Miami Fusion (1998-2001) · Miami
- **Pennsylvania** (1):   Philadelphia Union
- **Colorado** (1):   Colorado Rapids
- **Texas** (2):   FC Dallas · Houston Dynamo
- **California** (4):   LA Galaxy · Los Angeles FC · San Jose Earthquakes · CD Chivas USA (2005-2014)
- **Washington** (1):   Seattle Sounders FC
- **Oregon** (1):   Portland Timbers
- **Minnesota** (1):   Minnesota United FC
- **Utah** (1):   Real Salt Lake
- **Kansas** (1):   Sporting Kansas City
- **Tennessee** (1):   Nashville




By Year

- **1996** (10):   Columbus Crew SC · D.C. United · New England Revolution · New York Red Bulls · Colorado Rapids · FC Dallas · LA Galaxy · San Jose Earthquakes · Sporting Kansas City · Tampa Bay Mutiny (1996-2001)
- **1998** (2):   Chicago Fire · Miami Fusion (1998-2001)
- **2005** (2):   Real Salt Lake · CD Chivas USA (2005-2014)
- **2006** (1):   Houston Dynamo
- **2009** (1):   Seattle Sounders FC
- **2010** (1):   Philadelphia Union
- **2011** (1):   Portland Timbers
- **2015** (2):   New York City FC · Orlando City SC
- **2017** (2):   Atlanta United FC · Minnesota United FC
- **2018** (1):   Los Angeles FC
- **2019** (1):   FC Cincinnati
- **2020** (2):   Miami · Nashville




Historic

- **2001** (2):   Tampa Bay Mutiny (1996-2001) · Miami Fusion (1998-2001)
- **2014** (1):   CD Chivas USA (2005-2014)






By A to Z

- **A** (2): Atlanta United · Atlanta United FC
- **C** (12): Chicago · Colorado · Columbus · Chivas USA · Cincinnati · Chicago Fire · Columbus Crew · Colorado Rapids · Columbus Crew SC · Chicago Fire Soccer Club · Club Deportivo Chivas US · CD Chivas USA (2005-2014)
- **D** (3): Dallas · DC United · D.C. United
- **E** (1): Earthquakes
- **F** (2): FC Dallas · FC Cincinnati
- **H** (3): Houston · H. Dynamo · Houston Dynamo
- **K** (1): Kansas City Wizards
- **L** (3): LA Galaxy · Los Angeles FC · Los Angeles Galaxy
- **M** (5): Miami · Metrostars · Minnesota United · Minnesota United FC · Miami Fusion (1998-2001)
- **N** (9): Nashville · New England · NY Red Bulls · New York City · N.E. Revolution · New York City FC · New York Red Bulls · New York Metrostars · New England Revolution
- **O** (3): Orlando · Orlando City · Orlando City SC
- **P** (4): Portland · Philadelphia · Portland Timbers · Philadelphia Union
- **R** (2): Real Salt Lake · Real Salt Lake City
- **S** (7): San Jose · Sporting KC · SJ Earthquakes · Seattle Sounders · Seattle Sounders FC · San Jose Earthquakes · Sporting Kansas City
- **T** (1): Tampa Bay Mutiny (1996-2001)
- **W** (1): Washington D.C. United




