3 clubs

- [**Montreal Impact**](https://en.wikipedia.org/wiki/Montreal_Impact) : (4) Montreal · Montreal I. · Impact Montréal · Impact de Montréal ⇒ (2) ≈Impact Montreal≈ · ≈Impact de Montreal≈
- [**Toronto FC**](https://en.wikipedia.org/wiki/Toronto_FC) : (2) TFC · Toronto
- [**Vancouver Whitecaps FC**](https://en.wikipedia.org/wiki/Vancouver_Whitecaps_FC) : (2) Vancouver · Vancouver Whitecaps




Alphabet

- **Alphabet Specials** (1):  **é** 
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e




Duplicates





By City

- **Montréal, Quebec** (1): Montreal Impact  (4) Montreal · Montreal I. · Impact Montréal · Impact de Montréal
- **Toronto, Ontario** (1): Toronto FC  (2) Toronto · TFC
- **Vancouver, British Columbia** (1): Vancouver Whitecaps FC  (2) Vancouver · Vancouver Whitecaps




By Region

- **Quebec** (1):   Montreal Impact
- **Ontario** (1):   Toronto FC
- **British Columbia** (1):   Vancouver Whitecaps FC




By Year

- **1974** (1):   Vancouver Whitecaps FC
- **2006** (1):   Toronto FC
- **2010** (1):   Montreal Impact






By A to Z

- **I** (2): Impact Montréal · Impact de Montréal
- **M** (3): Montreal · Montreal I. · Montreal Impact
- **T** (3): TFC · Toronto · Toronto FC
- **V** (3): Vancouver · Vancouver Whitecaps · Vancouver Whitecaps FC




