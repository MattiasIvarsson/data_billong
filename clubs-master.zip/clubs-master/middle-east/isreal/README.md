15 clubs

- [**Hapoel Tel-Aviv FC**](https://en.wikipedia.org/wiki/Hapoel_Tel_Aviv_F.C.) : (1) H. Tel-Aviv
- [**Maccabi Tel-Aviv FC**](https://en.wikipedia.org/wiki/Maccabi_Tel_Aviv_F.C.) : (2) M. Tel-Aviv · Maccabi Tel Aviv
- [**Bnei Yehuda Tel-Aviv FC**](https://en.wikipedia.org/wiki/Bnei_Yehuda_Tel_Aviv_F.C.) : (1) Bnei Yehuda
- [**Maccabi Haifa FC**](https://en.wikipedia.org/wiki/Maccabi_Haifa_F.C.) : (1) M. Haifa
- [**Hapoel Haifa FC**](https://en.wikipedia.org/wiki/Hapoel_Haifa_F.C.) : (1) H. Haifa
- [**Hapoel Kiryat Shmona FC**](https://en.wikipedia.org/wiki/Hapoel_Ironi_Kiryat_Shmona_F.C.) : (2) H. Kiryat Shmona · Hapoel Ironi Kiryat Shmona FC
- [**Maccabi Netanya FC**](https://en.wikipedia.org/wiki/Maccabi_Netanya_F.C.) : (1) M. Netanya
- [**Beitar Jerusalem FC**](https://en.wikipedia.org/wiki/Beitar_Jerusalem_F.C.) : (1) Beitar Jerusalem
- [**Hapoel Beer-Sheva FC**](https://en.wikipedia.org/wiki/Hapoel_Be'er_Sheva_F.C.) : (1) H. Beer-Sheva
- **H. Ramat Gan**
- [**FC Ashdod**](https://en.wikipedia.org/wiki/F.C._Ashdod) : (2) Ashdod · FC Ironi Ashdod
- [**Bnei Sakhnin FC**](https://en.wikipedia.org/wiki/Bnei_Sakhnin_F.C.) : (1) Bnei Sakhnin
- [**Hapoel Hadera FC**](https://en.wikipedia.org/wiki/Hapoel_Hadera_F.C.) : (1) Hapoel Hadera
- [**Hapoel Ra'anana AFC**](https://en.wikipedia.org/wiki/Hapoel_Ra'anana_A.F.C.) : (1) Hapoel Ra'anana
- [**Maccabi Petah Tikva FC**](https://en.wikipedia.org/wiki/Maccabi_Petah_Tikva_F.C.) : (1) Maccabi Petah Tikva




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Ashdod** (1): FC Ashdod  (2) Ashdod · FC Ironi Ashdod
- **Hadera** (1): Hapoel Hadera FC  (1) Hapoel Hadera
- **Petah Tikva** (1): Maccabi Petah Tikva FC  (1) Maccabi Petah Tikva
- **Ra'anana** (1): Hapoel Ra'anana AFC  (1) Hapoel Ra'anana
- **Sakhnin** (1): Bnei Sakhnin FC  (1) Bnei Sakhnin
- ? (10): 
  - Hapoel Tel-Aviv FC  (1) H. Tel-Aviv
  - Maccabi Tel-Aviv FC  (2) Maccabi Tel Aviv · M. Tel-Aviv
  - Bnei Yehuda Tel-Aviv FC  (1) Bnei Yehuda
  - Maccabi Haifa FC  (1) M. Haifa
  - Hapoel Haifa FC  (1) H. Haifa
  - Hapoel Kiryat Shmona FC  (2) H. Kiryat Shmona · Hapoel Ironi Kiryat Shmona FC
  - Maccabi Netanya FC  (1) M. Netanya
  - Beitar Jerusalem FC  (1) Beitar Jerusalem
  - Hapoel Beer-Sheva FC  (1) H. Beer-Sheva
  - H. Ramat Gan 




By Region

- **Ashdod†** (1):   FC Ashdod
- **Sakhnin†** (1):   Bnei Sakhnin FC
- **Hadera†** (1):   Hapoel Hadera FC
- **Ra'anana†** (1):   Hapoel Ra'anana AFC
- **Petah Tikva†** (1):   Maccabi Petah Tikva FC




By Year

- ? (15):   Hapoel Tel-Aviv FC · Maccabi Tel-Aviv FC · Bnei Yehuda Tel-Aviv FC · Maccabi Haifa FC · Hapoel Haifa FC · Hapoel Kiryat Shmona FC · Maccabi Netanya FC · Beitar Jerusalem FC · Hapoel Beer-Sheva FC · H. Ramat Gan · FC Ashdod · Bnei Sakhnin FC · Hapoel Hadera FC · Hapoel Ra'anana AFC · Maccabi Petah Tikva FC






By A to Z

- **A** (1): Ashdod
- **B** (6): Bnei Yehuda · Bnei Sakhnin · Bnei Sakhnin FC · Beitar Jerusalem · Beitar Jerusalem FC · Bnei Yehuda Tel-Aviv FC
- **F** (2): FC Ashdod · FC Ironi Ashdod
- **H** (14): H. Haifa · H. Tel-Aviv · H. Ramat Gan · H. Beer-Sheva · Hapoel Hadera · Hapoel Haifa FC · Hapoel Ra'anana · H. Kiryat Shmona · Hapoel Hadera FC · Hapoel Tel-Aviv FC · Hapoel Ra'anana AFC · Hapoel Beer-Sheva FC · Hapoel Kiryat Shmona FC · Hapoel Ironi Kiryat Shmona FC
- **M** (9): M. Haifa · M. Netanya · M. Tel-Aviv · Maccabi Haifa FC · Maccabi Tel Aviv · Maccabi Netanya FC · Maccabi Petah Tikva · Maccabi Tel-Aviv FC · Maccabi Petah Tikva FC




